const add = "Add connections";
const edit = "Edit";
const copy = "Replication";
const sqlEditorOpen = "SQL editor";
const dataSourceName = "DataSource Name";
const dataSourceType = "DataSource Type";
const description = "Description";
const createTime = "CreateTime";
const whetherToCite = "Whether to make use of";
const isItOnline = "Is online";
const type = "Type";
const testLink = "Test Connection";
const host = "Host";
const port = "Port";
const user = "User Name";
const password = "Password";
const auth = "Authentication";
const database = "Database";
const serviceType = "Service Type";
const serviceName = "Service Name";
const driver = "Driver";
const storageType = "StorageType";
const connectPlaceholder = "Search for connection names and keywords";
const messageQueue = "Message queue";
const apis = "APIs";
const nodes = "Nodes";
const headers = "Headers";
const protocol = "Protocol";
const online = "Online";
const offline = "Offline";
const pendingLine = "Not detected";
const testLinkSuccess = "Test connection successful";
const mustOne = "Need at least one";
const enUS = {
  add,
  edit,
  copy,
  "delete": "Delete",
  sqlEditorOpen,
  dataSourceName,
  dataSourceType,
  description,
  createTime,
  whetherToCite,
  isItOnline,
  type,
  testLink,
  host,
  port,
  user,
  password,
  auth,
  database,
  serviceType,
  serviceName,
  driver,
  storageType,
  connectPlaceholder,
  messageQueue,
  apis,
  nodes,
  headers,
  protocol,
  online,
  offline,
  pendingLine,
  testLinkSuccess,
  mustOne
};
export {
  add,
  apis,
  auth,
  connectPlaceholder,
  copy,
  createTime,
  dataSourceName,
  dataSourceType,
  database,
  enUS as default,
  description,
  driver,
  edit,
  headers,
  host,
  isItOnline,
  messageQueue,
  mustOne,
  nodes,
  offline,
  online,
  password,
  pendingLine,
  port,
  protocol,
  serviceName,
  serviceType,
  sqlEditorOpen,
  storageType,
  testLink,
  testLinkSuccess,
  type,
  user,
  whetherToCite
};
