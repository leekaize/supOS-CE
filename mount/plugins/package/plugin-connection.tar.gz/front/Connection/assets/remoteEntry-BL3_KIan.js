const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-DoAC068g.js","assets/supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__-C1C8WqCv.js","assets/_commonjsHelpers-DWwsNxpa.js","assets/supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__-UFkmriww.js","assets/WarningFilled-D177vYaR.js","assets/index-vr7a_lBA.js","assets/index-DlGatoyv.js","assets/ResizeObserver.es-qMTzJJp5.js","assets/index-C3Bxq8ve.js","assets/supos_mf_2_ce_mf_1_Connection__loadShare__react_mf_2_dom__loadShare__-Bj9B9w_U.js","assets/supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__-BzNwQxr7.js","assets/lodash-BksnO1zI.js","assets/index-B0OThK7f.js","assets/index-d6dAhBYk.js","assets/index-BR9OUV7e.js"])))=>i.map(i=>d[i]);
import { i as init_1, s as supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__ } from "./supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__-UFkmriww.js";
import exposesMap from "./virtualExposes-BDP6ywEu.js";
import { _ as __vitePreload } from "./preload-helper-BaJ0u6Ce.js";
const importMap = {
  "@ant-design/icons": async () => {
    let pkg = await __vitePreload(() => import("./index-DoAC068g.js"), true ? __vite__mapDeps([0,1,2,3,4]) : void 0);
    return pkg;
  },
  "@carbon/icons-react": async () => {
    let pkg = await __vitePreload(() => import("./index-vr7a_lBA.js"), true ? __vite__mapDeps([5,2,1,3]) : void 0);
    return pkg;
  },
  "ahooks": async () => {
    let pkg = await __vitePreload(() => import("./index-DlGatoyv.js"), true ? __vite__mapDeps([6,1,2,3,7]) : void 0);
    return pkg;
  },
  "antd": async () => {
    let pkg = await __vitePreload(() => import("./index-C3Bxq8ve.js"), true ? __vite__mapDeps([8,1,2,3,4,9,7,10]) : void 0);
    return pkg;
  },
  "lodash": async () => {
    let pkg = await __vitePreload(() => import("./lodash-BksnO1zI.js").then((n) => n.l), true ? __vite__mapDeps([11,2]) : void 0);
    return pkg;
  },
  "react": async () => {
    let pkg = await __vitePreload(() => import("./index-B0OThK7f.js").then((n) => n.i), true ? __vite__mapDeps([12,2]) : void 0);
    return pkg;
  },
  "react-dom": async () => {
    let pkg = await __vitePreload(() => import("./index-d6dAhBYk.js").then((n) => n.i), true ? __vite__mapDeps([13,2,1,3]) : void 0);
    return pkg;
  },
  "react-router-dom": async () => {
    let pkg = await __vitePreload(() => import("./index-BR9OUV7e.js"), true ? __vite__mapDeps([14,1,2,3,9]) : void 0);
    return pkg;
  }
};
const usedShared = {
  "@ant-design/icons": {
    name: "@ant-design/icons",
    version: "6.0.0",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Connection",
    async get() {
      usedShared["@ant-design/icons"].loaded = true;
      const { "@ant-design/icons": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "6.0.0"
    }
  },
  "@carbon/icons-react": {
    name: "@carbon/icons-react",
    version: "11.60.0",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Connection",
    async get() {
      usedShared["@carbon/icons-react"].loaded = true;
      const { "@carbon/icons-react": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^11.60.0"
    }
  },
  "ahooks": {
    name: "ahooks",
    version: "3.8.5",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Connection",
    async get() {
      usedShared["ahooks"].loaded = true;
      const { "ahooks": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^3.8.5"
    }
  },
  "antd": {
    name: "antd",
    version: "5.27.1",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Connection",
    async get() {
      usedShared["antd"].loaded = true;
      const { "antd": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "5.27.1"
    }
  },
  "lodash": {
    name: "lodash",
    version: "4.17.21",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Connection",
    async get() {
      usedShared["lodash"].loaded = true;
      const { "lodash": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^4.17.21"
    }
  },
  "react": {
    name: "react",
    version: "18.3.1",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Connection",
    async get() {
      usedShared["react"].loaded = true;
      const { "react": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^18.3.1"
    }
  },
  "react-dom": {
    name: "react-dom",
    version: "18.3.1",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Connection",
    async get() {
      usedShared["react-dom"].loaded = true;
      const { "react-dom": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^18.3.1"
    }
  },
  "react-router-dom": {
    name: "react-router-dom",
    version: "6.28.0",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Connection",
    async get() {
      usedShared["react-router-dom"].loaded = true;
      const { "react-router-dom": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^6.27.0"
    }
  }
};
const usedRemotes = [
  {
    entryGlobalName: "supos-ce/host",
    name: "@supos_host",
    type: "var",
    entry: "/mf-manifest.json",
    shareScope: "default"
  }
];
const initTokens = {};
const shareScopeName = "default";
const mfName = "supos-ce/Connection";
async function init(shared = {}, initScope = []) {
  const initRes = init_1({
    name: mfName,
    remotes: usedRemotes,
    shared: usedShared,
    plugins: [],
    shareStrategy: "version-first"
  });
  var initToken = initTokens[shareScopeName];
  if (!initToken)
    initToken = initTokens[shareScopeName] = { from: mfName };
  if (initScope.indexOf(initToken) >= 0) return;
  initScope.push(initToken);
  initRes.initShareScopeMap("default", shared);
  try {
    await Promise.all(await initRes.initializeSharing("default", {
      strategy: "version-first",
      from: "build",
      initScope
    }));
  } catch (e) {
    console.error(e);
  }
  supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__.initResolve(initRes);
  return initRes;
}
function getExposes(moduleName) {
  if (!(moduleName in exposesMap)) throw new Error(`Module ${moduleName} does not exist in container.`);
  return exposesMap[moduleName]().then((res) => () => res);
}
export {
  getExposes as get,
  init
};
