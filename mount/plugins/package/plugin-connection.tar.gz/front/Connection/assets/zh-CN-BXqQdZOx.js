const add = "新增连接";
const edit = "编辑";
const copy = "复制";
const sqlEditorOpen = "SQL编辑器";
const dataSourceName = "数据源名称";
const dataSourceType = "数据源类型";
const description = "描述";
const createTime = "创建时间";
const whetherToCite = "是否引用";
const isItOnline = "是否在线";
const type = "类型";
const testLink = "测试连接";
const host = "主机";
const port = "端口";
const user = "用户名";
const password = "密码";
const auth = "身份验证";
const database = "数据库";
const serviceType = "连接类型";
const serviceName = "服务名";
const driver = "驱动";
const storageType = "存储";
const connectPlaceholder = "搜索连接名称和关键字";
const messageQueue = "消息队列";
const apis = "APIs";
const nodes = "节点";
const headers = "请求头";
const protocol = "协议";
const online = "在线";
const offline = "离线";
const pendingLine = "未检测";
const testLinkSuccess = "测试连接成功";
const mustOne = "至少需要一项";
const zhCN = {
  add,
  edit,
  copy,
  "delete": "删除",
  sqlEditorOpen,
  dataSourceName,
  dataSourceType,
  description,
  createTime,
  whetherToCite,
  isItOnline,
  type,
  testLink,
  host,
  port,
  user,
  password,
  auth,
  database,
  serviceType,
  serviceName,
  driver,
  storageType,
  connectPlaceholder,
  messageQueue,
  apis,
  nodes,
  headers,
  protocol,
  online,
  offline,
  pendingLine,
  testLinkSuccess,
  mustOne
};
export {
  add,
  apis,
  auth,
  connectPlaceholder,
  copy,
  createTime,
  dataSourceName,
  dataSourceType,
  database,
  zhCN as default,
  description,
  driver,
  edit,
  headers,
  host,
  isItOnline,
  messageQueue,
  mustOne,
  nodes,
  offline,
  online,
  password,
  pendingLine,
  port,
  protocol,
  serviceName,
  serviceType,
  sqlEditorOpen,
  storageType,
  testLink,
  testLinkSuccess,
  type,
  user,
  whetherToCite
};
