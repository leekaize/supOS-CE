import { s as supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__-C1C8WqCv.js";
import { s as supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__, a as index_cjs } from "./supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__-UFkmriww.js";
import { I as Icon } from "./supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__-BzNwQxr7.js";
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
const { loadShare: loadShare$4 } = index_cjs;
const { initPromise: initPromise$8 } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res$8 = initPromise$8.then((_) => loadShare$4("react-router-dom", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^6.27.0"
  } }
}));
const exportModule$8 = await res$8.then((factory) => factory());
var supos_mf_2_ce_mf_1_Connection__loadShare__react_mf_2_router_mf_2_dom__loadShare__ = exportModule$8;
const { loadShare: loadShare$3 } = index_cjs;
const { initPromise: initPromise$7 } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res$7 = initPromise$7.then((_) => loadShare$3("ahooks", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^3.8.5"
  } }
}));
const exportModule$7 = await res$7.then((factory) => factory());
var supos_mf_2_ce_mf_1_Connection__loadShare__ahooks__loadShare__ = exportModule$7;
const { loadRemote: loadRemote$3 } = index_cjs;
const { initPromise: initPromise$6 } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res$6 = initPromise$6.then((_) => loadRemote$3("@supos_host/hooks"));
const exportModule$6 = await initPromise$6.then((_) => res$6);
var supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__ = exportModule$6;
const REMOTE_NAME = "Connection";
const { loadRemote: loadRemote$2 } = index_cjs;
const { initPromise: initPromise$5 } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res$5 = initPromise$5.then((_) => loadRemote$2("@supos_host/components"));
const exportModule$5 = await initPromise$5.then((_) => res$5);
var supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__ = exportModule$5;
const { loadShare: loadShare$2 } = index_cjs;
const { initPromise: initPromise$4 } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res$4 = initPromise$4.then((_) => loadShare$2("@carbon/icons-react", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^11.60.0"
  } }
}));
const exportModule$4 = await res$4.then((factory) => factory());
var supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__ = exportModule$4;
const { loadRemote: loadRemote$1 } = index_cjs;
const { initPromise: initPromise$3 } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res$3 = initPromise$3.then((_) => loadRemote$1("@supos_host/utils"));
const exportModule$3 = await initPromise$3.then((_) => res$3);
var supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__ = exportModule$3;
const baseUrl = "/inter-api/supos/datasource";
const api = new supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl);
const pageListApi = async (params) => api.get("/pageList", {
  params,
  [supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.CustomAxiosConfigEnum.BusinessResponse]: true
});
const createApi = async (data) => api.post("", data);
const getDetailApi = async (id) => api.get(`/${id}`);
const editApi = async (data) => api.put("", data);
const deleteApi = async (id) => api.delete(`/${id}`);
const testApi = async (data) => api.post("/connection/test", data);
const { loadShare: loadShare$1 } = index_cjs;
const { initPromise: initPromise$2 } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res$2 = initPromise$2.then((_) => loadShare$1("antd", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "5.27.1"
  } }
}));
const exportModule$2 = await res$2.then((factory) => factory());
var supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__ = exportModule$2;
const connection = "_connection_1berw_1";
const flex = "_flex_1berw_1";
const styles = {
  connection,
  flex
};
const { loadShare } = index_cjs;
const { initPromise: initPromise$1 } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res$1 = initPromise$1.then((_) => loadShare("lodash", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^4.17.21"
  } }
}));
const exportModule$1 = await res$1.then((factory) => factory());
var supos_mf_2_ce_mf_1_Connection__loadShare__lodash__loadShare__ = exportModule$1;
const ButtonPermission = {
  "Connection.add": "Connection.add",
  "Connection.edit": "Connection.edit",
  "Connection.copy": "Connection.copy",
  "Connection.delete": "Connection.delete",
  "Connection.sqlEditorOpen": "Connection.sqlEditorOpen"
};
var CategoryType = /* @__PURE__ */ ((CategoryType2) => {
  CategoryType2["DB"] = "DB";
  CategoryType2["MQ"] = "MQ";
  CategoryType2["APIs"] = "APIs";
  return CategoryType2;
})(CategoryType || {});
var ConnectTypeCode = /* @__PURE__ */ ((ConnectTypeCode2) => {
  ConnectTypeCode2["MYSQL"] = "MYSQL";
  ConnectTypeCode2["ORACLE"] = "ORACLE";
  ConnectTypeCode2["MONGODB"] = "MONGODB";
  ConnectTypeCode2["REDIS"] = "REDIS";
  ConnectTypeCode2["POSTGRESQL"] = "POSTGRESQL";
  ConnectTypeCode2["SQLSERVER"] = "SQLSERVER";
  ConnectTypeCode2["MARIADB"] = "MARIADB";
  ConnectTypeCode2["KAFKA"] = "KAFKA";
  ConnectTypeCode2["RABBITMQ"] = "RABBITMQ";
  ConnectTypeCode2["EMQX"] = "EMQX";
  ConnectTypeCode2["WEBSOCKET"] = "WEBSOCKET";
  return ConnectTypeCode2;
})(ConnectTypeCode || {});
const templateInfo = {
  [ConnectTypeCode.MYSQL]: {
    pattern: /jdbc:mysql:\/\/(.*):(\d+)(\/(\w+))?/,
    template: "jdbc:mysql://{host}:{port}/{database}"
  },
  [ConnectTypeCode.POSTGRESQL]: {
    pattern: /jdbc:postgresql:\/\/(.*):(\d+)(\/(\w+))?/,
    template: "jdbc:postgresql://{host}:{port}/{database}"
  },
  [ConnectTypeCode.MARIADB]: {
    pattern: /jdbc:mariadb:\/\/(.*):(\d+)(\/(\w+))?/,
    template: "jdbc:mariadb://{host}:{port}/{database}"
  },
  [ConnectTypeCode.SQLSERVER]: {
    pattern: /jdbc:sqlserver:\/\/(.*):(\d+)(;database=(\w+))?/,
    template: "jdbc:sqlserver://{host}:{port};database={database}"
  },
  [ConnectTypeCode.ORACLE + "sid"]: {
    pattern: /jdbc:oracle:(.*):@(.*):(\d+):(.*)/,
    template: "jdbc:oracle:{driver}:@{host}:{port}:{sid}"
  },
  [ConnectTypeCode.ORACLE + "service"]: {
    pattern: /jdbc:oracle:(.*):@\/\/(.*):(\d+)\/(.*)/,
    template: "jdbc:oracle:{driver}:@//{host}:{port}/{serviceName}"
  },
  [ConnectTypeCode.MONGODB]: {
    pattern: /mongodb:\/\/(.*):(\d+)(\/(\w+))?/,
    template: "mongodb://{host}:{port}/{database}"
  },
  [ConnectTypeCode.REDIS + "cluster"]: {
    pattern: /redis:cluster:\/\/(.*):(\d+)(\/(\w+))?/,
    template: "redis:cluster://{host}:{port}/{database}"
  },
  [ConnectTypeCode.REDIS + "standalone"]: {
    pattern: /redis:\/\/(.*):(\d+)(\/(\w+))?/,
    template: "redis://{host}:{port}/{database}"
  },
  [ConnectTypeCode.KAFKA]: {
    pattern: /^kafka:\/\/([^/]+)\/(.+)$/,
    template: "kafka://{nodeHosts}/{topic}"
  },
  [ConnectTypeCode.RABBITMQ]: {
    pattern: /^amqp:\/\/([^:@]+):([^:@]+)@([^:/]+):(\d+)\/([^?]+)/,
    template: "amqp://{user}:{password}@{host}:{port}/{vhost}"
  },
  [ConnectTypeCode.EMQX + "1"]: {
    pattern: /^mqtt:\/\/([^:@]+):([^:@]+)@([^:/]+):(\d+)\/([^?]+)/,
    template: "mqtt://{user}:{password}@{host}:{port}/{clientId}"
  },
  [ConnectTypeCode.EMQX + "2"]: {
    pattern: /^mqtt:\/\/([^/:@]+):(\d+)\/([^?]+)/,
    template: "mqtt://{host}:{port}/{clientId}"
  },
  [ConnectTypeCode.WEBSOCKET]: {
    pattern: /^(wss?):\/\/([^:/?#]+)(?::(\d+))?(\/[^?#]*)?/,
    template: "{protocol}://{host}:{port}"
  }
};
function extractObjByUrl(info, key) {
  const { template } = templateInfo[key];
  let url = template;
  Object.keys(info).map((t) => {
    url = url.replace(`{${t}}`, info[t] || "");
  });
  if (key === ConnectTypeCode.RABBITMQ && !info.vhost) {
    url = url.replace(/\/$/, "");
  }
  if (key === ConnectTypeCode.KAFKA && !info.topic) {
    url = url.replace(/\/[^/]*$/, "");
    console.log(url);
  }
  if (key === ConnectTypeCode.WEBSOCKET && info.originalUrl) {
    const pathMatch = info.originalUrl.match(/^wss?:\/\/[^/]+(\/.*)$/);
    if (pathMatch && pathMatch[1]) {
      url += pathMatch[1];
    }
  }
  return url;
}
function extractObj(url, key) {
  const { template, pattern } = templateInfo[key];
  const matches = url.match(pattern);
  const reg = /{(.*?)}/g;
  let match;
  const arr = [];
  while ((match = reg.exec(template)) !== null) {
    arr.push(match[1]);
  }
  const newExtract = {};
  arr.map((t, i) => {
    newExtract[t] = t === "database" ? matches[i + 2] || "" : matches[i + 1];
  });
  if (key === ConnectTypeCode.WEBSOCKET) {
    newExtract.originalUrl = url;
  }
  return newExtract;
}
const getKey = (form, key) => {
  const _key = key ? key : form.getFieldValue("type");
  if (_key === ConnectTypeCode.ORACLE) {
    return _key + form.getFieldValue("serviceType");
  }
  if (_key === ConnectTypeCode.REDIS) {
    return _key + form.getFieldValue("serviceType");
  }
  if (_key === ConnectTypeCode.EMQX) {
    return _key + form.getFieldValue("authenticationType");
  }
  return _key;
};
const otherInputChangeForUrl = (_, form, key) => {
  const _key = getKey(form, key);
  form.setFieldValue("url", extractObjByUrl(form.getFieldsValue(true), _key));
};
const otherSelectChangeForUrl = (_, __, form, key) => {
  const _key = getKey(form, key);
  form.setFieldValue("url", extractObjByUrl(form.getFieldsValue(true), _key));
};
const urlChangeForOther = (e, form, key) => {
  const _key = getKey(form, key);
  const keyValue = e.target.value;
  if (templateInfo[_key].pattern.test(keyValue)) {
    form.setFieldsValue(extractObj(form.getFieldValue("url"), _key));
  }
};
const initFormConfig = (origin) => {
  return Object.keys(origin).reduce((acc, key) => {
    acc[key] = void 0;
    return acc;
  }, {});
};
function arrayToObject(arr) {
  return arr == null ? void 0 : arr.filter((f2) => f2).reduce((obj, item) => {
    if (item.key && item.value) {
      obj[item.key] = item.value;
    }
    return obj;
  }, {});
}
function objectToArray(obj) {
  return Object.entries(obj).map(([key, value]) => ({
    key,
    value
  }));
}
const NextButton = ({ handleStep }) => {
  const commonFormatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const type = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useWatch("type");
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Button,
    {
      color: "default",
      variant: "filled",
      size: "small",
      icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.ChevronRight, {}),
      iconPosition: "end",
      onClick: handleStep,
      disabled: !type,
      children: commonFormatMessage("common.next")
    }
  );
};
const FormStep = ({ step, setStep, setOpen, refreshRequest, disablePre }) => {
  const commonFormatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const formatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [loading, setLoading] = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useState(false);
  const form = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useFormInstance();
  const { message } = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.App.useApp();
  const save = async () => {
    var _a;
    await form.validateFields();
    const info = form.getFieldsValue(true);
    setLoading(true);
    const api2 = info.id ? editApi : createApi;
    api2({
      id: info.id,
      // supos的配置
      category: info.category,
      dsType: info.type,
      name: info.alias,
      description: info.description,
      // chat2db要的配置
      config: {
        ...info,
        user: (info == null ? void 0 : info.authenticationType) === "2" ? void 0 : info.user,
        password: (info == null ? void 0 : info.authenticationType) === "2" ? void 0 : info.password,
        id: void 0,
        description: void 0,
        category: void 0,
        // kafka
        nodes: (info == null ? void 0 : info.nodes) ? (_a = info == null ? void 0 : info.nodes) == null ? void 0 : _a.map((m2) => `${m2.host}:${m2.port}`) : void 0,
        // websocket
        headers: (info == null ? void 0 : info.headers) ? arrayToObject(info.headers) : void 0,
        // 默认都加上，不然chat2db会报错
        ssh: {
          use: false
        },
        extendInfo: []
      }
    }).then(() => {
      refreshRequest == null ? void 0 : refreshRequest();
      message.success(commonFormatMessage("appGui.saveSuccess"));
      setOpen(false);
      form.resetFields();
    }).finally(() => {
      setLoading(false);
    });
  };
  const handleStep = async () => {
    setStep(2);
  };
  const onTest = async () => {
    const info = form.getFieldsValue(true);
    setLoading(true);
    testApi({
      url: info.url,
      username: (info == null ? void 0 : info.authenticationType) === "2" ? void 0 : info.user,
      password: (info == null ? void 0 : info.authenticationType) === "2" ? void 0 : info.password,
      headers: (info == null ? void 0 : info.headers) ? arrayToObject(info.headers) : void 0
    }).then(() => {
      message.success(formatMessage("testLinkSuccess"));
    }).finally(() => {
      setLoading(false);
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Divider, { style: { borderColor: "rgb(198, 198, 198)" } }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { align: "center", justify: "flex-end", gap: 10, children: step === 1 ? /* @__PURE__ */ jsxRuntimeExports.jsx(NextButton, { handleStep }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { style: { width: "100%" }, justify: "space-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Button, { color: "primary", variant: "solid", size: "small", onClick: onTest, loading, children: formatMessage("testLink") }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { gap: 10, children: [
        !disablePre && /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Button,
          {
            color: "default",
            variant: "filled",
            size: "small",
            style: { color: "var(--supos-text-color)", backgroundColor: "var(--supos-uns-button-color)" },
            icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.ChevronLeft, {}),
            onClick: () => {
              setStep(() => step - 1);
            },
            disabled: loading,
            children: commonFormatMessage("common.prev")
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Button, { color: "primary", variant: "solid", size: "small", onClick: save, loading, children: commonFormatMessage("common.save") })
      ] })
    ] }) })
  ] });
};
const { loadRemote } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadRemote("@supos_host/i18nStore"));
const exportModule = await initPromise.then((_) => res);
var supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_i18nStore__loadRemote__ = exportModule;
const connectTypeList = [
  { label: "MySQL", value: ConnectTypeCode.MYSQL, parentId: CategoryType.DB, sqlEdit: true },
  { label: "PostgreSql", value: ConnectTypeCode.POSTGRESQL, parentId: CategoryType.DB, sqlEdit: true },
  { label: "Mariadb", value: ConnectTypeCode.MARIADB, parentId: CategoryType.DB, sqlEdit: true },
  { label: "SQLServer", value: ConnectTypeCode.SQLSERVER, parentId: CategoryType.DB, sqlEdit: true },
  { label: "Oracle", value: ConnectTypeCode.ORACLE, parentId: CategoryType.DB, sqlEdit: true },
  { label: "MongoDB", value: ConnectTypeCode.MONGODB, parentId: CategoryType.DB, sqlEdit: true },
  { label: "Redis", value: ConnectTypeCode.REDIS, parentId: CategoryType.DB, sqlEdit: false },
  { label: "kafka", value: ConnectTypeCode.KAFKA, parentId: CategoryType.MQ, sqlEdit: false },
  { label: "RabbitMQ", value: ConnectTypeCode.RABBITMQ, parentId: CategoryType.MQ, sqlEdit: false },
  { label: "EMQx", value: ConnectTypeCode.EMQX, parentId: CategoryType.MQ, sqlEdit: false },
  { label: "WebSocket", value: ConnectTypeCode.WEBSOCKET, parentId: CategoryType.APIs, sqlEdit: false }
];
const connectTypeTree = [
  {
    label: "database",
    value: CategoryType.DB,
    children: connectTypeList.filter((i) => i.parentId === CategoryType.DB)
  },
  {
    label: "messageQueue",
    value: CategoryType.MQ,
    children: connectTypeList.filter((i) => i.parentId === CategoryType.MQ)
  },
  {
    label: "apis",
    value: CategoryType.APIs,
    children: connectTypeList.filter((i) => i.parentId === CategoryType.APIs)
  }
];
const initBaseConfig = {
  [ConnectTypeCode.MYSQL]: {
    host: "localhost",
    port: "3306",
    authenticationType: "1",
    user: "root",
    password: void 0,
    database: void 0,
    url: "jdbc:mysql://localhost:3306"
  },
  [ConnectTypeCode.POSTGRESQL]: {
    host: "localhost",
    port: "5432",
    authenticationType: "1",
    user: "root",
    password: void 0,
    database: "postgres",
    url: "jdbc:postgresql://localhost:5432/postgres"
  },
  [ConnectTypeCode.MARIADB]: {
    host: "localhost",
    port: "3306",
    authenticationType: "1",
    user: "root",
    password: void 0,
    database: void 0,
    url: "jdbc:mariadb://localhost:3306"
  },
  [ConnectTypeCode.SQLSERVER]: {
    host: "localhost",
    port: "1433",
    authenticationType: "1",
    user: "root",
    password: void 0,
    database: void 0,
    url: "jdbc:sqlserver://localhost:1433"
  },
  [ConnectTypeCode.ORACLE]: {
    host: "localhost",
    port: "1521",
    serviceType: "sid",
    driver: "thin",
    authenticationType: "1",
    user: "root",
    password: void 0,
    sid: "XE",
    url: "jdbc:oracle:thin:@localhost:1521:XE"
  },
  [ConnectTypeCode.MONGODB]: {
    host: "localhost",
    port: "27017",
    authenticationType: "1",
    user: "root",
    password: void 0,
    database: void 0,
    url: "mongodb://localhost:27017"
  },
  [ConnectTypeCode.REDIS]: {
    // storageType: 'CLOUD',
    serviceType: "standalone",
    host: "localhost",
    port: "9092",
    authenticationType: "1",
    password: void 0,
    database: void 0,
    url: "redis://localhost:6379"
  },
  [ConnectTypeCode.KAFKA]: {
    url: "kafka://",
    topic: void 0
  },
  [ConnectTypeCode.RABBITMQ]: {
    host: "localhost",
    port: "3306",
    authenticationType: "1",
    user: "root",
    password: void 0,
    vhost: void 0,
    url: "amqp://root:@localhost:3306"
  },
  [ConnectTypeCode.EMQX]: {
    host: "localhost",
    port: "3306",
    authenticationType: "1",
    user: "root",
    password: void 0,
    clientId: void 0,
    url: "mqtt://root:@localhost:3306"
  },
  [ConnectTypeCode.WEBSOCKET]: {
    protocol: "ws",
    host: "localhost",
    port: "3306",
    url: "ws://localhost:3306"
  }
};
const connectSourceFormConfigs = [
  {
    type: ConnectTypeCode.MYSQL,
    baseInfo: {
      formItems: [
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "authenticationType",
            labelCode: "Connection.auth"
          },
          childProps: {
            options: [
              {
                label: "User&Password",
                value: "1",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "user",
                      labelCode: "Connection.user",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  },
                  {
                    formType: "password",
                    formProps: {
                      name: "password",
                      labelCode: "Connection.password",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  }
                ]
              },
              {
                label: "None",
                value: "2",
                formItems: []
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "database",
            labelCode: "Connection.database"
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.POSTGRESQL,
    baseInfo: {
      formItems: [
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "authenticationType",
            labelCode: "Connection.auth"
          },
          childProps: {
            options: [
              {
                label: "User&Password",
                value: "1",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "user",
                      labelCode: "Connection.user",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  },
                  {
                    formType: "password",
                    formProps: {
                      name: "password",
                      labelCode: "Connection.password",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  }
                ]
              },
              {
                label: "None",
                value: "2",
                formItems: []
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "database",
            labelCode: "Connection.database"
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.MARIADB,
    baseInfo: {
      formItems: [
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "authenticationType",
            labelCode: "Connection.auth"
          },
          childProps: {
            options: [
              {
                label: "User&Password",
                value: "1",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "user",
                      labelCode: "Connection.user",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  },
                  {
                    formType: "password",
                    formProps: {
                      name: "password",
                      labelCode: "Connection.password",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  }
                ]
              },
              {
                label: "None",
                value: "2",
                formItems: []
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "database",
            labelCode: "Connection.database"
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.SQLSERVER,
    baseInfo: {
      formItems: [
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "instance",
            label: "Instance"
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "authenticationType",
            labelCode: "Connection.auth"
          },
          childProps: {
            options: [
              {
                label: "User&Password",
                value: "1",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "user",
                      labelCode: "Connection.user",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  },
                  {
                    formType: "password",
                    formProps: {
                      name: "password",
                      labelCode: "Connection.password",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  }
                ]
              },
              {
                label: "None",
                value: "2",
                formItems: []
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "database",
            labelCode: "Connection.database"
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.ORACLE,
    baseInfo: {
      formItems: [
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "serviceType",
            labelCode: "Connection.serviceType"
          },
          childProps: {
            onChange: (v, options, form) => {
              if (v === "sid") {
                form.setFieldsValue({
                  sid: "XE",
                  serviceName: void 0
                });
              } else {
                form.setFieldsValue({
                  sid: void 0,
                  serviceName: void 0
                });
              }
              return otherSelectChangeForUrl(v, options, form);
            },
            options: [
              {
                label: "SID",
                value: "sid",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "sid",
                      label: "SID",
                      // style: {
                      //   width: `${(2 / 3) * 100}%`,
                      //   display: 'inline-block',
                      // },
                      // labelCol: { span: 6 },
                      // wrapperCol: { span: 17 },
                      rules: [{ required: true }]
                    },
                    childProps: {
                      onChange: otherInputChangeForUrl
                    }
                  }
                ]
              },
              {
                label: "Service",
                value: "service",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "serviceName",
                      labelCode: "Connection.serviceName",
                      // style: {
                      //   width: `${(2 / 3) * 100}%`,
                      //   display: 'inline-block',
                      // },
                      // labelCol: { span: 6 },
                      // wrapperCol: { span: 17 },
                      rules: [{ required: true }]
                    },
                    childProps: {
                      onChange: otherInputChangeForUrl
                    }
                  }
                ]
              }
            ]
          }
        },
        {
          formType: "select",
          formProps: {
            hidden: true,
            name: "driver",
            labelCode: "Connection.driver"
            // style: {
            //   width: `${(1 / 3) * 100}%`,
            //   display: 'inline-block',
            // },
            // labelCol: { span: 6 },
            // wrapperCol: { span: 18 },
          },
          childProps: {
            onChange: otherSelectChangeForUrl,
            options: [
              {
                value: "thin",
                label: "thin"
              },
              {
                value: "oci",
                label: "oci"
              },
              {
                value: "oci8",
                label: "oci8"
              }
            ]
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "authenticationType",
            labelCode: "Connection.auth"
          },
          childProps: {
            options: [
              {
                label: "User&Password",
                value: "1",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "user",
                      labelCode: "Connection.user",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  },
                  {
                    formType: "password",
                    formProps: {
                      name: "password",
                      labelCode: "Connection.password",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  }
                ]
              },
              {
                label: "None",
                value: "2",
                formItems: []
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.MONGODB,
    baseInfo: {
      formItems: [
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "authenticationType",
            labelCode: "Connection.auth"
          },
          childProps: {
            options: [
              {
                label: "User&Password",
                value: "1",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "user",
                      labelCode: "Connection.user",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  },
                  {
                    formType: "password",
                    formProps: {
                      name: "password",
                      labelCode: "Connection.password",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  }
                ]
              },
              {
                label: "None",
                value: "2",
                formItems: []
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "database",
            labelCode: "Connection.database"
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.REDIS,
    baseInfo: {
      formItems: [
        // {
        //   formType: 'select',
        //   formProps: {
        //     name: 'storageType',
        //     labelCode: 'Connection.storageType',
        //   },
        //   childProps: {
        //     options: [
        //       {
        //         value: 'CLOUD',
        //         label: 'CLOUD',
        //       },
        //       {
        //         value: 'LOCAL',
        //         label: 'LOCAL',
        //       },
        //     ],
        //   },
        // },
        {
          formType: "select",
          formProps: {
            name: "serviceType",
            labelCode: "Connection.serviceType"
          },
          childProps: {
            onChange: otherSelectChangeForUrl,
            options: [
              {
                value: "standalone",
                label: "standalone"
              },
              {
                value: "cluster",
                label: "cluster"
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "authenticationType",
            labelCode: "Connection.auth"
          },
          childProps: {
            options: [
              {
                label: "User&Password",
                value: "1",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "user",
                      labelCode: "Connection.user"
                    },
                    childProps: {}
                  },
                  {
                    formType: "password",
                    formProps: {
                      name: "password",
                      labelCode: "Connection.password",
                      rules: [{ required: true }]
                    },
                    childProps: {}
                  }
                ]
              },
              {
                label: "None",
                value: "2",
                formItems: []
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "database",
            labelCode: "Connection.database"
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.RABBITMQ,
    baseInfo: {
      formItems: [
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "authenticationType",
            labelCode: "Connection.auth"
          },
          childProps: {
            disabled: true,
            options: [
              {
                label: "User&Password",
                value: "1",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "user",
                      labelCode: "Connection.user",
                      rules: [{ required: true }]
                    },
                    childProps: {
                      onChange: otherInputChangeForUrl
                    }
                  },
                  {
                    formType: "password",
                    formProps: {
                      name: "password",
                      labelCode: "Connection.password",
                      rules: [{ required: true }]
                    },
                    childProps: {
                      onChange: otherInputChangeForUrl
                    }
                  }
                ]
              },
              {
                label: "None",
                value: "2",
                formItems: []
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "vhost",
            label: "vhost"
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.EMQX,
    baseInfo: {
      formItems: [
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "controlledSelect",
          formProps: {
            name: "authenticationType",
            labelCode: "Connection.auth"
          },
          childProps: {
            onChange: otherSelectChangeForUrl,
            options: [
              {
                label: "User&Password",
                value: "1",
                formItems: [
                  {
                    formType: "input",
                    formProps: {
                      name: "user",
                      labelCode: "Connection.user",
                      rules: [{ required: true }]
                    },
                    childProps: {
                      onChange: otherInputChangeForUrl
                    }
                  },
                  {
                    formType: "password",
                    formProps: {
                      name: "password",
                      labelCode: "Connection.password",
                      rules: [{ required: true }]
                    },
                    childProps: {
                      onChange: otherInputChangeForUrl
                    }
                  }
                ]
              },
              {
                label: "None",
                value: "2",
                formItems: []
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "clientId",
            label: "Client ID",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.KAFKA,
    baseInfo: {
      formItems: [
        {
          formType: "input",
          formProps: {
            hidden: true,
            name: "nodeHosts"
          }
        },
        {
          formType: "formList",
          formProps: {
            name: "nodes",
            rules: [{ required: true }]
          },
          childProps: {
            style: {
              marginBottom: 24
            },
            titleKey: "Connection.nodes",
            onChange: (nodes, form) => {
              form.setFieldValue("nodeHosts", nodes.map((node) => `${node.host || ""}:${node.port || ""}`).join(","));
              otherInputChangeForUrl(nodes, form);
            },
            formItems: [
              {
                formType: "input",
                formProps: {
                  name: "host",
                  wrapperCol: { span: 24 },
                  style: { width: "70%" },
                  rules: [{ required: true, message: supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_i18nStore__loadRemote__.getIntl("rule.required") }]
                },
                childProps: {
                  placeholder: "Connection.host"
                }
              },
              {
                formType: "input",
                formProps: {
                  name: "port",
                  wrapperCol: { span: 24 },
                  style: { width: "30%" },
                  rules: [{ required: true, message: supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_i18nStore__loadRemote__.getIntl("rule.required") }]
                },
                childProps: {
                  placeholder: "Connection.port"
                }
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "topic",
            label: "topic"
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            disabled: true,
            onChange: urlChangeForOther
          }
        }
      ]
    }
  },
  {
    type: ConnectTypeCode.WEBSOCKET,
    baseInfo: {
      formItems: [
        {
          formType: "select",
          formProps: {
            name: "protocol",
            labelCode: "Connection.protocol"
          },
          childProps: {
            onChange: otherSelectChangeForUrl,
            options: [
              {
                value: "ws",
                label: "ws"
              },
              {
                value: "wss",
                label: "wss"
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "host",
            labelCode: "Connection.host",
            style: {
              width: `${2 / 3 * 100}%`,
              display: "inline-block"
            },
            labelCol: { span: 6 },
            wrapperCol: { span: 17 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "input",
          formProps: {
            name: "port",
            labelCode: "Connection.port",
            style: {
              width: `${1 / 3 * 100}%`,
              display: "inline-block"
            },
            labelAlign: "right",
            labelCol: { span: 12 },
            wrapperCol: { span: 12 },
            rules: [{ required: true }]
          },
          childProps: {
            onChange: otherInputChangeForUrl
          }
        },
        {
          formType: "formList",
          formProps: {
            name: "headers",
            labelCode: "Connection.headers"
          },
          childProps: {
            style: {
              marginBottom: 24
            },
            titleKey: "Connection.headers",
            onChange: otherInputChangeForUrl,
            formItems: [
              {
                formType: "input",
                formProps: {
                  name: "key",
                  wrapperCol: { span: 24 },
                  style: { width: "50%" }
                },
                childProps: {
                  placeholder: "uns.key"
                }
              },
              {
                formType: "input",
                formProps: {
                  name: "value",
                  wrapperCol: { span: 24 },
                  style: { width: "50%" }
                },
                childProps: {
                  placeholder: "uns.value"
                }
              }
            ]
          }
        },
        {
          formType: "input",
          formProps: {
            name: "url",
            label: "URL",
            rules: [{ required: true }]
          },
          childProps: {
            onChange: urlChangeForOther
          }
        }
      ]
    }
  }
];
const MARIADB$8 = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "4636", width: "1em", height: "1em", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M912.896 456.704s-2.048 0 0 0c-47.104-4.096-80.896 8.704-102.4 36.352-4.096 6.144-10.752 12.8-14.848 21.504-4.096 8.704-8.704 16.896-12.8 27.648-2.048 4.096-8.704 21.504-10.752 23.552-4.096 10.752-8.704 16.896-12.8 21.504l-6.656 6.144c-19.456 19.456-34.304 27.648-57.344 29.696-36.352 4.096-51.2 6.656-74.752 12.8-25.6 8.704-49.152 21.504-68.096 40.448-10.752 10.752-19.456 21.504-25.6 31.744-4.096 6.656-10.752 21.504-12.8 21.504-4.096 6.144-4.096 6.144-12.8 6.144-25.6 0-45.056 21.504-49.152 47.104-4.096 29.696 14.848 51.2 49.152 49.152 27.648-2.048 49.152-10.752 74.752-27.648 4.096-2.048 19.456-12.8 21.504-14.848 6.144-4.096 10.752-6.656 12.8-6.656 12.8-4.096 70.656-10.752 93.696-12.8v2.048c-2.048 12.8-8.704 21.504-14.848 27.648-8.704 8.704-12.8 19.456-4.096 29.696 4.096 6.144 12.8 8.704 21.504 8.704 10.752 0 25.6-4.096 40.448-10.752 27.648-12.8 51.2-31.744 64-59.904 12.8 10.752 25.6 14.848 38.4 12.8 19.456-2.048 31.744-10.752 34.304-25.6 2.048-6.656 0-12.8-4.096-16.896-12.8-10.752-16.896-23.552-14.848-40.448 0-4.096 2.048-10.752 4.096-14.848 0 0 6.656-10.752 8.704-16.896 8.704-16.896 14.848-36.352 16.896-66.048v-4.096c2.048-27.648 8.704-42.496 16.896-47.104 16.896-8.704 29.696-29.696 31.744-53.248 6.144-15.36-2.56-38.4-30.208-38.4z",
        fill: "currentColor",
        "p-id": "4637"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M473.6 722.944l-40.448-68.096-57.344 96.256H210.944L128 614.4l80.896-136.704h132.096L270.848 360.448l80.896-136.704h166.4L599.04 360.448l-70.656 117.248h125.952l68.096 113.152c6.144-4.096 10.752-8.704 19.456-14.848l6.656-6.656s2.048-4.096 6.144-10.752L682.496 435.2h-74.752l45.056-74.752-106.496-179.2H328.704l-106.496 179.2L266.752 435.2H185.344l-106.496 179.2 106.496 179.2h215.552l31.744-53.248 10.752 16.896c8.704-14.848 17.408-25.6 30.208-34.304z",
        fill: "currentColor",
        "p-id": "4638"
      }
    )
  ] });
};
const POSTGRESQL$1 = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "5847", width: "1em", height: "1em", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    "path",
    {
      d: "M730.794667 0a432.384 432.384 0 0 0-117.546667 17.194667l-2.688 0.853333A466.005333 466.005333 0 0 0 537.6 11.008C487.338667 10.154667 444.16 22.357333 409.344 42.666667 375.04 30.762667 303.872 10.24 228.864 14.336 176.64 17.194667 119.637333 33.066667 77.397333 77.653333 35.285333 122.24 13.013333 191.232 17.706667 285.098667c1.28 25.898667 8.661333 68.138667 20.906666 122.837333s29.44 118.741333 50.901334 177.152c21.461333 58.453333 44.970667 110.933333 81.706666 146.602667 18.346667 17.877333 43.605333 32.896 73.386667 31.658666 20.906667-0.853333 39.808-10.026667 56.106667-23.552 7.936 10.453333 16.426667 15.018667 24.149333 19.242667 9.728 5.333333 19.2 8.96 29.013333 11.349333 17.621333 4.394667 47.786667 10.282667 83.114667 4.266667 12.032-2.005333 24.704-5.930667 37.333333-11.52 0.469333 14.08 1.024 27.861333 1.578667 41.813333 1.749333 44.202667 2.858667 85.034667 16.128 120.832 2.133333 5.845333 7.978667 35.968 31.018667 62.549334 23.04 26.624 68.181333 43.221333 119.594666 32.213333 36.266667-7.765333 82.389333-21.76 113.024-65.365333 30.293333-43.093333 43.946667-104.917333 46.634667-205.184a201.813333 201.813333 0 0 1 2.346667-14.336l7.210666 0.64h0.853334c38.698667 1.749333 80.682667-3.754667 115.754666-20.053334 31.061333-14.378667 54.570667-28.928 71.68-54.741333 4.266667-6.4 8.96-14.122667 10.24-27.434667s-6.357333-34.133333-19.029333-43.733333c-25.386667-19.285333-41.344-11.946667-58.453333-8.405333a267.52 267.52 0 0 1-51.285334 6.229333c49.322667-83.072 84.693333-171.306667 104.874667-249.386667 11.946667-46.08 18.645333-88.576 19.2-125.738666 0.554667-37.162667-2.474667-70.058667-24.746667-98.517334C911.36 25.6 813.525333 1.024 737.834667 0.170667c-2.346667-0.042667-4.693333-0.085333-7.04-0.042667z m-2.005334 27.306667c71.594667-0.682667 163.072 19.413333 228.736 103.338666 14.762667 18.858667 19.157333 46.421333 18.645334 80.384-0.554667 33.92-6.826667 74.538667-18.304 119.04-22.272 86.186667-64.341333 186.666667-123.605334 276.821334a32.256 32.256 0 0 0 6.741334 3.669333c12.373333 5.12 40.576 9.514667 96.853333-2.048 14.165333-2.986667 24.533333-4.992 35.285333 3.2a22.186667 22.186667 0 0 1 7.808 18.133333 30.037333 30.037333 0 0 1-5.546666 14.336c-10.88 16.341333-32.341333 31.829333-59.861334 44.586667-24.362667 11.349333-59.306667 17.28-90.282666 17.621333-15.530667 0.170667-29.866667-1.024-42.026667-4.821333l-0.768-0.298667c-4.693333 45.226667-15.488 134.528-22.528 175.274667-5.632 32.853333-15.488 58.965333-34.304 78.506667-18.773333 19.541333-45.354667 31.317333-81.109333 38.997333-44.288 9.514667-76.586667-0.725333-97.408-18.261333-20.778667-17.493333-30.293333-40.704-36.010667-54.912-3.925333-9.813333-5.973333-22.528-7.936-39.509334-1.962667-16.981333-3.413333-37.76-4.394667-61.184a2194.176 2194.176 0 0 1-1.28-107.648 130.602667 130.602667 0 0 1-66.218666 32.426667c-29.397333 4.992-55.637333 0.085333-71.296-3.84a97.109333 97.109333 0 0 1-22.186667-8.576c-7.253333-3.882667-14.165333-8.277333-18.773333-16.938667a23.893333 23.893333 0 0 1-2.432-16.256 26.026667 26.026667 0 0 1 9.301333-14.122666c8.448-6.869333 19.626667-10.709333 36.48-14.208 30.677333-6.314667 41.386667-10.624 47.914667-15.786667 5.546667-4.437333 11.818667-13.397333 22.912-26.538667a49.493333 49.493333 0 0 1-0.128-1.749333 126.293333 126.293333 0 0 1-56.746667-15.274667c-6.4 6.741333-39.082667 41.301333-78.933333 89.258667-16.768 20.053333-35.285333 31.573333-54.826667 32.384-19.541333 0.853333-37.205333-9.002667-52.224-23.552-29.994667-29.141333-53.930667-79.274667-74.794667-135.936-20.821333-56.661333-37.76-119.765333-49.792-173.525333-12.074667-53.76-19.2-97.109333-20.224-118.016-4.48-88.832 16.298667-148.693333 51.925334-186.453334 35.669333-37.76 84.565333-52.053333 132.224-54.784 85.546667-4.906667 166.784 24.917333 183.210666 31.317334 31.658667-21.504 72.448-34.901333 123.392-34.048a315.306667 315.306667 0 0 1 71.722667 9.301333l0.853333-0.384a292.437333 292.437333 0 0 1 31.530667-9.130667A410.709333 410.709333 0 0 1 728.746667 27.392z m6.485334 28.586666h-6.229334a372.906667 372.906667 0 0 0-72.704 8.192c53.162667 23.552 93.312 59.818667 121.6 96a360.106667 360.106667 0 0 1 48.298667 81.92c4.693333 11.264 7.850667 20.778667 9.642667 28.16 0.896 3.712 1.493333 6.826667 1.706666 10.069334a18.773333 18.773333 0 0 1-0.512 6.144c0 0.128-0.213333 0.426667-0.256 0.554666 1.28 37.376-7.978667 62.72-9.088 98.389334-0.853333 25.856 5.76 56.234667 7.381334 89.386666 1.536 31.146667-2.218667 65.365333-22.442667 98.944 1.706667 2.048 3.242667 4.096 4.864 6.144 53.504-84.266667 92.074667-177.493333 112.64-256.981333 11.008-42.794667 16.853333-81.578667 17.365333-112.298667 0.426667-30.72-5.290667-52.992-12.586666-62.293333-57.258667-73.216-134.741333-91.861333-199.68-92.373333z m-204.373334 10.922667c-50.432 0.128-86.613333 15.36-114.048 38.186667-28.288 23.594667-47.274667 55.893333-59.733333 88.96-14.805333 39.253333-19.882667 77.226667-21.888 102.997333l0.554667-0.341333c15.232-8.533333 35.242667-17.066667 56.661333-22.016 21.418667-4.906667 44.501333-6.442667 65.408 1.664s38.186667 27.178667 44.458667 56.106666c30.037333 138.965333-9.344 190.634667-23.850667 229.632a410.026667 410.026667 0 0 0-14.122667 43.221334c1.834667-0.426667 3.669333-0.938667 5.504-1.109334 10.24-0.853333 18.261333 2.56 23.04 4.608 14.592 6.058667 24.618667 18.773333 30.037334 33.28 1.408 3.797333 2.432 7.893333 3.029333 12.117334a14.336 14.336 0 0 1 0.853333 5.418666 2352.64 2352.64 0 0 0 0.554667 159.488c0.981333 22.954667 2.432 43.178667 4.266667 59.136 1.834667 15.914667 4.437333 28.032 6.101333 32.128 5.461333 13.653333 13.44 31.530667 27.861333 43.690667 14.421333 12.117333 35.114667 20.224 72.917334 12.117333 32.768-7.04 52.992-16.810667 66.517333-30.848 13.482667-14.037333 21.546667-33.578667 26.709333-63.488 7.722667-44.8 23.253333-174.72 25.130667-199.168-0.853333-18.432 1.877333-32.597333 7.765333-43.392 6.058667-11.093333 15.445333-17.877333 23.552-21.546666 4.053333-1.834667 7.850667-3.072 10.965334-3.968a254.122667 254.122667 0 0 0-10.368-13.866667 190.122667 190.122667 0 0 1-28.416-46.890667 353.962667 353.962667 0 0 0-10.965334-20.608c-5.674667-10.24-12.842667-23.04-20.352-37.418666-15.018667-28.8-31.36-63.701333-39.850666-97.706667-8.448-33.962667-9.685333-69.12 11.989333-93.909333 19.2-22.016 52.906667-31.146667 103.509333-26.026667-1.493333-4.48-2.389333-8.192-4.906666-14.165333a333.525333 333.525333 0 0 0-44.416-75.264c-42.88-54.826667-112.298667-109.184-219.562667-110.933334h-4.906667z m-283.392 2.218667c-5.418667 0-10.837333 0.170667-16.213333 0.469333-43.093333 2.474667-83.84 14.976-112.981333 45.866667-29.184 30.890667-48.384 81.536-44.202667 165.376 0.810667 15.872 7.722667 60.330667 19.584 113.152 11.818667 52.821333 28.586667 114.986667 48.725333 169.898666 20.181333 54.912 44.629333 102.698667 67.84 125.312 11.690667 11.306667 21.845333 15.872 31.061334 15.488 9.258667-0.426667 20.394667-5.76 34.005333-22.101333a1845.077333 1845.077333 0 0 1 77.226667-87.381333 149.205333 149.205333 0 0 1-49.792-134.4c4.394667-31.530667 4.992-61.013333 4.48-84.309334-0.512-22.698667-2.133333-37.802667-2.133334-47.232a14.336 14.336 0 0 1 0-0.810666v-0.213334l-0.042666-0.256v-0.042666a422.101333 422.101333 0 0 1 25.258666-144.042667c11.946667-31.744 29.738667-64 56.405334-90.112-26.197333-8.618667-72.704-21.76-123.050667-24.234667a324.394667 324.394667 0 0 0-16.213333-0.426666zM776.490667 294.4c-28.970667 0.384-45.226667 7.850667-53.76 17.621333-12.074667 13.866667-13.226667 38.186667-5.717334 68.138667 7.466667 29.994667 22.912 63.530667 37.418667 91.392 7.253333 13.952 14.293333 26.496 19.968 36.693333 5.717333 10.24 9.898667 17.493333 12.458667 23.68 2.346667 5.717333 4.949333 10.752 7.594666 15.445334 11.221333-23.68 13.226667-46.933333 12.074667-71.168-1.493333-29.994667-8.448-60.672-7.424-91.733334 1.152-36.309333 8.32-59.946667 8.96-88.021333a247.168 247.168 0 0 0-31.573333-2.048z m-351.317334 4.906667a120.32 120.32 0 0 0-26.282666 3.157333 199.04 199.04 0 0 0-49.194667 19.157333 103.125333 103.125333 0 0 0-14.890667 9.728l-0.938666 0.853334c0.256 6.229333 1.493333 21.333333 2.005333 43.562666 0.512 24.32-0.085333 55.338667-4.778667 88.917334-10.197333 72.96 42.752 133.376 104.96 133.461333 3.626667-14.976 9.6-30.165333 15.573334-46.165333 17.322667-46.677333 51.413333-80.725333 22.698666-213.589334-4.693333-21.76-13.994667-30.549333-26.794666-35.498666a62.890667 62.890667 0 0 0-22.357334-3.584z m337.792 8.704h2.133334a37.461333 37.461333 0 0 1 7.68 0.938666c2.304 0.512 4.266667 1.28 5.888 2.346667a6.997333 6.997333 0 0 1 3.2 4.693333l-0.042667 0.341334h0.042667-0.042667a10.24 10.24 0 0 1-1.493333 5.76 28.501333 28.501333 0 0 1-4.693334 6.4 28.885333 28.885333 0 0 1-16.469333 9.045333 25.173333 25.173333 0 0 1-17.493333-4.394667 25.941333 25.941333 0 0 1-5.546667-5.034666 11.093333 11.093333 0 0 1-2.688-5.418667 7.253333 7.253333 0 0 1 1.792-5.461333 16.384 16.384 0 0 1 4.992-3.84c4.096-2.304 9.642667-4.010667 15.914667-4.949334 2.346667-0.341333 4.650667-0.512 6.826666-0.554666z m-333.653333 7.168c2.261333 0 4.650667 0.213333 7.082667 0.554666 6.528 0.896 12.330667 2.645333 16.768 5.205334a19.029333 19.029333 0 0 1 5.674666 4.522666 9.514667 9.514667 0 0 1 2.304 7.253334 12.885333 12.885333 0 0 1-3.2 6.570666 27.690667 27.690667 0 0 1-6.101333 5.546667 27.306667 27.306667 0 0 1-19.114667 4.821333 31.061333 31.061333 0 0 1-17.92-9.728 30.293333 30.293333 0 0 1-5.034666-6.997333 11.946667 11.946667 0 0 1-1.749334-7.552c0.64-4.608 4.437333-6.997333 8.149334-8.32a36.949333 36.949333 0 0 1 13.098666-1.706667z m386.56 313.301333l-0.128 0.042667c-6.272 2.261333-11.434667 3.2-15.786667 5.12a19.285333 19.285333 0 0 0-10.197333 9.130666c-2.688 4.906667-4.992 13.610667-4.309333 28.416a21.76 21.76 0 0 0 6.314666 2.986667c7.296 2.218667 19.541333 3.669333 33.194667 3.456 27.221333-0.298667 60.714667-6.656 78.506667-14.933333a168.533333 168.533333 0 0 0 40.234666-26.24h-0.042666c-59.434667 12.288-93.013333 9.002667-113.621334 0.512a56.106667 56.106667 0 0 1-14.165333-8.533334z m-342.656 4.010667h-0.896c-2.261333 0.213333-5.546667 0.981333-11.904 8.021333-14.848 16.64-20.053333 27.093333-32.298667 36.864-12.245333 9.728-28.16 14.933333-59.946666 21.461333a81.834667 81.834667 0 0 0-19.669334 6.144c1.237333 1.024 1.109333 1.28 2.986667 2.261334 4.650667 2.56 10.624 4.821333 15.445333 6.058666 13.653333 3.413333 36.096 7.381333 59.52 3.413334 23.424-4.010667 47.786667-15.232 68.565334-44.373334 3.584-5.034667 3.968-12.458667 1.024-20.437333-2.986667-7.978667-9.514667-14.848-14.122667-16.768a27.861333 27.861333 0 0 0-8.704-2.56z",
      "p-id": "5848",
      fill: "currentColor"
    }
  ) });
};
const POSTGRESQL = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "6895", width: "1em", height: "1em", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M1001.632 793.792c-7.84-13.856-26.016-37.536-93.12-83.2a1096.224 1096.224 0 0 0-125.152-74.144c-30.592-82.784-89.824-190.112-176.256-319.36-93.056-139.168-201.12-197.792-321.888-174.56a756.608 756.608 0 0 0-40.928-37.696C213.824 78.688 139.2 56.48 96.32 60.736c-19.424 1.952-34.016 9.056-43.36 21.088-21.664 27.904-14.432 68.064 85.504 198.912 19.008 55.616 23.072 84.672 23.072 99.296 0 30.912 15.968 66.368 49.984 110.752l-32 109.504c-28.544 97.792 23.328 224.288 71.616 268.384 25.76 23.552 47.456 20.032 58.176 15.84 21.504-8.448 38.848-29.472 50.048-89.504 5.728 14.112 11.808 29.312 18.208 45.6 34.56 87.744 68.352 136.288 106.336 152.736a32.032 32.032 0 0 0 25.44-58.688c-9.408-4.096-35.328-23.712-72.288-117.504-31.168-79.136-53.856-132.064-69.376-161.856a32.224 32.224 0 0 0-35.328-16.48 32.032 32.032 0 0 0-25.024 29.92c-3.872 91.04-13.056 130.4-19.2 147.008-26.496-30.464-68.128-125.984-47.232-197.536 20.768-71.232 32.992-112.928 36.64-125.248a31.936 31.936 0 0 0-5.888-29.28c-41.664-51.168-46.176-75.584-46.176-83.712 0-29.472-9.248-70.4-28.288-125.152a31.104 31.104 0 0 0-4.768-8.896c-53.824-70.112-73.6-105.216-80.832-121.888 25.632 1.216 74.336 15.04 91.008 29.376a660.8 660.8 0 0 1 49.024 46.304c8 8.448 19.968 11.872 31.232 8.928 100.192-25.92 188.928 21.152 271.072 144 87.808 131.328 146.144 238.048 173.408 317.216a32 32 0 0 0 16.384 18.432 1004.544 1004.544 0 0 1 128.8 75.264c7.392 5.024 14.048 9.696 20.064 14.016h-98.848a32.032 32.032 0 0 0-24.352 52.736 3098.752 3098.752 0 0 0 97.856 110.464 32 32 0 1 0 46.56-43.872 2237.6 2237.6 0 0 1-50.08-55.328h110.08a32.032 32.032 0 0 0 27.84-47.776z",
        "p-id": "6896",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M320 289.472c12.672 21.76 22.464 37.344 29.344 46.784 8.288 16.256 21.184 29.248 29.44 45.536l2.016-1.984c14.528-9.952 25.92-49.504 2.752-75.488-12.032-18.176-51.04-17.664-63.552-14.848z",
        "p-id": "6897",
        fill: "currentColor"
      }
    )
  ] });
};
const MARIADB$7 = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "1683", width: "1em", height: "1em", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M215.846 671.657c54.004-35.684 107.171-74.018 165.288-102.444 60.464-26.253 120.071-47.82 182.395-70.003 60.822-22.361 122.782-40.591 185.705-56.6 62.935-15.947 126.791-28.496 191.238-37.383l-9.76 19.962c-14.888-24.35-34.334-45.821-56.344-64.332-22.02-18.564-46.653-34.11-72.414-47.6a497.77 497.77 0 0 0-19.584-9.685c-6.597-3.106-13.241-6.132-19.963-9.003a599.898 599.898 0 0 0-20.331-8.266 695.449 695.449 0 0 0-20.608-7.678c-27.652-9.841-55.948-18.185-84.619-25.233-28.659-7.003-57.794-12.756-86.917-16.841-3.636-0.498-7.247-0.97-10.797-1.349l-11.274-1.236a2146.98 2146.98 0 0 1-22.539-2.722c-15.023-1.862-30.02-4.012-44.999-6.311-29.939-4.727-59.814-10.263-89.313-17.815-7.368-1.917-14.71-3.951-22.012-6.155-7.301-2.205-14.569-4.561-21.728-7.285-7.159-2.713-14.259-5.65-21.132-9.179-3.424-1.788-6.796-3.715-10.028-5.926-1.614-1.111-3.196-2.288-4.697-3.616a27.685 27.685 0 0 1-2.167-2.143c-0.347-0.386-0.683-0.79-1.006-1.225a11.139 11.139 0 0 1-0.477-0.691l-0.232-0.388c-0.081-0.149-0.142-0.252-0.271-0.547a1.62 1.62 0 1 1 2.971-1.294c-0.026-0.083 0.031 0.018 0.078 0.066l0.166 0.193c0.121 0.135 0.257 0.276 0.4 0.415 0.286 0.279 0.601 0.555 0.932 0.822a23.997 23.997 0 0 0 2.122 1.519c1.484 0.962 3.066 1.832 4.69 2.633 3.253 1.602 6.669 2.955 10.136 4.177 6.931 2.464 14.076 4.447 21.288 6.168 14.442 3.405 29.1 6.078 43.857 8.208 29.503 4.34 59.261 7.279 89.071 9.662 14.902 1.23 29.833 2.21 44.766 3.183l22.415 1.309 11.216 0.625c3.95 0.212 7.823 0.513 11.665 0.833 15.366 1.279 30.547 3.217 45.704 5.485 15.153 2.25 30.215 5.067 45.224 8.19 29.998 6.318 59.705 14.396 88.786 24.637 7.262 2.579 14.496 5.261 21.674 8.104a633.708 633.708 0 0 1 21.366 9.004c7.068 3.145 14.1 6.396 21.039 9.854a530.944 530.944 0 0 1 20.593 10.872 434.182 434.182 0 0 1 39.592 24.811c12.771 8.993 25.085 18.719 36.728 29.26 23.299 21.032 43.896 45.489 59.789 72.911l10.27 17.718-20.028 2.244c-63.62 7.125-126.857 18.122-189.391 32.393-62.549 14.216-124.444 32.854-185.355 53.341-60.944 20.386-120.986 42.426-179.757 68.681-29.383 13.128-58.455 26.986-87.121 41.661-14.349 7.303-28.602 14.803-42.719 22.554-14.101 7.766-28.14 15.716-41.803 24.169l-0.029 0.018a1.623 1.623 0 0 1-1.749-2.732z",
        "p-id": "1684",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M209.963 677.652c20.688-16.411 40.803-33.515 59.903-51.661 19.143-18.088 37.364-37.122 54.246-57.217 8.426-10.058 16.51-20.385 24.139-31.006 7.608-10.626 14.793-21.563 21.103-32.862a183.354 183.354 0 0 0 4.47-8.515l0.506-1.056 0.557-1.205 0.991-2.27 1.889-4.479a313.186 313.186 0 0 0 3.579-9.053 301.38 301.38 0 0 0 3.343-9.108 325.21 325.21 0 0 0 5.77-18.427c1.738-6.176 3.177-12.413 4.475-18.649a227.377 227.377 0 0 0 3.041-18.802c0.772-6.281 1.302-12.572 1.521-18.859 0.115-3.143 0.151-6.285 0.117-9.42-0.01-3.136-0.095-6.268-0.254-9.392a192.937 192.937 0 0 0-1.856-18.635c-3.512-24.695-11.826-48.505-23.843-70.371-5.981-10.957-12.992-21.366-20.633-31.296-7.681-9.896-16.184-19.212-25.226-27.776a175.341 175.341 0 0 0-6.899-6.159l-1.733-1.436-1.576-1.252c0.077 0.06-0.885-0.679-0.535-0.417l-0.117-0.102-0.233-0.204-0.466-0.407-0.948-0.874-1.88-1.762-3.716-3.564a282.594 282.594 0 0 1-3.577-3.748c-2.395-2.494-4.61-5.203-6.828-7.915-4.306-5.549-8.327-11.507-11.268-18.321-1.43-3.413-2.653-7.043-3.015-10.975-0.187-1.948-0.123-4.001 0.423-5.963 0.294-0.976 0.716-1.918 1.291-2.729 0.559-0.808 1.319-1.497 2.181-1.788-0.704 1.638-0.39 3.185 0.184 4.521 0.554 1.347 1.395 2.552 2.299 3.71 1.866 2.293 4.085 4.373 6.421 6.364 4.685 3.976 9.759 7.672 14.905 11.32 2.526 1.876 5.178 3.629 7.736 5.496 1.294 0.917 2.601 1.824 3.917 2.721l3.889 2.773 3.523 2.455 1.247 0.924 1.1 0.842 2.118 1.674a198.672 198.672 0 0 1 8.03 6.844c10.402 9.296 19.787 19.517 28.375 30.409 8.616 10.868 16.206 22.564 22.811 34.816 6.636 12.24 11.99 25.197 16.188 38.51 4.164 13.33 6.91 27.101 8.338 40.964 2.73 27.772-0.331 55.83-8.101 82.046-1.896 6.572-4.157 13.016-6.587 19.364-2.426 6.352-5.143 12.571-8.058 18.671a308.25 308.25 0 0 1-4.513 9.065 325.117 325.117 0 0 1-4.848 8.863l-2.528 4.382-1.267 2.135-0.513 1.027-0.6 1.157c-1.605 3.046-3.298 5.961-5.037 8.852-6.976 11.521-14.706 22.418-22.84 32.979-8.137 10.557-16.735 20.716-25.658 30.556-35.729 39.361-76.427 73.677-119.473 104.235z",
        "p-id": "1685",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M690.811 462.863c-11.202-10.033-23.855-19.852-35.554-29.38-11.68-9.552-23.726-18.717-36.167-27.376-6.239-4.303-12.542-8.533-18.979-12.561a597.859 597.859 0 0 0-19.576-11.684c-26.471-14.997-54.155-28.04-82.668-39.175-28.453-11.315-57.758-20.741-87.595-28.368-29.823-7.76-27.023-23.895 4.021-18.259 31.023 5.783 61.779 13.468 91.98 23.226 30.136 9.932 59.694 21.938 88.283 36.152a624.38 624.38 0 0 1 21.287 11.007c7.038 3.795 14.057 7.649 20.979 11.689 13.88 8.018 27.484 16.59 40.701 25.777 13.191 9.221 25.917 19.161 37.968 29.873a391.554 391.554 0 0 1 17.569 16.581",
        "p-id": "1686",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M504.265 210.272c7.783 20.086 13.193 41.187 16.299 62.71 3.1 21.525 3.785 43.508 1.912 65.352a297.933 297.933 0 0 1-1.9 16.374 214.153 214.153 0 0 1-1.403 8.137 249.382 249.382 0 0 1-1.724 8.121c-2.505 10.788-5.811 21.432-10.021 31.704-4.19 10.278-9.157 20.225-14.752 29.741-5.613 9.508-11.797 18.612-18.305 27.395-6.501 8.792-13.396 17.21-20.378 25.483-7.015 8.273-14.046 16.353-21.409 24.36-14.654 15.997-30.276 31.101-46.621 45.297-16.339 14.21-33.456 27.443-51.069 39.884a713.556 713.556 0 0 1-26.824 18.032 1231.056 1231.056 0 0 1-13.691 8.56c-4.612 2.777-9.218 5.555-13.899 8.215l12.484-10.215c4.177-3.373 8.331-6.772 12.459-10.198a1921.952 1921.952 0 0 0 24.653-20.604c16.29-13.859 32.193-28.084 47.546-42.809a789.044 789.044 0 0 0 44.143-45.921c3.516-3.964 6.976-7.995 10.467-12.047 3.489-4.036 6.954-8.08 10.37-12.151 6.84-8.134 13.449-16.402 19.757-24.824 6.299-8.429 12.219-17.076 17.55-26.025 5.357-8.931 10.134-18.162 14.155-27.707 4.007-9.548 7.361-19.368 9.895-29.436a234.407 234.407 0 0 0 1.772-7.585c0.542-2.582 1.021-4.99 1.513-7.687a294.292 294.292 0 0 0 2.503-15.502c2.848-20.812 3.639-41.967 2.602-63.149-1.024-21.194-3.927-42.38-8.084-63.505zM654.02 238.096c0.518 2.054 0.892 4.13 1.276 6.211 0.327 2.083 0.623 4.175 0.888 6.277 0.492 4.202 0.758 8.433 0.847 12.671a159.8 159.8 0 0 1-1.553 25.397c-0.272 2.107-0.622 4.201-0.985 6.293l-0.568 3.133-0.146 0.783-0.037 0.196-0.048 0.217-0.089 0.377-0.355 1.51c-0.983 4.118-2.055 8.2-3.201 12.268a305.387 305.387 0 0 1-7.876 24.147c-6.003 15.864-13.405 31.254-22.155 45.773-8.718 14.542-18.58 28.298-29.112 41.369a580.201 580.201 0 0 1-16.155 19.239l-8.222 9.268-8.147 9.285c-5.462 6.183-10.864 12.463-16.47 18.629a647.404 647.404 0 0 1-8.477 9.225 474.458 474.458 0 0 1-8.775 9.014 324.52 324.52 0 0 1-38.248 32.636c-6.761 4.911-13.643 9.618-20.685 14.061a599.722 599.722 0 0 1-10.618 6.553c-3.593 2.097-7.168 4.209-10.821 6.199l9.5-8.051a724.68 724.68 0 0 0 9.454-8.048c6.244-5.421 12.45-10.848 18.486-16.427 12.113-11.12 23.596-22.724 34.324-35.011 10.743-12.269 20.933-25.157 31.472-37.996 2.617-3.221 5.307-6.392 7.984-9.578 2.676-3.174 5.42-6.377 8.074-9.454 5.335-6.216 10.599-12.472 15.667-18.857 10.133-12.769 19.664-25.921 28.028-39.733 8.354-13.812 15.638-28.22 21.504-43.251a291.694 291.694 0 0 0 7.984-22.877 337.49 337.49 0 0 0 3.316-11.68l0.398-1.5 0.1-0.375 0.1-0.34 0.219-0.725 0.86-2.906 1.649-5.834c2.136-7.801 4.107-15.67 5.84-23.667a524.034 524.034 0 0 0 2.471-12.092c0.412-2.032 0.794-4.076 1.145-6.13l1.157-6.199zM822.932 290.223c-3.896 19.357-10.441 38.246-19.119 56.222-8.687 17.978-19.675 34.894-32.108 50.501-12.437 15.627-26.202 30.026-40.509 43.656-7.143 6.636-14.486 13.05-22.189 19.208a221.19 221.19 0 0 1-11.889 8.92c-4.093 2.849-8.298 5.586-12.806 7.972 2.541-4.421 5.308-8.567 8.153-12.638 2.847-4.068 5.8-8.029 8.868-11.893 6.117-7.736 12.646-15.163 19.583-22.159 13.807-13.665 27.259-27.554 39.798-42.145 12.549-14.581 24.136-29.908 34.447-46.224a393.993 393.993 0 0 0 14.589-25.138c4.585-8.592 8.915-17.377 13.182-26.282z",
        "p-id": "1687",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M345.965 547.814c33.042-32.345 69.5-61.194 107.723-87.398 38.283-26.148 78.514-49.519 120.168-69.979 41.652-20.465 84.758-37.989 128.859-52.278 44.111-14.228 89.215-25.373 134.961-32.052-44.042 13.988-87.524 28.726-130.216 45.387a1606.714 1606.714 0 0 0-125.675 55.097 1600.647 1600.647 0 0 0-120.477 65.695c-39.289 23.588-77.555 48.94-115.343 75.528zM393.713 444.275a383.308 383.308 0 0 1 14.563-17.172c4.999-5.596 10.141-11.057 15.365-16.442 10.466-10.75 21.354-21.084 32.536-31.091 22.4-19.971 46.024-38.562 70.553-55.831a836.583 836.583 0 0 1 76.195-47.736c13.12-7.242 26.423-14.146 39.945-20.604 6.768-3.216 13.57-6.355 20.448-9.339a446.32 446.32 0 0 1 20.835-8.515 987.665 987.665 0 0 1-18.4 12.902l-18.481 12.625-36.948 24.996c-24.595 16.627-49.021 33.367-73.24 50.387a3321.594 3321.594 0 0 0-71.992 52.044c-11.912 8.828-23.761 17.766-35.621 26.754l-17.811 13.515a1597.439 1597.439 0 0 1-17.947 13.507zM394.681 318.676c1.843-3.003 3.827-5.863 5.873-8.676 2.037-2.817 4.156-5.553 6.308-8.26 4.318-5.397 8.851-10.586 13.516-15.641 9.362-10.074 19.302-19.556 29.712-28.485a363.39 363.39 0 0 1 32.68-25.008c5.703-3.84 11.517-7.531 17.503-10.982 3.002-1.715 6.025-3.397 9.116-4.987 3.085-1.597 6.214-3.131 9.461-4.503-2.156 2.79-4.425 5.426-6.72 8.021-2.288 2.605-4.634 5.128-6.985 7.641-4.72 5.001-9.559 9.832-14.452 14.583-9.814 9.467-19.885 18.567-30.198 27.384-10.311 8.819-20.847 17.371-31.695 25.625-5.44 4.109-10.947 8.157-16.598 12.07-2.835 1.947-5.68 3.887-8.595 5.762-2.906 1.879-5.851 3.734-8.926 5.456z",
        "p-id": "1688",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M377.385 198.376c7.314 10.42 13.067 21.728 18.192 33.278 2.505 5.8 4.857 11.673 6.954 17.642 0.531 1.49 1.042 2.987 1.542 4.489 0.529 1.601 1.014 2.927 1.52 4.539 0.979 3.108 1.859 6.175 2.617 9.317 3.056 12.519 4.389 25.521 3.754 38.388a123.34 123.34 0 0 1-2.46 19.107c-1.343 6.278-3.107 12.454-5.732 18.401-1.064-6.414-1.678-12.653-2.379-18.819a1281.01 1281.01 0 0 0-2.105-18.259c-1.469-12.039-3.251-23.862-5.484-35.695l-1.735-8.858c-0.27-1.405-0.624-3.078-0.93-4.478l-1.037-4.493c-1.406-5.988-2.791-12.004-4.25-18.017-2.814-12.069-5.852-24.104-8.467-36.542zM400.461 418.669c3.467 0.23 6.864 0.806 10.224 1.573 3.365 0.756 6.67 1.755 9.938 2.907 6.52 2.334 12.803 5.438 18.746 9.173 11.894 7.464 22.255 17.681 30.145 29.499 7.903 11.82 13.317 25.195 15.93 38.873 1.309 6.843 1.981 13.755 1.945 20.638-0.039 3.445-0.206 6.874-0.597 10.289-0.379 3.412-0.928 6.805-1.798 10.171-1.359-3.2-2.545-6.363-3.734-9.485l-3.545-9.241c-2.362-6.078-4.739-12.002-7.301-17.747-5.113-11.491-10.798-22.307-17.533-32.398-6.715-10.105-14.476-19.442-23.241-28.313-4.378-4.444-9.038-8.73-13.914-12.995-2.432-2.145-4.94-4.247-7.484-6.394-2.553-2.137-5.163-4.266-7.781-6.55zM213.98 674.63s-101.966 69.187-52.733 141.79c0 0 35.523 62.631 161.722 96.598 0 0 144.272 33.34 219.991 29.601 0 0 9.038-1.869-16.203-6.854 0 0-72.877-10.811-146.453-25.862-51.476-10.532-100.322-31.201-122.46-45.183 0 0-129.315-71.046-68.864-149.258 0 0 20.914-32.032 52.056-54.967",
        "p-id": "1689",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M535.012 942.074s48.847-108.205 75.021-251.542c0 0 17.688-104.204 0-192.57l19.944-7.041s19.941 83.071-3.116 230.147c0 0-20.753 119.558-82.45 220.829",
        "p-id": "1690",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M542.96 941.841s-1.385 0.233-3.722 0.233c-3.706 0-3.725-1.792-3.725-1.792M165.298 756.591s225.6-62.942 291.66-90.364c0 0 127.756-49.232 165.772-87.871v13.088s-109.256 83.509-222.27 112.177c0 0-131.71 39.884-235.163 59.205v-6.235z",
        "p-id": "1691",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M224.502 848.203s129.095-167.642 164.884-266.732l25.194-11.84S384.845 679.34 303.65 759.708c0 0-57.958 72.292-74.162 95.351l-4.986-6.856zM501.206 532.861s14.539 90.365-58.479 216.252c0 0-63.669 121.524-102.308 162.034h11.841s63.547-54.22 132.733-205.034c0 0 44.714-112.178 32.958-178.237l-16.745 4.985zM359.115 911.147s196.478-57.505 215.629-65.438v6.232c0 0.001-149.569 59.83-215.629 59.206z",
        "p-id": "1692",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M581.599 842.594s-136.481-18.072-211.889-88.495c0 0-83.509-62.943-50.167-143.337l-27.733 6.232s-20.566 76.654 39.262 129.626c-0.001 0 87.247 98.466 250.527 95.974zM414.58 567.138s28.667 115.293 199.425 145.207l8.726-3.74s-192.562-64.189-192.562-149.777l-15.589 8.31z",
        "p-id": "1693",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M235.098 855.059s199.9-66.06 244.919-86.626c0 0 82.264-26.798 142.714-66.059l-4.985 9.971s-56.089 38.639-150.815 75.407c0 0-100.336 41.755-236.819 72.915l4.986-5.608zM519.92 530.369s99.071 59.827 110.913 60.451v-4.363s-96.444-57.958-105.322-64.19l-5.591 8.102zM549.186 219.389s-55.458-79.146-70.416-150.815c0 0-206.281 68.553-194.44 105.322l25.76 12.556 4.154-1.961s-19.942-18.696 48.61-56.089c0 0 66.06-36.146 112.177-51.103 0 0 15.58 108.438 52.973 138.975l21.182 3.115z",
        "p-id": "1694",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M341.042 134.633l50.526 67.306 24.944 2.493-75.47-76.654z", "p-id": "1695", fill: "currentColor" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M501.206 162.054s-160.164-11.217-153.309-34.276h8.102s136.751 26.976 145.207 25.552v8.724zM456.766 206.301s48.179-37.954 50.048-38.607l-3.116-5.64s-61.386 34.808-72.759 37.658c-11.374 2.851 25.827 6.589 25.827 6.589z",
        "p-id": "1696",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M215.846 671.657c54.004-35.684 107.171-74.018 165.288-102.444 60.464-26.253 120.071-47.82 182.395-70.003 60.822-22.361 122.782-40.591 185.705-56.6 62.935-15.947 126.791-28.496 191.238-37.383l-9.76 19.962c-14.888-24.35-34.334-45.821-56.344-64.332-22.02-18.564-46.653-34.11-72.414-47.6a497.77 497.77 0 0 0-19.584-9.685c-6.597-3.106-13.241-6.132-19.963-9.003a599.898 599.898 0 0 0-20.331-8.266 695.449 695.449 0 0 0-20.608-7.678c-27.652-9.841-55.948-18.185-84.619-25.233-28.659-7.003-57.794-12.756-86.917-16.841-3.636-0.498-7.247-0.97-10.797-1.349l-11.274-1.236a2146.98 2146.98 0 0 1-22.539-2.722c-15.023-1.862-30.02-4.012-44.999-6.311-29.939-4.727-59.814-10.263-89.313-17.815-7.368-1.917-14.71-3.951-22.012-6.155-7.301-2.205-14.569-4.561-21.728-7.285-7.159-2.713-14.259-5.65-21.132-9.179-3.424-1.788-6.796-3.715-10.028-5.926-1.614-1.111-3.196-2.288-4.697-3.616a27.685 27.685 0 0 1-2.167-2.143c-0.347-0.386-0.683-0.79-1.006-1.225a11.139 11.139 0 0 1-0.477-0.691l-0.232-0.388c-0.081-0.149-0.142-0.252-0.271-0.547a1.62 1.62 0 1 1 2.971-1.294c-0.026-0.083 0.031 0.018 0.078 0.066l0.166 0.193c0.121 0.135 0.257 0.276 0.4 0.415 0.286 0.279 0.601 0.555 0.932 0.822a23.997 23.997 0 0 0 2.122 1.519c1.484 0.962 3.066 1.832 4.69 2.633 3.253 1.602 6.669 2.955 10.136 4.177 6.931 2.464 14.076 4.447 21.288 6.168 14.442 3.405 29.1 6.078 43.857 8.208 29.503 4.34 59.261 7.279 89.071 9.662 14.902 1.23 29.833 2.21 44.766 3.183l22.415 1.309 11.216 0.625c3.95 0.212 7.823 0.513 11.665 0.833 15.366 1.279 30.547 3.217 45.704 5.485 15.153 2.25 30.215 5.067 45.224 8.19 29.998 6.318 59.705 14.396 88.786 24.637 7.262 2.579 14.496 5.261 21.674 8.104a633.708 633.708 0 0 1 21.366 9.004c7.068 3.145 14.1 6.396 21.039 9.854a530.944 530.944 0 0 1 20.593 10.872 434.182 434.182 0 0 1 39.592 24.811c12.771 8.993 25.085 18.719 36.728 29.26 23.299 21.032 43.896 45.489 59.789 72.911l10.27 17.718-20.028 2.244c-63.62 7.125-126.857 18.122-189.391 32.393-62.549 14.216-124.444 32.854-185.355 53.341-60.944 20.386-120.986 42.426-179.757 68.681-29.383 13.128-58.455 26.986-87.121 41.661-14.349 7.303-28.602 14.803-42.719 22.554-14.101 7.766-28.14 15.716-41.803 24.169l-0.029 0.018a1.623 1.623 0 0 1-1.749-2.732z",
        "p-id": "1697",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M209.963 677.652c41.157-33.063 79.92-69.152 113.493-109.449 8.364-10.084 16.385-20.433 23.952-31.061 7.543-10.635 14.661-21.577 20.888-32.849a181.168 181.168 0 0 0 4.4-8.473l1.057-2.271 0.956-2.286 1.811-4.49a309.195 309.195 0 0 0 3.422-9.077 297.476 297.476 0 0 0 3.198-9.113 337.505 337.505 0 0 0 5.489-18.396c1.652-6.155 2.99-12.367 4.214-18.561a224.385 224.385 0 0 0 2.809-18.658c0.702-6.223 1.173-12.449 1.331-18.663 0.085-3.106 0.092-6.209 0.031-9.306-0.033-3.095-0.14-6.185-0.318-9.267a189.717 189.717 0 0 0-1.964-18.362c-3.604-24.317-11.887-47.708-23.759-69.25-5.903-10.798-12.843-21.048-20.365-30.862-7.569-9.773-15.963-18.979-24.838-27.453a174.746 174.746 0 0 0-6.759-6.075l-1.686-1.406-1.482-1.188c0.106 0.081-1.082-0.831-0.637-0.496l-0.115-0.103-0.231-0.206-0.462-0.414-0.945-0.897-1.87-1.811-3.696-3.662-3.535-3.875c-2.375-2.572-4.537-5.397-6.716-8.212-4.201-5.783-8.093-12.021-10.82-19.185-1.318-3.587-2.418-7.409-2.595-11.542-0.101-2.046 0.081-4.204 0.753-6.241 0.363-1.011 0.828-1.993 1.505-2.808 0.654-0.811 1.506-1.478 2.423-1.709-0.584 1.762-0.026 3.268 0.639 4.522 0.68 1.271 1.639 2.372 2.629 3.432 2.051 2.092 4.394 3.979 6.841 5.796 4.9 3.625 10.104 7.044 15.353 10.458 2.564 1.773 5.27 3.408 7.849 5.198l3.958 2.594 3.911 2.675 3.442 2.293 1.311 0.968 1.13 0.863 2.166 1.703a202.806 202.806 0 0 1 8.169 6.928c10.57 9.387 20.062 19.719 28.763 30.734 8.736 10.982 16.397 22.838 23.08 35.25 6.721 12.396 12.093 25.551 16.321 39.05 4.184 13.521 6.898 27.496 8.289 41.545 2.614 28.153-0.677 56.531-8.782 82.9-1.97 6.613-4.333 13.083-6.848 19.452-2.511 6.374-5.327 12.602-8.339 18.702a306.657 306.657 0 0 1-4.658 9.061 327.575 327.575 0 0 1-5.004 8.84l-2.606 4.37-1.301 2.118-1.119 2.175c-1.632 3.072-3.347 5.995-5.107 8.893-7.058 11.548-14.855 22.44-23.054 32.993-8.199 10.549-16.86 20.686-25.844 30.5-17.956 19.641-37.226 37.955-57.332 55.201a801.43 801.43 0 0 1-62.796 48.463z",
        "p-id": "1698",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M690.811 462.863c-11.202-10.033-23.855-19.852-35.554-29.38-11.68-9.552-23.726-18.717-36.167-27.376-6.239-4.303-12.542-8.533-18.979-12.561a597.859 597.859 0 0 0-19.576-11.684c-26.471-14.997-54.155-28.04-82.668-39.175-28.453-11.315-57.758-20.741-87.595-28.368-29.823-7.76-27.023-23.895 4.021-18.259 31.023 5.783 61.779 13.468 91.98 23.226 30.136 9.932 59.694 21.938 88.283 36.152a624.38 624.38 0 0 1 21.287 11.007c7.038 3.795 14.057 7.649 20.979 11.689 13.88 8.018 27.484 16.59 40.701 25.777 13.191 9.221 25.917 19.161 37.968 29.873a391.554 391.554 0 0 1 17.569 16.581",
        "p-id": "1699",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M504.265 210.272c8.23 19.958 13.948 41.048 17.311 62.613a281.744 281.744 0 0 1 2.469 65.623 298.03 298.03 0 0 1-1.825 16.481c-0.375 2.582-0.886 5.504-1.393 8.193a245.919 245.919 0 0 1-1.716 8.188c-2.502 10.876-5.801 21.622-10.037 31.982-4.21 10.369-9.201 20.403-14.825 29.992-5.648 9.578-11.865 18.737-18.398 27.563-6.525 8.837-13.455 17.274-20.455 25.565-7.036 8.293-14.069 16.366-21.479 24.381-14.725 16.011-30.459 31.089-46.925 45.221-16.46 14.145-33.728 27.258-51.503 39.521a661.29 661.29 0 0 1-27.092 17.716 1221.997 1221.997 0 0 1-13.843 8.358c-4.669 2.697-9.327 5.403-14.073 7.968l24.617-20.859a2431.026 2431.026 0 0 0 24.386-20.923c16.127-14.034 31.881-28.382 47.111-43.169a828.927 828.927 0 0 0 43.838-45.999c3.495-3.96 6.938-7.99 10.421-12.042 3.481-4.033 6.939-8.071 10.345-12.135a573.112 573.112 0 0 0 19.681-24.744c6.273-8.385 12.16-16.977 17.458-25.855 5.328-8.86 10.081-18.002 14.081-27.457 3.982-9.458 7.342-19.177 9.879-29.155a230.665 230.665 0 0 0 1.778-7.52c0.546-2.57 1.021-4.922 1.525-7.631a295.142 295.142 0 0 0 2.579-15.396c2.967-20.684 3.939-41.738 3.158-62.878-0.768-21.152-3.362-42.347-7.073-63.602zM654.02 238.096c2.406 8.22 3.54 16.717 3.97 25.251 0.398 8.536 0.044 17.126-1.024 25.611-0.237 2.126-0.563 4.238-0.905 6.348l-0.531 3.162-0.138 0.789-0.033 0.198-0.05 0.225-0.088 0.378-0.35 1.511a310.785 310.785 0 0 1-3.186 12.34 307.855 307.855 0 0 1-7.864 24.303c-6.02 15.967-13.436 31.479-22.234 46.085-8.762 14.632-18.667 28.462-29.248 41.57a572.384 572.384 0 0 1-16.213 19.286l-8.241 9.245-8.168 9.25c-10.93 12.319-21.915 24.936-33.998 36.728a314.736 314.736 0 0 1-38.731 32.343 373.459 373.459 0 0 1-20.948 13.78 357.946 357.946 0 0 1-21.753 12.328c12.455-11.08 24.957-21.916 36.863-33.229 11.941-11.279 23.257-22.964 33.842-35.304 10.596-12.322 20.698-25.239 31.193-38.135 2.603-3.238 5.293-6.415 7.964-9.615 2.671-3.183 5.418-6.41 8.057-9.477 5.314-6.208 10.563-12.445 15.607-18.81 10.083-12.732 19.574-25.81 27.895-39.532 8.304-13.725 15.574-28.012 21.423-42.94a289.39 289.39 0 0 0 7.998-22.721 341.978 341.978 0 0 0 3.33-11.608l0.403-1.498 0.102-0.375 0.026-0.093c0.009-0.039 0.002 0.001 0.02-0.059l0.055-0.179 0.228-0.718 0.897-2.877 1.73-5.779c2.254-7.726 4.402-15.517 6.368-23.453 1.998-7.938 3.735-16.007 5.732-24.329zM822.932 290.223c-3.33 19.547-9.583 38.631-18.054 56.813-8.486 18.183-19.401 35.294-31.819 51.028-12.424 15.755-26.229 30.216-40.597 43.842-7.168 6.592-14.612 12.882-22.511 18.844-3.939 2.983-8.016 5.854-12.26 8.554-4.248 2.697-8.631 5.262-13.38 7.397 2.298-4.671 4.889-8.992 7.58-13.212a197.146 197.146 0 0 1 8.496-12.259c5.923-7.931 12.35-15.483 19.262-22.523 13.745-13.669 27.159-27.496 39.711-41.958 12.563-14.455 24.224-29.585 34.734-45.696 10.567-16.088 19.774-33.202 28.838-50.83z",
        "p-id": "1700",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M345.965 547.814a554.561 554.561 0 0 1 25.007-24.114c8.562-7.806 17.35-15.363 26.277-22.762 17.879-14.767 36.438-28.729 55.501-41.985 38.164-26.459 78.401-50.008 120.13-70.507 41.727-20.505 84.978-37.926 129.251-51.931 22.144-6.98 44.542-13.115 67.147-18.258 11.308-2.555 22.654-4.9 34.056-6.94a594.59 594.59 0 0 1 34.343-5.212l-32.763 11.264c-10.886 3.781-21.745 7.563-32.546 11.472-21.612 7.778-43.068 15.82-64.323 24.294-42.53 16.878-84.302 35.349-125.282 55.445-40.977 20.104-81.146 41.848-120.515 65.167-19.703 11.632-39.191 23.681-58.536 36.055-19.37 12.348-38.491 25.146-57.747 38.012zM393.713 444.275c9.035-12.098 18.943-23.434 29.211-34.426 10.293-10.968 21.066-21.47 32.155-31.625 22.229-20.251 45.81-38.995 70.375-56.296a759.91 759.91 0 0 1 76.561-47.41c13.221-7.112 26.646-13.838 40.313-20.063 6.844-3.096 13.723-6.107 20.693-8.933a383.03 383.03 0 0 1 21.133-7.977c-11.965 9.213-24.18 17.829-36.34 26.475-12.179 8.606-24.398 17.063-36.577 25.538-24.396 16.885-48.696 33.723-72.875 50.714a5613.08 5613.08 0 0 0-72.171 51.577l-36 26.22-18.112 13.153a989.284 989.284 0 0 1-18.366 13.053zM394.681 318.676c1.69-3.162 3.557-6.145 5.497-9.073 1.928-2.933 3.958-5.767 6.025-8.568 4.152-5.583 8.573-10.903 13.13-16.087 9.161-10.32 19.057-19.883 29.473-28.832 10.428-8.937 21.396-17.241 32.981-24.723a248.85 248.85 0 0 1 17.886-10.531c3.083-1.617 6.188-3.195 9.378-4.66 3.183-1.474 6.417-2.872 9.798-4.069-2.021 2.964-4.184 5.736-6.381 8.455-2.19 2.729-4.453 5.356-6.722 7.967a360.601 360.601 0 0 1-14.071 15.035c-9.607 9.7-19.605 18.857-29.898 27.669-10.304 8.8-20.885 17.27-31.935 25.277-5.548 3.979-11.166 7.897-16.984 11.624-2.919 1.854-5.854 3.696-8.877 5.454-3.01 1.766-6.073 3.497-9.3 5.062z",
        "p-id": "1701",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M377.385 198.376c7.893 10.171 13.98 21.39 19.39 32.877 2.634 5.773 5.105 11.629 7.288 17.595a208.038 208.038 0 0 1 1.603 4.488c0.557 1.625 1.058 2.91 1.593 4.547 1.024 3.13 1.943 6.208 2.726 9.374 3.157 12.603 4.434 25.751 3.541 38.719a112.472 112.472 0 0 1-3.022 19.212c-1.595 6.292-3.653 12.46-6.732 18.349-1.518-6.472-2.425-12.718-3.378-18.871l-2.668-18.153c-1.728-11.938-3.566-23.616-5.697-35.365l-1.626-8.801a186.252 186.252 0 0 0-0.857-4.471l-0.974-4.493-3.917-18.063c-2.531-12.133-5.235-24.257-7.27-36.944zM400.461 418.669c3.572-0.022 7.066 0.362 10.524 0.96 3.467 0.584 6.87 1.447 10.241 2.477a89.806 89.806 0 0 1 19.348 8.694c12.266 7.308 22.957 17.621 30.989 29.654 8.052 12.031 13.415 25.727 15.745 39.667 1.187 6.97 1.588 14.02 1.273 20.998-0.19 3.494-0.52 6.966-1.107 10.417-0.573 3.448-1.335 6.87-2.48 10.256-1.634-3.18-3.034-6.314-4.417-9.401l-4.055-9.112a633.294 633.294 0 0 0-7.974-17.387c-5.396-11.228-11.132-21.724-17.718-31.604-6.573-9.891-14.004-19.131-22.397-28.158a343.862 343.862 0 0 0-13.311-13.475c-2.33-2.267-4.739-4.505-7.182-6.824-2.453-2.305-4.965-4.626-7.479-7.162zM213.98 674.63s-101.966 69.187-52.733 141.79c0 0 35.523 62.631 161.722 96.598 0 0 144.272 33.34 219.991 29.601 0 0 9.038-1.869-16.203-6.854 0 0-72.877-10.811-146.453-25.862-51.476-10.532-100.322-31.201-122.46-45.183 0 0-129.315-71.046-68.864-149.258 0 0 20.914-32.032 52.056-54.967",
        "p-id": "1702",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M535.012 942.074s48.847-108.205 75.021-251.542c0 0 17.688-104.204 0-192.57l19.944-7.041s19.941 83.071-3.116 230.147c0 0-20.753 119.558-82.45 220.829",
        "p-id": "1703",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M542.96 941.841s-1.385 0.233-3.722 0.233c-3.706 0-3.725-1.792-3.725-1.792M165.298 756.591s225.6-62.942 291.66-90.364c0 0 127.756-49.232 165.772-87.871v13.088s-109.256 83.509-222.27 112.177c0 0-131.71 39.884-235.163 59.205v-6.235z",
        "p-id": "1704",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M224.502 848.203s129.095-167.642 164.884-266.732l25.194-11.84S384.845 679.34 303.65 759.708c0 0-57.958 72.292-74.162 95.351l-4.986-6.856zM501.206 532.861s14.539 90.365-58.479 216.252c0 0-63.669 121.524-102.308 162.034h11.841s63.547-54.22 132.733-205.034c0 0 44.714-112.178 32.958-178.237l-16.745 4.985zM359.115 911.147s196.478-57.505 215.629-65.438v6.232c0 0.001-149.569 59.83-215.629 59.206z",
        "p-id": "1705",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M581.599 842.594s-136.481-18.072-211.889-88.495c0 0-83.509-62.943-50.167-143.337l-27.733 6.232s-20.566 76.654 39.262 129.626c-0.001 0 87.247 98.466 250.527 95.974zM414.58 567.138s28.667 115.293 199.425 145.207l8.726-3.74s-192.562-64.189-192.562-149.777l-15.589 8.31z",
        "p-id": "1706",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M235.098 855.059s199.9-66.06 244.919-86.626c0 0 82.264-26.798 142.714-66.059l-4.985 9.971s-56.089 38.639-150.815 75.407c0 0-100.336 41.755-236.819 72.915l4.986-5.608zM519.92 530.369s99.071 59.827 110.913 60.451v-4.363s-96.444-57.958-105.322-64.19l-5.591 8.102zM549.186 219.389s-55.458-79.146-70.416-150.815c0 0-206.281 68.553-194.44 105.322l25.76 12.556 4.154-1.961s-19.942-18.696 48.61-56.089c0 0 66.06-36.146 112.177-51.103 0 0 15.58 108.438 52.973 138.975l21.182 3.115z",
        "p-id": "1707",
        fill: "currentColor"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M341.042 134.633l50.526 67.306 24.944 2.493-75.47-76.654z", "p-id": "1708", fill: "currentColor" }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M501.206 162.054s-160.164-11.217-153.309-34.276h8.102s136.751 26.976 145.207 25.552v8.724zM456.766 206.301s48.179-37.954 50.048-38.607l-3.116-5.64s-61.386 34.808-72.759 37.658c-11.374 2.851 25.827 6.589 25.827 6.589z",
        "p-id": "1709",
        fill: "currentColor"
      }
    )
  ] });
};
const MARIADB$6 = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "3330", width: "1em", height: "1em", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    "path",
    {
      d: "M700.245333 188.245333h-376.32a323.754667 323.754667 0 0 0-0.341333 647.509334h376.661333a323.754667 323.754667 0 0 0 0-647.509334z m-8.234666 533.418667H332.202667a209.706667 209.706667 0 0 1 0-419.328h359.808a209.664 209.664 0 1 1 0 419.328z",
      "p-id": "3331",
      fill: "currentColor"
    }
  ) });
};
const MARIADB$5 = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "4398", width: "1em", height: "1em", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    "path",
    {
      d: "M733.013333 406.101333c-53.888-237.226667-180.992-315.178667-194.645333-345.002666C523.349333 40.064 507.093333 0 507.093333 0l-0.213333 2.090667v0.554666h-0.042667a24.490667 24.490667 0 0 0-0.170666 1.664v0.64h-0.085334l-0.085333 1.109334v1.109333h-0.128c-0.042667 0.341333-0.042667 0.768-0.128 1.066667v0.896h-0.085333c0 0.298667 0 0.64-0.085334 0.896v0.853333h-0.085333l-0.085333 1.365333v0.085334l-0.384 2.133333v0.341333h-0.085334l-0.128 0.512v0.725334h-0.128v0.938666h-0.213333v0.768h-0.213333v0.896h-0.170667v0.810667h-0.170667v0.725333h-0.256v0.597334h-0.170666v0.768h-0.170667v0.597333h-0.213333v0.554667H503.466667v0.64h-0.170667l-0.042667 0.170666v0.426667h-0.128l-0.042666 0.256v0.256h-0.085334a1.877333 1.877333 0 0 0-0.085333 0.426667l-0.426667 0.896v0.085333a1.28 1.28 0 0 0-0.213333 0.298667v0.341333h-0.170667v0.341333h-0.213333v0.341334h-0.128v0.426666h-0.256v0.597334h-0.170667v0.170666h-0.170666v0.341334h-0.170667v0.469333h-0.170667v0.341333h-0.256v0.469334h-0.170666v0.341333h-0.213334v0.341333h-0.128v0.426667h-0.213333v0.341333h-0.170667v0.256h-0.170666v0.341334h-0.256V32.426667h-0.170667v0.256h-0.213333v0.341333h-0.170667v0.469333h-0.213333v0.170667h-0.128v0.341333h-0.256v0.170667h-0.170667v0.426667h-0.170667v0.170666h-0.170666v0.341334h-0.213334v0.256h-0.128l-0.085333 0.170666v0.170667h-0.085333l-0.085334 0.170667v0.042666h-0.042666a0.682667 0.682667 0 0 1-0.170667 0.298667v0.128h-0.042667L496.213333 37.12v0.042667c-0.085333 0.085333-0.298667 0.256-0.384 0.426666v0.085334h-0.042666l-0.128 0.128v0.128h-0.085334l-0.128 0.128v0.042666h-0.042666l-0.128 0.170667v0.170667h-0.128l-0.085334 0.085333v0.085333h-0.085333c0 0.085333-0.085333 0.085333-0.085333 0.128v0.128h-0.170667l-0.085333 0.128V39.253333h-0.128v0.170667h-0.170667V39.68h-0.170667v0.341333h-0.213333V39.68h-0.213333v0.170667h-0.170667V40.106667h-0.213333v0.341333h-0.213334v0.170667h-0.170666v0.256h-0.170667v0.170666h-0.170667V41.386667h-0.256v0.170666h-0.170666V41.813333h-0.213334v0.170667h-0.170666v0.213333h-0.213334v0.426667h-0.085333v0.170667h-0.256v0.213333h-0.170667v0.085333h-0.170666v0.170667h-0.213334v0.426667h-0.170666v0.170666h-0.213334v0.170667h-0.170666v0.256h-0.213334v0.170667h-0.213333v0.170666h-0.170667v0.170667h-0.170666v0.426667h-0.170667v0.213333h-0.256v0.170667h-0.170667v0.170666h-0.213333v0.256h-0.170667v0.170667h-0.213333v0.298667h-0.170667v0.170666h-0.256V46.933333h-0.085333v0.170667h-0.170667v0.170667h-0.213333v0.170666h-0.170667v0.256h-0.213333v0.170667h-0.128l-0.042667 0.085333v0.085334h-0.085333l-0.170667 0.170666-0.170666 0.128v0.256h-0.170667v0.213334h-0.170667v0.170666h-0.170666v0.170667h-0.128l-0.128 0.128v0.128h-0.085334l-0.085333 0.085333v0.128h-0.085333c-0.213333 0.256-0.298667 0.426667-0.597334 0.682667a15.616 15.616 0 0 0-2.176 1.792l-0.938666 0.725333v0.042667h-0.042667a120.362667 120.362667 0 0 1-2.090667 1.664v0.042667l-3.157333 2.645333V57.173333h-0.085333c-2.432 2.005333-4.992 4.266667-7.936 6.784V64h-0.042667c-7.210667 6.314667-15.786667 14.421333-25.386667 24.234667l-0.64 0.64-0.170666 0.170666C384 149.077333 292.565333 274.176 282.922667 476.330667c-0.853333 16.725333-0.682667 32.981333 0.256 48.810666v0.384c4.650667 79.658667 29.653333 147.669333 60.928 202.922667v0.042667c12.458667 22.016 25.898667 42.026667 39.509333 59.946666v0.042667c47.018667 62.08 95.018667 98.858667 107.264 107.776 18.816 43.648 17.066667 118.570667 17.066667 118.570667l27.477333 9.173333s-5.589333-72.576 2.261333-107.605333c2.432-10.965333 8.192-20.309333 14.890667-28.245334a357.546667 357.546667 0 0 0 34.005333-27.52c0.768-0.810667 1.194667-1.536 1.877334-2.304 64.896-60.501333 186.112-209.493333 144.554666-452.224z",
      fill: "currentColor",
      "p-id": "4399"
    }
  ) });
};
const MARIADB$4 = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "5571", width: "1em", height: "1em", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M1023.786667 611.84c-0.426667 9.770667-13.354667 20.693333-39.893334 34.56-54.613333 28.458667-337.749333 144.896-397.994666 176.298667-60.288 31.402667-93.738667 31.104-141.354667 8.32-47.616-22.741333-348.842667-144.469333-403.114667-170.368-27.093333-12.970667-40.917333-23.893333-41.386666-34.218667v103.509333c0 10.325333 14.250667 21.290667 41.386666 34.261334 54.272 25.941333 355.541333 147.626667 403.114667 170.368 47.616 22.784 81.066667 23.082667 141.354667-8.362667 60.245333-31.402667 343.338667-147.797333 397.994666-176.298667 27.776-14.464 40.106667-25.728 40.106667-35.925333v-102.058667l-0.213333-0.085333z",
        fill: "currentColor",
        "p-id": "5572"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M1023.744 443.093333c-0.426667 9.770667-13.354667 20.650667-39.850667 34.517334-54.613333 28.458667-337.749333 144.896-397.994666 176.298666-60.288 31.402667-93.738667 31.104-141.354667 8.362667-47.616-22.741333-348.842667-144.469333-403.114667-170.410667-27.093333-12.928-40.917333-23.893333-41.386666-34.176v103.509334c0 10.325333 14.250667 21.248 41.386666 34.218666 54.272 25.941333 355.498667 147.626667 403.114667 170.368 47.616 22.784 81.066667 23.082667 141.354667-8.32 60.245333-31.402667 343.338667-147.84 397.994666-176.298666 27.776-14.506667 40.106667-25.770667 40.106667-35.968v-102.058667l-0.256-0.042667z",
        fill: "currentColor",
        "p-id": "5573"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M1023.744 268.074667c0.512-10.410667-13.098667-19.541333-40.490667-29.610667-53.248-19.498667-334.634667-131.498667-388.522666-151.253333-53.888-19.712-75.818667-18.901333-139.093334 3.84C392.234667 113.706667 92.629333 231.253333 39.338667 252.074667c-26.666667 10.496-39.68 20.181333-39.253334 30.506666V386.133333c0 10.325333 14.250667 21.248 41.386667 34.218667 54.272 25.941333 355.498667 147.669333 403.114667 170.410667 47.616 22.741333 81.066667 23.04 141.354666-8.362667 60.245333-31.402667 343.338667-147.84 397.994667-176.298667 27.776-14.506667 40.106667-25.770667 40.106667-35.968V268.074667h-0.341334zM366.72 366.08l237.269333-36.437333-71.68 105.088-165.546666-68.650667z m524.8-94.634667l-140.330667 55.466667-15.232 5.973333-140.245333-55.466666 155.392-61.44 140.373333 55.466666z m-411.989333-101.674666l-22.954667-42.325334 71.594667 27.989334 67.498666-22.101334-18.261333 43.733334 68.778667 25.770666-88.704 9.216-19.882667 47.786667-32.085333-53.290667-102.4-9.216 76.416-27.562666z m-176.768 59.733333c70.058667 0 126.805333 21.973333 126.805333 49.109333s-56.746667 49.152-126.805333 49.152-126.848-22.058667-126.848-49.152c0-27.136 56.789333-49.152 126.848-49.152z",
        fill: "currentColor",
        "p-id": "5574"
      }
    )
  ] });
};
const MARIADB$3 = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "7704", width: "1em", height: "1em", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M326.4 652.8c-32 0-70.4-12.8-96-38.4-25.6-25.6-44.8-64-44.8-102.4 0-38.4 12.8-70.4 38.4-102.4 51.2-51.2 147.2-51.2 198.4 0 57.6 57.6 57.6 147.2 0 198.4-19.2 32-57.6 44.8-96 44.8z m0-217.6c-19.2 0-38.4 6.4-57.6 25.6s-19.2 32-19.2 51.2 6.4 38.4 25.6 57.6c32 32 76.8 32 108.8 0s32-76.8 0-108.8c-12.8-19.2-32-25.6-57.6-25.6zM723.2 358.4c-44.8 0-83.2-19.2-108.8-51.2-51.2-64-38.4-153.6 19.2-198.4 32-25.6 64-32 102.4-32 38.4 6.4 70.4 25.6 96 51.2 25.6 32 32 64 32 102.4-6.4 38.4-25.6 70.4-51.2 96-25.6 25.6-57.6 32-89.6 32z m0-217.6c-19.2 0-32 6.4-51.2 19.2-32 25.6-38.4 70.4-6.4 108.8 25.6 32 76.8 38.4 108.8 12.8 19.2-12.8 25.6-32 32-51.2 0-19.2-6.4-38.4-19.2-57.6-12.8-19.2-32-25.6-51.2-32h-12.8zM326.4 230.4c-32 0-57.6-12.8-83.2-32s-32-51.2-32-83.2 12.8-57.6 32-83.2c44.8-44.8 121.6-44.8 160 0 19.2 19.2 32 51.2 32 83.2s0 57.6-25.6 83.2-51.2 32-83.2 32z m0-166.4c-12.8 0-25.6 6.4-32 12.8s-19.2 25.6-19.2 38.4c0 12.8 6.4 25.6 12.8 38.4 19.2 19.2 51.2 19.2 70.4 0 19.2-12.8 19.2-25.6 19.2-38.4 0-12.8-6.4-25.6-12.8-38.4-6.4-6.4-19.2-12.8-38.4-12.8zM326.4 1024c-32 0-57.6-12.8-83.2-32-44.8-44.8-44.8-115.2 0-160s121.6-44.8 160 0c44.8 44.8 44.8 115.2 0 160-12.8 19.2-44.8 32-76.8 32z m0-166.4c-12.8 0-25.6 6.4-38.4 12.8-19.2 19.2-19.2 51.2 0 70.4 19.2 19.2 51.2 19.2 70.4 0 19.2-19.2 19.2-51.2 0-70.4 0-6.4-12.8-12.8-32-12.8z",
        fill: "currentColor",
        "p-id": "7705"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M435.2 492.8c-6.4 0-19.2-6.4-25.6-12.8-12.8-12.8-12.8-32 6.4-44.8l198.4-153.6c12.8-12.8 32-6.4 44.8 6.4 12.8 12.8 6.4 32-6.4 44.8L454.4 486.4c-6.4 6.4-12.8 6.4-19.2 6.4zM723.2 947.2c-32 0-64-12.8-89.6-32-64-51.2-70.4-140.8-25.6-198.4 51.2-64 140.8-70.4 198.4-25.6 64 51.2 70.4 140.8 25.6 198.4-25.6 38.4-64 57.6-108.8 57.6z m0-217.6c-25.6 0-44.8 12.8-64 32-25.6 32-19.2 83.2 12.8 108.8 32 25.6 83.2 19.2 108.8-12.8 25.6-32 19.2-83.2-12.8-108.8-6.4-19.2-25.6-19.2-44.8-19.2z",
        fill: "currentColor",
        "p-id": "7706"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M633.6 748.8c-6.4 0-12.8 0-19.2-6.4L416 588.8c-19.2-12.8-19.2-32-6.4-44.8 12.8-12.8 32-19.2 44.8-6.4l198.4 153.6c12.8 12.8 19.2 32 6.4 44.8-6.4 12.8-19.2 12.8-25.6 12.8zM326.4 428.8c-19.2 0-32-12.8-32-32V211.2c0-19.2 12.8-32 32-32s32 12.8 32 32v185.6c0 19.2-12.8 32-32 32zM326.4 851.2c-19.2 0-32-12.8-32-32V633.6c0-19.2 12.8-32 32-32s32 12.8 32 32v185.6c0 19.2-12.8 32-32 32z",
        fill: "currentColor",
        "p-id": "7707"
      }
    )
  ] });
};
const MARIADB$2 = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "6623", width: "1em", height: "1em", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M672.646021 347.695881q25.859842 25.859842 0 51.719685L414.048597 658.01099q-25.859842 25.859842-51.719685 0t0-51.719685l258.598424-258.597424q25.858842-25.859842 51.718685 0z",
        fill: "currentColor",
        "p-id": "6624"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M959.121275 64.949604a221.621649 221.621649 0 0 0-313.41509 0L450.416375 260.314414a39.130762 39.130762 0 0 0 0 55.588661 39.057762 39.057762 0 0 0 55.587662 0l195.289809-195.436809a143.139128 143.139128 0 0 1 244.149513 101.156383c0 38.252767-14.920909 74.166548-41.983744 101.155384L708.315804 518.140843a39.130762 39.130762 0 0 0 27.79383 66.997591 39.42376 39.42376 0 0 0 27.794831-11.40993l195.28881-195.435809a221.767649 221.767649 0 0 0-0.072-313.342091zM322.781153 903.601494c-26.989836 26.989836-62.901617 41.983744-101.082384 41.983744a141.530138 141.530138 0 0 1-101.082384-41.983744 142.627131 142.627131 0 0 1-0.073-202.238768l195.28881-195.362809a39.130762 39.130762 0 0 0 0-55.588662 39.057762 39.057762 0 0 0-55.587661 0L64.955724 645.628066A220.304658 220.304658 0 0 0 0.00612 802.372111c0 59.244639 23.03986 114.979299 64.949604 156.744044a220.816654 220.816654 0 0 0 156.671045 64.876605c56.758654 0 113.589308-21.649868 156.598046-64.876605L573.659624 763.825345a39.42376 39.42376 0 0 0-55.587661-55.587661L322.781153 903.600494z",
        fill: "currentColor",
        "p-id": "6625"
      }
    )
  ] });
};
const MARIADB$1 = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "9216", width: "1em", height: "1em", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "path",
      {
        d: "M192 128h-128v768h896V384h-384V128h-128v256h-256V128zM384 320v-256h256v256h384v640H0V64h256v256h128z",
        fill: "currentColor",
        "p-id": "9217"
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx("path", { d: "M640 576v128h128v-128H640zM576 512h256v256h-256V512z", fill: "currentColor", "p-id": "9218" })
  ] });
};
const MARIADB = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { viewBox: "0 0 1024 1024", version: "1.1", xmlns: "http://www.w3.org/2000/svg", "p-id": "10324", width: "1em", height: "1em", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    "path",
    {
      d: "M561.4592 13.5168l356.864 206.848c29.952 18.0224 47.9744 50.9952 47.9744 86.9888v413.7984c0 35.9936-18.0224 68.9664-47.9744 86.9376l-356.864 206.8992c-11.9808 5.9904-29.952 9.0112-47.9744 9.0112-17.9712 0-32.9728-3.0208-47.9744-11.9808l-359.8336-206.8992a100.608 100.608 0 0 1-47.9744-86.9888V307.3536c0-35.9936 18.0224-68.9664 47.9744-86.9376L462.5408 13.5168a97.4336 97.4336 0 0 1 98.9184 0z m-47.9744 56.9344c-5.9904 0-8.96 0-15.0016 3.0208l-356.8128 206.848a31.488 31.488 0 0 0-15.0016 27.0336v413.7984c0 11.9808 6.0416 20.992 15.0016 26.9824l356.864 206.8992c8.96 5.9904 20.992 5.9904 29.952 0l356.864-209.92a31.488 31.488 0 0 0 14.9504-26.9824V307.3536a31.488 31.488 0 0 0-15.0016-26.9824l-356.8128-206.8992c-2.9696 0-9.0112-3.0208-15.0016-3.0208z m236.9024 581.7344c20.992 0 38.9632 17.9712 35.9936 35.9936 0 20.992-15.0016 35.9424-35.9936 35.9424h-395.776a36.4544 36.4544 0 0 1-35.9936-35.9424c0-20.992 14.9504-35.9936 35.9424-35.9936zM615.424 478.208c18.0224 0 33.024 18.0224 33.024 35.9936s-15.0016 32.9728-33.024 35.9936H276.6336a36.4544 36.4544 0 0 1-35.9936-35.9936c0-20.992 15.0016-35.9936 35.9936-35.9936z m134.9632-176.896c20.992 0 38.9632 17.9712 35.9936 35.9936 0 20.992-15.0016 35.9424-35.9936 35.9424h-395.776a36.4544 36.4544 0 0 1-35.9936-35.9424c0-20.992 14.9504-35.9936 35.9424-35.9936z",
      fill: "currentColor",
      "p-id": "10325"
    }
  ) });
};
const component = {
  POSTGRESQL: POSTGRESQL$1,
  MARIADB: MARIADB$8,
  EMQX: MARIADB,
  KAFKA: MARIADB$3,
  MONGODB: MARIADB$5,
  MYSQL: POSTGRESQL,
  ORACLE: MARIADB$6,
  REDIS: MARIADB$4,
  RABBITMQ: MARIADB$1,
  SQLSERVER: MARIADB$7,
  WEBSOCKET: MARIADB$2
};
const IconTitle = ({ type, label, style, textStyle, showTitle = true }) => {
  return showTitle ? /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { gap: 8, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { component: component[type] || MARIADB, style }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { style: textStyle, children: label || type })
  ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { component: component[type] || MARIADB, style });
};
const IconCom = () => {
  var _a;
  const type = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useWatch("type", { preserve: true });
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { justify: "center", align: "center", style: { height: 40, fontSize: 24, fontWeight: "bold", marginBottom: 24 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    IconTitle,
    {
      label: (_a = connectTypeList.find((f2) => f2.value === type)) == null ? void 0 : _a.label,
      type,
      style: {
        fontSize: 24,
        color: "var(--supos-theme-color)"
      }
    }
  ) });
};
function filterTree(data, parentValue, childLabel) {
  return data.filter((item) => !parentValue || item.value === parentValue).map((item) => {
    if (!childLabel) {
      return { ...item };
    }
    const filteredChildren = item.children.filter(
      (child) => child.label.toLowerCase().includes(childLabel.toLowerCase())
    );
    return { ...item, children: filteredChildren };
  }).filter((item) => item.children.length > 0);
}
const DataBaseItem = ({ defaultValue, value, onChange }) => {
  const formatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const [v, setV] = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.usePropsValue({
    value,
    onChange,
    defaultValue
  });
  const [typeValue, setTypeValue] = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useState();
  const [labelValue, setLabelValue] = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useState();
  const [tree, setTree] = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useState(connectTypeTree);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { vertical: true, gap: 16, className: "dataBase", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { gap: 8, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComSelect,
        {
          value: typeValue,
          onChange: (v2) => setTypeValue(v2),
          allowClear: true,
          options: connectTypeTree == null ? void 0 : connectTypeTree.map((item) => ({
            ...item,
            label: formatMessage(item.label)
          })),
          style: { width: 140, flexShrink: 0 }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComInput,
        {
          placeholder: formatMessage("connectPlaceholder"),
          value: labelValue,
          onChange: (e) => setLabelValue(e.target.value),
          onPressEnter: () => {
            setTree(filterTree(connectTypeTree, typeValue, labelValue));
          }
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Button,
        {
          onClick: () => {
            setTree(filterTree(connectTypeTree, typeValue, labelValue));
          },
          children: commonFormatMessage("common.search")
        }
      )
    ] }),
    (tree == null ? void 0 : tree.length) === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Empty, {}) : /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Radio.Group, { value: v, onChange: (e) => setV(e.target.value), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { vertical: true, gap: 16, children: tree == null ? void 0 : tree.map((l2) => {
      var _a;
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { className: "typeLabel", children: formatMessage(l2.label) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { gap: 8, wrap: true, children: (_a = l2.children) == null ? void 0 : _a.map((c) => {
          return /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "dataLabel",
              style: {
                "--border-color": v === c.value ? "var(--supos-theme-color)" : "var(--supos-switchwrap-bg-color)",
                width: "calc((100% - 16px) / 3)"
              },
              onClick: () => setV(c.value),
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Radio, { value: c.value, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                IconTitle,
                {
                  label: c.label,
                  type: c.value,
                  style: {
                    color: v === c.value ? "var(--supos-theme-color)" : void 0,
                    fontSize: 14
                  },
                  textStyle: {
                    color: v === c.value ? "var(--supos-theme-color)" : void 0
                  }
                }
              ) })
            },
            c.value
          );
        }) })
      ] }, l2.value);
    }) }) })
  ] });
};
const BaseInfo = () => {
  var _a;
  const type = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useWatch("type", { preserve: true });
  const config = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useMemo(() => {
    return connectSourceFormConfigs == null ? void 0 : connectSourceFormConfigs.find((f2) => f2.type === type);
  }, [type]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(RenderItems, { formData: (_a = config == null ? void 0 : config.baseInfo) == null ? void 0 : _a.formItems });
};
const Item = ({ name, items }) => {
  const authenticationType = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useWatch(name, { preserve: true });
  const formData = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useMemo(() => {
    var _a;
    return (_a = items == null ? void 0 : items.find((f2) => f2.value === authenticationType)) == null ? void 0 : _a.formItems;
  }, [authenticationType, items]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(RenderItems, { formData });
};
const ControlledSelect = ({ item }) => {
  var _a;
  const form = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useFormInstance();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.Item, { ...item.formProps, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Select, { ...item.childProps, onChange: (value, options) => {
      var _a2, _b;
      return (_b = (_a2 = item.childProps) == null ? void 0 : _a2.onChange) == null ? void 0 : _b.call(_a2, value, options, form);
    } }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(Item, { name: item.formProps.name, items: (_a = item.childProps) == null ? void 0 : _a.options })
  ] });
};
const render$1 = (item, formatMessage) => {
  const { formType, childProps = {} } = item;
  switch (formType) {
    case "input":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Input,
        {
          ...childProps,
          placeholder: (childProps == null ? void 0 : childProps.placeholder) ? formatMessage(childProps == null ? void 0 : childProps.placeholder) : void 0
        }
      );
  }
};
const FormList = ({
  name,
  style,
  titleKey,
  formItems = [],
  onChange,
  rules
}) => {
  const form = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useFormInstance();
  const formatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const watchedValue = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useWatch(name);
  supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useEffect(() => {
    onChange == null ? void 0 : onChange((watchedValue == null ? void 0 : watchedValue.filter((f2) => f2)) || [], form);
  }, [watchedValue, onChange]);
  if (!name) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      style: {
        border: "1px dashed rgb(198, 198, 198)",
        borderRadius: 6,
        padding: 20,
        ...style
      },
      children: [
        titleKey && /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex,
          {
            style: {
              fontWeight: "600",
              fontSize: 14,
              marginBottom: 16
            },
            justify: "flex-start",
            children: formatMessage(titleKey)
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.List,
          {
            name,
            rules: rules ? [
              {
                validator: (_, names) => {
                  if (!names || names.length < 1) {
                    return Promise.reject(new Error(formatMessage("Connection.mustOne")));
                  }
                  return Promise.resolve();
                }
              }
            ] : [],
            children: (items, { add, remove }, { errors }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
              items.map(({ key, name: name2, ...restField }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { gap: 8, children: [
                formItems == null ? void 0 : formItems.map((f2) => /* @__PURE__ */ supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.createElement(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.Item, { ...restField, ...f2.formProps, name: [name2, f2.formProps.name], key: f2.formProps.name }, render$1(f2, formatMessage))),
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Button,
                  {
                    color: "default",
                    variant: "filled",
                    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.SubtractAlt, {}),
                    onClick: () => {
                      remove(name2);
                    },
                    style: {
                      border: "1px solid #CBD5E1",
                      color: "var(--supos-text-color)",
                      backgroundColor: "var(--supos-uns-button-color)"
                    }
                  }
                )
              ] }, key)),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Button,
                {
                  color: "default",
                  variant: "filled",
                  onClick: () => {
                    add();
                  },
                  block: true,
                  style: { color: "var(--supos-text-color)", backgroundColor: "var(--supos-uns-button-color)" },
                  icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.AddAlt, { size: 20 })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.ErrorList, { errors })
            ] })
          }
        )
      ]
    }
  );
};
const render = (item, formatMessage, form) => {
  const { formType, formProps = {}, childProps = {} } = item;
  const key = formProps.name;
  const { labelCode, ...restFormProps } = formProps;
  const label = labelCode ? formatMessage(labelCode) : formProps.label;
  const _formProps = {
    ...restFormProps,
    label
  };
  switch (formType) {
    case "type":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.Item, { name: "type", noStyle: true, children: /* @__PURE__ */ jsxRuntimeExports.jsx(DataBaseItem, { ...childProps }) }, key);
    case "input":
      return /* @__PURE__ */ supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.createElement(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.Item, { ..._formProps, key }, /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Input, { ...childProps, onChange: (e) => {
        var _a;
        return (_a = childProps == null ? void 0 : childProps.onChange) == null ? void 0 : _a.call(childProps, e, form);
      } }));
    case "divider":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Divider, { style: { borderColor: "#c6c6c6" } }, key);
    case "password":
      return /* @__PURE__ */ supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.createElement(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.Item, { ..._formProps, key }, /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Input.Password,
        {
          autoComplete: "new-password",
          ...childProps,
          onChange: (e) => {
            var _a;
            return (_a = childProps == null ? void 0 : childProps.onChange) == null ? void 0 : _a.call(childProps, e, form);
          }
        }
      ));
    case "textArea":
      return /* @__PURE__ */ supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.createElement(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.Item, { ..._formProps, key }, /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Input.TextArea, { ...childProps, onChange: (e) => {
        var _a;
        return (_a = childProps == null ? void 0 : childProps.onChange) == null ? void 0 : _a.call(childProps, e, form);
      } }));
    case "select":
      return /* @__PURE__ */ supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.createElement(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.Item, { ..._formProps, key }, /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComSelect, { ...childProps, onChange: (v, options) => {
        var _a;
        return (_a = childProps == null ? void 0 : childProps.onChange) == null ? void 0 : _a.call(childProps, v, options, form);
      } }));
    case "icon":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(IconCom, {}, key);
    case "baseInfo":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(BaseInfo, {}, key);
    case "controlledSelect":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(ControlledSelect, { item: { ...item, formProps: _formProps } }, key);
    case "formList":
      return /* @__PURE__ */ jsxRuntimeExports.jsx(FormList, { name: key, rules: formProps.rules, ...childProps }, key);
  }
};
const RenderItems = ({ formData = [] }) => {
  const formatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const form = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useFormInstance();
  if (!(formData == null ? void 0 : formData.length)) return null;
  return /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: formData == null ? void 0 : formData.map((item) => {
    if (item.formType === "custom") {
      return item.component;
    }
    return render(item, formatMessage, form);
  }) });
};
const FormContent = ({ step }) => {
  const formatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const form = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useFormInstance();
  const getFormData = ({ currentStep }) => {
    const formItemList = [];
    if (currentStep === 1) {
      formItemList.push(
        // 类型
        {
          formType: "type",
          formProps: {
            name: "type"
          },
          childProps: {
            onChange(type) {
              var _a;
              form.setFieldsValue({
                ...initFormConfig(form.getFieldsValue(true)),
                ...initBaseConfig[type],
                type,
                category: (_a = connectTypeList == null ? void 0 : connectTypeList.find((v) => v.value === type)) == null ? void 0 : _a.parentId
              });
            }
          }
        },
        // 数据库类型 隐藏字段
        {
          formType: "input",
          formProps: {
            name: "category",
            hidden: true
          }
        }
      );
    }
    if (currentStep === 2) {
      formItemList.push(
        {
          formType: "icon",
          formProps: {
            name: "icon"
          }
        },
        {
          formType: "input",
          formProps: {
            name: "alias",
            label: formatMessage("common.name"),
            rules: [
              { required: true, message: formatMessage("uns.pleaseInputName") },
              { pattern: /^[\u4e00-\u9fa5a-zA-Z0-9_-]+$/, message: formatMessage("uns.nameFormat") },
              {
                max: 30,
                message: formatMessage("uns.labelMaxLength", { label: formatMessage("common.name"), length: 30 })
              }
            ]
          }
        },
        {
          formType: "textArea",
          formProps: {
            name: "description",
            label: formatMessage("common.description"),
            rules: [
              {
                max: 255,
                message: formatMessage("uns.labelMaxLength", {
                  label: formatMessage("common.description"),
                  length: 255
                })
              }
            ]
          },
          childProps: { rows: 2 }
        },
        {
          formType: "divider",
          formProps: {
            name: "bottomDivider"
          }
        },
        {
          formType: "baseInfo",
          formProps: {
            name: "baseInfo"
          }
        }
      );
    }
    return formItemList;
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(RenderItems, { formData: getFormData({ currentStep: step }) });
};
const useCreateDrawer = ({ refreshRequest }) => {
  const commonFormatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const formatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [form] = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.useForm();
  const [step, setStep] = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useState(1);
  const [open, setOpen] = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useState(false);
  const [title, setTitle] = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useState("");
  const [disablePre, setDisablePre] = supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.useState(false);
  const openDrawer = ({ type, step: step2, id }) => {
    setDisablePre(!!id);
    setTitle(formatMessage(type));
    setOpen(true);
    if (step2) {
      setStep(step2);
    } else {
      setStep(1);
    }
    if (id || id === 0) {
      getDetailApi(id).then((data) => {
        var _a, _b, _c;
        form.setFieldsValue({
          ...data.config,
          id: type === "edit" ? id : void 0,
          category: data.category,
          description: data.description,
          alias: type === "copy" ? data.config.alias + "_copy" : data.config.alias,
          // kafka特殊配置
          nodes: (data == null ? void 0 : data.config.nodes) ? (_b = (_a = data == null ? void 0 : data.config) == null ? void 0 : _a.nodes) == null ? void 0 : _b.map((node) => {
            const [host, port] = node.split(":");
            return {
              host,
              port
            };
          }) : void 0,
          // websocket特殊配置
          headers: ((_c = data == null ? void 0 : data.config) == null ? void 0 : _c.headers) ? objectToArray(data.config.headers) : void 0
        });
      });
    }
  };
  const onClose = () => {
    setOpen(false);
    setStep(1);
    form.resetFields();
  };
  const Dom = /* @__PURE__ */ jsxRuntimeExports.jsx(
    supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Drawer,
    {
      rootClassName: "useCreateDrawer",
      title,
      closable: false,
      maskClosable: false,
      destroyOnHidden: false,
      open,
      width: 680,
      extra: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Tooltip, { title: commonFormatMessage("common.close"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Button, { color: "default", variant: "text", onClick: onClose, icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Close, { size: 20 }) }) }),
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form, { form, colon: false, labelCol: { span: 4 }, wrapperCol: { span: 20 }, labelAlign: "left", labelWrap: true, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Form.Item, { hidden: true, name: "id", children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Input, {}) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(FormContent, { step }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          FormStep,
          {
            disablePre,
            step,
            setStep,
            setOpen,
            refreshRequest
          }
        )
      ] })
    }
  );
  return {
    openDrawer,
    CreateDrawer: Dom
  };
};
const StatusOptions = [
  {
    value: 0,
    label: "pendingLine",
    color: "orange"
  },
  {
    value: 1,
    label: "online",
    color: "green"
  },
  {
    value: 2,
    label: "offline",
    color: "#E0E0E0"
  }
];
const CardTag = ({ status }) => {
  const formatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const info = (StatusOptions == null ? void 0 : StatusOptions.find((f2) => f2.value === status)) ?? {
    label: "offline",
    color: "orange"
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { align: "center", justify: "flex-start", gap: 4, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
    supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Tag,
    {
      bordered: false,
      color: info == null ? void 0 : info.color,
      title: formatMessage(info == null ? void 0 : info.label),
      style: {
        borderRadius: 9,
        height: 16,
        lineHeight: "16px",
        maxWidth: 120,
        overflow: "hidden",
        whiteSpace: "nowrap",
        textOverflow: "ellipsis"
      },
      children: formatMessage(info == null ? void 0 : info.label)
    }
  ) });
};
const Connection = ({ title }) => {
  const commonFormatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const formatMessage = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [mode, setMode] = supos_mf_2_ce_mf_1_Connection__loadShare__ahooks__loadShare__.useLocalStorageState("SUPOS_CONNECTION_MODE", {
    defaultValue: "card"
  });
  const { message, modal } = supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.App.useApp();
  const navigate = supos_mf_2_ce_mf_1_Connection__loadShare__react_mf_2_router_mf_2_dom__loadShare__.useNavigate();
  const { loading, pagination, data, setSearchParams, refreshRequest } = supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.usePagination({
    fetchApi: pageListApi,
    autoRefresh: true,
    initPageSize: 18
  });
  const { CreateDrawer, openDrawer } = useCreateDrawer({
    refreshRequest
  });
  const onAddHandle = () => {
    openDrawer({ type: "add" });
  };
  const columns = [
    {
      dataIndex: "name",
      ellipsis: true,
      title: () => commonFormatMessage("common.name"),
      width: "120px",
      render: (text, d) => {
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            IconTitle,
            {
              type: d.dsType,
              showTitle: false,
              style: {
                fontSize: 16,
                color: "var(--supos-theme-color)",
                marginRight: 8
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { title: text, children: text })
        ] });
      }
    },
    {
      dataIndex: "category",
      ellipsis: true,
      title: () => formatMessage("dataSourceType"),
      width: "120px",
      render: (category) => {
        var _a;
        return formatMessage((_a = connectTypeTree.find((f2) => f2.value === category)) == null ? void 0 : _a.label);
      }
    },
    {
      dataIndex: "dsType",
      ellipsis: true,
      title: () => formatMessage("type"),
      width: "120px",
      render: (dsType) => {
        var _a;
        return (_a = connectTypeList.find((f2) => f2.value === dsType)) == null ? void 0 : _a.label;
      }
    },
    {
      dataIndex: "description",
      ellipsis: true,
      title: () => commonFormatMessage("common.description"),
      width: "240px"
    },
    {
      dataIndex: "createAt",
      ellipsis: true,
      title: () => commonFormatMessage("common.creationTime"),
      width: "160px",
      render: (t) => supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.formatTimestamp(t)
    },
    {
      dataIndex: "updateAt",
      ellipsis: true,
      title: () => commonFormatMessage("common.latestUpdate"),
      width: "160px",
      render: (t) => supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.formatTimestamp(t)
    },
    {
      dataIndex: "connectivityStatus",
      ellipsis: true,
      title: () => formatMessage("isItOnline"),
      width: "100px",
      render: (connectivityStatus) => /* @__PURE__ */ jsxRuntimeExports.jsx(CardTag, { status: connectivityStatus })
    }
  ];
  const actions = (record) => {
    var _a;
    if (record.id === 0) {
      return [
        {
          key: "sqlEditorOpen",
          auth: ButtonPermission["Connection.sqlEditorOpen"],
          button: {
            style: { color: "var(--supos-theme-color)" }
          },
          onClick: () => {
            var _a2, _b;
            const params = new URLSearchParams();
            if (record.externalId !== void 0) params.append("dataSourceId", record.externalId);
            if (((_a2 = record.config) == null ? void 0 : _a2.database) !== void 0) params.append("databaseName", record.config.database);
            if (((_b = record.config) == null ? void 0 : _b.type) !== void 0) params.append("databaseType", record.config.type);
            const url = `/SQLEditor${params.toString() ? "?" + params.toString() : ""}`;
            navigate(url);
          },
          label: formatMessage("sqlEditorOpen")
        },
        {
          key: "copy",
          label: formatMessage("copy"),
          auth: ButtonPermission["Connection.copy"],
          button: {
            style: { color: "var(--supos-theme-color)" }
          },
          onClick: () => openDrawer({ type: "copy", step: 2, id: record.id })
        }
      ];
    }
    return [
      {
        key: "edit",
        label: formatMessage("edit"),
        auth: ButtonPermission["Connection.edit"],
        button: {
          type: "primary",
          variant: "variant"
        },
        onClick: () => openDrawer({ type: "edit", step: 2, id: record.id })
      },
      ((_a = connectTypeList == null ? void 0 : connectTypeList.find((f2) => f2.value === record.dsType)) == null ? void 0 : _a.sqlEdit) ? {
        key: "sqlEditorOpen",
        auth: ButtonPermission["Connection.sqlEditorOpen"],
        button: {
          style: { color: "var(--supos-theme-color)" }
        },
        onClick: () => {
          var _a2, _b;
          const params = new URLSearchParams();
          if (record.externalId !== void 0) params.append("dataSourceId", record.externalId);
          if (((_a2 = record.config) == null ? void 0 : _a2.database) !== void 0) params.append("databaseName", record.config.database);
          if (((_b = record.config) == null ? void 0 : _b.type) !== void 0) params.append("databaseType", record.config.type);
          const url = `/SQLEditor${params.toString() ? "?" + params.toString() : ""}`;
          navigate(url);
        },
        label: formatMessage("sqlEditorOpen")
      } : null,
      {
        key: "copy",
        label: formatMessage("copy"),
        auth: ButtonPermission["Connection.copy"],
        button: {
          style: { color: "var(--supos-theme-color)" }
        },
        onClick: () => openDrawer({ type: "copy", step: 2, id: record.id })
      },
      {
        key: "delete",
        label: formatMessage("delete"),
        auth: ButtonPermission["Connection.delete"],
        button: {},
        onClick: () => modal.confirm({
          title: commonFormatMessage("common.deleteConfirm"),
          onOk: () => {
            return deleteApi(record.id).then(() => {
              message.success(commonFormatMessage("common.optsuccess"));
              refreshRequest == null ? void 0 : refreshRequest();
            });
          },
          okButtonProps: {
            title: commonFormatMessage("common.confirm")
          },
          cancelButtonProps: {
            title: commonFormatMessage("common.cancel")
          }
        })
      }
    ];
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComLayout, { loading, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
    {
      title: /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { align: "center", gap: 8, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Platforms, { size: 20, style: { justifyContent: "center", verticalAlign: "middle" } }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: title })
      ] }),
      hasBack: false,
      style: {
        overflow: "hidden",
        display: "flex",
        flexDirection: "column",
        height: "100%"
      },
      className: styles["connection"],
      extra: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton, { auth: ButtonPermission["Connection.add"], type: "primary", onClick: onAddHandle, children: formatMessage("add") }),
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { justify: "flex-end", align: "center", style: { marginBottom: 16, marginTop: 16, paddingRight: 16 }, gap: 8, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComSelect,
            {
              onChange: (v) => {
                setSearchParams(
                  {
                    category: v
                  },
                  false
                );
              },
              size: "small",
              style: { width: 150 },
              options: connectTypeTree == null ? void 0 : connectTypeTree.map((item) => ({
                ...item,
                label: formatMessage(item.label)
              })),
              allowClear: true,
              showSearch: true
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComInput,
            {
              placeholder: commonFormatMessage("common.searchPlaceholder"),
              onChange: supos_mf_2_ce_mf_1_Connection__loadShare__lodash__loadShare__.debounce((e, isCompose) => {
                var _a;
                if (!isCompose) {
                  setSearchParams(
                    {
                      keyword: (_a = e == null ? void 0 : e.target) == null ? void 0 : _a.value
                    },
                    false
                  );
                }
              }, 500),
              size: "small",
              style: { width: 150 }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Segmented,
            {
              size: "small",
              value: mode,
              onChange: (v) => setMode(v),
              options: [
                {
                  value: "card",
                  icon: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles["flex"], title: commonFormatMessage("common.cardMode"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Grid, {}) })
                },
                {
                  value: "list",
                  icon: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles["flex"], title: commonFormatMessage("common.listMode"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.List, {}) })
                }
              ]
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { flex: 1, padding: "0 16px 16px", overflow: "auto" }, children: mode === "card" ? (data == null ? void 0 : data.length) > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ProCardContainer, { children: data == null ? void 0 : data.map((d) => {
          var _a, _b;
          return /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ProCard,
            {
              statusHeader: {
                statusTag: /* @__PURE__ */ jsxRuntimeExports.jsx(CardTag, { status: d.connectivityStatus })
              },
              header: {
                title: d.name,
                titleDescription: supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.formatTimestamp(d == null ? void 0 : d.createAt) || " ",
                customIcon: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  IconTitle,
                  {
                    showTitle: false,
                    type: d.dsType,
                    style: {
                      fontSize: 24,
                      color: "var(--supos-theme-color)"
                    }
                  }
                )
              },
              description: d == null ? void 0 : d.description,
              secondaryDescription: /* @__PURE__ */ jsxRuntimeExports.jsx(
                supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.SecondaryList,
                {
                  options: [
                    {
                      label: formatMessage("dataSourceType"),
                      content: formatMessage((_a = connectTypeTree.find((f2) => f2.value === d.category)) == null ? void 0 : _a.label),
                      span: 12,
                      key: "category"
                    },
                    {
                      label: formatMessage("type"),
                      content: (_b = connectTypeList.find((f2) => f2.value === d.dsType)) == null ? void 0 : _b.label,
                      span: 12,
                      key: "dsType"
                    }
                  ],
                  dsType: d.dsType,
                  category: d.category
                }
              ),
              item: d,
              actions
            },
            d.id
          );
        }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Flex, { style: { width: "100%" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Empty, { style: { width: "100%" } }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_Connection__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ProTable,
          {
            resizeable: true,
            style: { height: "100%" },
            scroll: { y: "calc(100vh  - 285px)", x: "max-content" },
            dataSource: data,
            columns,
            operationOptions: {
              render: actions
            },
            pagination: {
              total: pagination == null ? void 0 : pagination.total,
              pageSize: (pagination == null ? void 0 : pagination.pageSize) || 18,
              current: pagination == null ? void 0 : pagination.page,
              showQuickJumper: true,
              pageSizeOptions: pagination.pageSizes,
              showSizeChanger: true,
              onChange: pagination.onChange,
              onShowSizeChange: (current, size) => {
                pagination.onChange({ page: current, pageSize: size });
              }
            }
          }
        ) }),
        mode === "card" && /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_Connection__loadShare__antd__loadShare__.Pagination,
          {
            size: "small",
            className: "custom-pagination",
            align: "center",
            style: { margin: "20px 0" },
            total: pagination == null ? void 0 : pagination.total,
            showSizeChanger: false,
            onChange: pagination.onChange,
            pageSize: (pagination == null ? void 0 : pagination.pageSize) || 20,
            current: pagination == null ? void 0 : pagination.page
          }
        ),
        CreateDrawer
      ]
    }
  ) });
};
const App = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Connection
}, Symbol.toStringTag, { value: "Module" }));
export {
  App as A,
  Connection as C,
  jsxRuntimeExports as j,
  supos_mf_2_ce_mf_1_Connection__loadShare__react_mf_2_router_mf_2_dom__loadShare__ as s
};
