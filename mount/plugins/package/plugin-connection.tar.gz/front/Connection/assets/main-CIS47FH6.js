import "./hostInit-C7K9GhQd.js";
import "./supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__-UFkmriww.js";
import { j as jsxRuntimeExports, s as supos_mf_2_ce_mf_1_Connection__loadShare__react_mf_2_router_mf_2_dom__loadShare__, C as Connection } from "./App-cAthUtPb.js";
import { s as supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__-C1C8WqCv.js";
import { s as supos_mf_2_ce_mf_1_Connection__loadShare__react_mf_2_dom__loadShare__ } from "./supos_mf_2_ce_mf_1_Connection__loadShare__react_mf_2_dom__loadShare__-Bj9B9w_U.js";
import "./preload-helper-BaJ0u6Ce.js";
import "./supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__-BzNwQxr7.js";
import "./_commonjsHelpers-DWwsNxpa.js";
var createRoot;
var m = supos_mf_2_ce_mf_1_Connection__loadShare__react_mf_2_dom__loadShare__;
{
  createRoot = m.createRoot;
  m.hydrateRoot;
}
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__react__loadShare__.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Connection__loadShare__react_mf_2_router_mf_2_dom__loadShare__.BrowserRouter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Connection, { title: "" }) }) })
);
