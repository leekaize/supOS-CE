import { g as getDefaultExportFromCjs } from "./_commonjsHelpers-DWwsNxpa.js";
import { s as supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__, a as index_cjs } from "./supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__-UFkmriww.js";
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_Connection__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("@ant-design/icons", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "6.0.0"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__ = exportModule;
const Icon = /* @__PURE__ */ getDefaultExportFromCjs(supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__);
export {
  Icon as I,
  supos_mf_2_ce_mf_1_Connection__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__ as s
};
