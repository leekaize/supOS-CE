const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-B0OThK7f.js","assets/_commonjsHelpers-DWwsNxpa.js","assets/index-DCk8YTfP.js","assets/supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__-X4nl10Rf.js","assets/supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__-Br6ZSoi8.js","assets/supos_mf_2_ce_mf_1_Alert__loadShare__react_mf_2_dom__loadShare__-mgRSoRK_.js","assets/index-B8F3w5s0.js","assets/index-BHdSYc92.js","assets/DownloadOutlined-Ce42J_hp.js","assets/index-C0g94wjF.js","assets/index-BbK4DbHP.js"])))=>i.map(i=>d[i]);
import { i as index_cjs, s as supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__ } from "./supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__-Br6ZSoi8.js";
import exposesMap from "./virtualExposes-C42d6ioz.js";
import { _ as __vitePreload } from "./preload-helper-PAP2FNEz.js";
const importMap = {
  "react": async () => {
    let pkg = await __vitePreload(() => import("./index-B0OThK7f.js").then((n) => n.i), true ? __vite__mapDeps([0,1]) : void 0);
    return pkg;
  },
  "react-router-dom": async () => {
    let pkg = await __vitePreload(() => import("./index-DCk8YTfP.js"), true ? __vite__mapDeps([2,3,1,4,5]) : void 0);
    return pkg;
  },
  "@carbon/icons-react": async () => {
    let pkg = await __vitePreload(() => import("./index-B8F3w5s0.js"), true ? __vite__mapDeps([6,1,3,4]) : void 0);
    return pkg;
  },
  "antd": async () => {
    let pkg = await __vitePreload(() => import("./index-BHdSYc92.js"), true ? __vite__mapDeps([7,3,1,4,8,5]) : void 0);
    return pkg;
  },
  "react-dom": async () => {
    let pkg = await __vitePreload(() => import("./index-C0g94wjF.js").then((n) => n.i), true ? __vite__mapDeps([9,1,3,4]) : void 0);
    return pkg;
  },
  "@ant-design/icons": async () => {
    let pkg = await __vitePreload(() => import("./index-BbK4DbHP.js"), true ? __vite__mapDeps([10,3,1,4,8]) : void 0);
    return pkg;
  }
};
const usedShared = {
  "react": {
    name: "react",
    version: "18.3.1",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Alert",
    async get() {
      usedShared["react"].loaded = true;
      const { "react": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^18.3.1"
    }
  },
  "react-router-dom": {
    name: "react-router-dom",
    version: "6.28.0",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Alert",
    async get() {
      usedShared["react-router-dom"].loaded = true;
      const { "react-router-dom": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^6.27.0"
    }
  },
  "@carbon/icons-react": {
    name: "@carbon/icons-react",
    version: "11.60.0",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Alert",
    async get() {
      usedShared["@carbon/icons-react"].loaded = true;
      const { "@carbon/icons-react": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^11.60.0"
    }
  },
  "antd": {
    name: "antd",
    version: "5.25.2",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Alert",
    async get() {
      usedShared["antd"].loaded = true;
      const { "antd": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^5.25.2"
    }
  },
  "react-dom": {
    name: "react-dom",
    version: "18.3.1",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Alert",
    async get() {
      usedShared["react-dom"].loaded = true;
      const { "react-dom": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^18.3.1"
    }
  },
  "@ant-design/icons": {
    name: "@ant-design/icons",
    version: "5.5.2",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/Alert",
    async get() {
      usedShared["@ant-design/icons"].loaded = true;
      const { "@ant-design/icons": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^5.5.2"
    }
  }
};
const usedRemotes = [
  {
    entryGlobalName: "supos-ce/host",
    name: "@supos_host",
    type: "var",
    entry: "/mf-manifest.json",
    shareScope: "default"
  }
];
const initTokens = {};
const shareScopeName = "default";
const mfName = "supos-ce/Alert";
async function init(shared = {}, initScope = []) {
  const initRes = index_cjs.init({
    name: mfName,
    remotes: usedRemotes,
    shared: usedShared,
    plugins: [],
    shareStrategy: "version-first"
  });
  var initToken = initTokens[shareScopeName];
  if (!initToken)
    initToken = initTokens[shareScopeName] = { from: mfName };
  if (initScope.indexOf(initToken) >= 0) return;
  initScope.push(initToken);
  initRes.initShareScopeMap("default", shared);
  try {
    await Promise.all(await initRes.initializeSharing("default", {
      strategy: "version-first",
      from: "build",
      initScope
    }));
  } catch (e) {
    console.error(e);
  }
  supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__.initResolve(initRes);
  return initRes;
}
function getExposes(moduleName) {
  if (!(moduleName in exposesMap)) throw new Error(`Module ${moduleName} does not exist in container.`);
  return exposesMap[moduleName]().then((res) => () => res);
}
export {
  getExposes as get,
  init
};
