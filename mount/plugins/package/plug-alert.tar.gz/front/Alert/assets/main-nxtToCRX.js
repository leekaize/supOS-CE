import "./hostInit-D9GUzrPY.js";
import "./supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__-Br6ZSoi8.js";
import { j as jsxRuntimeExports, s as supos_mf_2_ce_mf_1_Alert__loadShare__react_mf_2_router_mf_2_dom__loadShare__, A as Alert } from "./App-2nT2yxPu.js";
import { s as supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__-X4nl10Rf.js";
import { s as supos_mf_2_ce_mf_1_Alert__loadShare__react_mf_2_dom__loadShare__ } from "./supos_mf_2_ce_mf_1_Alert__loadShare__react_mf_2_dom__loadShare__-mgRSoRK_.js";
import "./preload-helper-PAP2FNEz.js";
import "./_commonjsHelpers-DWwsNxpa.js";
var createRoot;
var m = supos_mf_2_ce_mf_1_Alert__loadShare__react_mf_2_dom__loadShare__;
{
  createRoot = m.createRoot;
  m.hydrateRoot;
}
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__react_mf_2_router_mf_2_dom__loadShare__.BrowserRouter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(Alert, { title: "" }) }) })
);
