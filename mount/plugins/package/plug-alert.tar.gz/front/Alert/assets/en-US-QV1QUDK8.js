const alterCount = "Alert Count";
const createAlert = "Create Alert";
const alert = "Alert";
const edit = "Edit";
const show = "Details";
const editAlert = "Edit Alert";
const key = "Key";
const condition = "Condition";
const deadZone = "Dead Zone";
const overDuration = "Over-limit Duration(s)";
const percent = "Percentage";
const value = "Value";
const greaterThan = "Greater than (>)";
const lessThan = "Less than (<)";
const greaterEqualThan = "Greater than or Equal to (>=)";
const lessEqualThan = "Less than or Equal to (<=)";
const equal = "Equal to (=)";
const noEqual = "Not Equal to (!=)";
const range = "Range(min<x<max)";
const min = "Min";
const max = "Max";
const search = "Please enter the alert name or description";
const acceptType = "Receiver Type";
const person = "Person";
const workflow = "workflow";
const accept = "Receiver";
const regularValue = "Rule value";
const enUS = {
  alterCount,
  createAlert,
  alert,
  edit,
  show,
  editAlert,
  key,
  condition,
  deadZone,
  overDuration,
  percent,
  value,
  greaterThan,
  lessThan,
  greaterEqualThan,
  lessEqualThan,
  equal,
  noEqual,
  range,
  min,
  max,
  search,
  acceptType,
  person,
  workflow,
  accept,
  regularValue
};
export {
  accept,
  acceptType,
  alert,
  alterCount,
  condition,
  createAlert,
  deadZone,
  enUS as default,
  edit,
  editAlert,
  equal,
  greaterEqualThan,
  greaterThan,
  key,
  lessEqualThan,
  lessThan,
  max,
  min,
  noEqual,
  overDuration,
  percent,
  person,
  range,
  regularValue,
  search,
  show,
  value,
  workflow
};
