const alterCount = "报警次数";
const createAlert = "创建报警";
const alert = "报警";
const edit = "编辑";
const show = "显示";
const editAlert = "编辑报警";
const key = "键";
const condition = "条件";
const deadZone = "死区类型";
const overDuration = "越限时长(s)";
const percent = "百分比";
const value = "值";
const greaterThan = "大于 (>)";
const lessThan = "小于 (<)";
const greaterEqualThan = "大于等于 (>=)";
const lessEqualThan = "小于等于 (<=)";
const equal = "等于 (=)";
const noEqual = "不等于 (!=)";
const range = "区间(最小值<x<最大值)";
const min = "最小值";
const max = "最大值";
const search = "请输入报警名称或描述进行搜索";
const acceptType = "接收方式";
const person = "人员";
const workflow = "工作流程";
const accept = "接收";
const regularValue = "规则值";
const zhCN = {
  alterCount,
  createAlert,
  alert,
  edit,
  show,
  editAlert,
  key,
  condition,
  deadZone,
  overDuration,
  percent,
  value,
  greaterThan,
  lessThan,
  greaterEqualThan,
  lessEqualThan,
  equal,
  noEqual,
  range,
  min,
  max,
  search,
  acceptType,
  person,
  workflow,
  accept,
  regularValue
};
export {
  accept,
  acceptType,
  alert,
  alterCount,
  condition,
  createAlert,
  deadZone,
  zhCN as default,
  edit,
  editAlert,
  equal,
  greaterEqualThan,
  greaterThan,
  key,
  lessEqualThan,
  lessThan,
  max,
  min,
  noEqual,
  overDuration,
  percent,
  person,
  range,
  regularValue,
  search,
  show,
  value,
  workflow
};
