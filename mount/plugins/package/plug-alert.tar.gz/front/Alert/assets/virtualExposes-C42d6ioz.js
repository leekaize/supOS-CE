const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/App-2nT2yxPu.js","assets/supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__-X4nl10Rf.js","assets/_commonjsHelpers-DWwsNxpa.js","assets/supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__-Br6ZSoi8.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-PAP2FNEz.js";
const exposesMap = {
  "./index": async () => {
    const importModule = await __vitePreload(() => import("./App-2nT2yxPu.js").then((n) => n.a), true ? __vite__mapDeps([0,1,2,3]) : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./enUS": async () => {
    const importModule = await __vitePreload(() => import("./en-US-QV1QUDK8.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./zhCN": async () => {
    const importModule = await __vitePreload(() => import("./zh-CN-CtrQxRs9.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  }
};
export {
  exposesMap as default
};
