import { s as supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__-X4nl10Rf.js";
import { s as supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__, i as index_cjs } from "./supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__-Br6ZSoi8.js";
import { c as commonjsGlobal, g as getDefaultExportFromCjs } from "./_commonjsHelpers-DWwsNxpa.js";
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
const { loadShare: loadShare$2 } = index_cjs;
const { initPromise: initPromise$8 } = supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__;
const res$8 = initPromise$8.then((_) => loadShare$2("react-router-dom", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^6.27.0"
  } }
}));
const exportModule$8 = await res$8.then((factory) => factory());
var supos_mf_2_ce_mf_1_Alert__loadShare__react_mf_2_router_mf_2_dom__loadShare__ = exportModule$8;
const { loadRemote: loadRemote$5 } = index_cjs;
const { initPromise: initPromise$7 } = supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__;
const res$7 = initPromise$7.then((_) => loadRemote$5("@supos_host/hooks"));
const exportModule$7 = await initPromise$7.then((_) => res$7);
var supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__ = exportModule$7;
const { loadRemote: loadRemote$4 } = index_cjs;
const { initPromise: initPromise$6 } = supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__;
const res$6 = initPromise$6.then((_) => loadRemote$4("@supos_host/button-permission"));
const exportModule$6 = await initPromise$6.then((_) => res$6);
var supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__ = exportModule$6;
const { loadShare: loadShare$1 } = index_cjs;
const { initPromise: initPromise$5 } = supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__;
const res$5 = initPromise$5.then((_) => loadShare$1("@carbon/icons-react", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^11.60.0"
  } }
}));
const exportModule$5 = await res$5.then((factory) => factory());
var supos_mf_2_ce_mf_1_Alert__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__ = exportModule$5;
const { loadRemote: loadRemote$3 } = index_cjs;
const { initPromise: initPromise$4 } = supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__;
const res$4 = initPromise$4.then((_) => loadRemote$3("@supos_host/tabs-lifecycle-context"));
const exportModule$4 = await initPromise$4.then((_) => res$4);
var supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_tabs_mf_2_lifecycle_mf_2_context__loadRemote__ = exportModule$4;
const { loadRemote: loadRemote$2 } = index_cjs;
const { initPromise: initPromise$3 } = supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__;
const res$3 = initPromise$3.then((_) => loadRemote$2("@supos_host/utils"));
const exportModule$3 = await initPromise$3.then((_) => res$3);
var supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__ = exportModule$3;
const baseUrl$2 = "/inter-api/supos/userManage";
const api$2 = new supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl$2);
const searchUserManageList = async (data) => api$2.post("/pageList", data).then((data2) => {
  var _a;
  return (_a = data2 == null ? void 0 : data2.map) == null ? void 0 : _a.call(data2, (item) => ({
    label: item.preferredUsername,
    value: item.id
  }));
});
const baseUrl$1 = "/inter-api/supos/uns";
const api$1 = new supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl$1);
const getAlertList = async (params) => api$1.get("/search", {
  params,
  [supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.CustomAxiosConfigEnum.BusinessResponse]: true
}).then((data) => {
  var _a, _b, _c;
  return {
    ...data,
    pageNo: (_a = data == null ? void 0 : data.page) == null ? void 0 : _a.pageNo,
    pageSize: (_b = data == null ? void 0 : data.page) == null ? void 0 : _b.pageSize,
    total: (_c = data == null ? void 0 : data.page) == null ? void 0 : _c.total
  };
});
const getInstanceInfo = async (params) => api$1.get("/instance", { params, _noMessage: true });
const searchTreeData = async (params) => api$1.get("/search", { params });
const baseUrl = "/inter-api/supos/uns";
const api = new supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl);
const addRule = async (data) => api.post("/alarm/rule", data);
const editRule = async (data) => api.put("/alarm/rule", data);
const deleteRule = async (params) => api.delete(``, { params });
const { loadShare } = index_cjs;
const { initPromise: initPromise$2 } = supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__;
const res$2 = initPromise$2.then((_) => loadShare("antd", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^5.25.2"
  } }
}));
const exportModule$2 = await res$2.then((factory) => factory());
var supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__ = exportModule$2;
function isObject$2(value) {
  var type = typeof value;
  return value != null && (type == "object" || type == "function");
}
var isObject_1 = isObject$2;
var freeGlobal$1 = typeof commonjsGlobal == "object" && commonjsGlobal && commonjsGlobal.Object === Object && commonjsGlobal;
var _freeGlobal = freeGlobal$1;
var freeGlobal = _freeGlobal;
var freeSelf = typeof self == "object" && self && self.Object === Object && self;
var root$2 = freeGlobal || freeSelf || Function("return this")();
var _root = root$2;
var root$1 = _root;
var now$1 = function() {
  return root$1.Date.now();
};
var now_1 = now$1;
var reWhitespace = /\s/;
function trimmedEndIndex$1(string) {
  var index = string.length;
  while (index-- && reWhitespace.test(string.charAt(index))) {
  }
  return index;
}
var _trimmedEndIndex = trimmedEndIndex$1;
var trimmedEndIndex = _trimmedEndIndex;
var reTrimStart = /^\s+/;
function baseTrim$1(string) {
  return string ? string.slice(0, trimmedEndIndex(string) + 1).replace(reTrimStart, "") : string;
}
var _baseTrim = baseTrim$1;
var root = _root;
var Symbol$3 = root.Symbol;
var _Symbol = Symbol$3;
var Symbol$2 = _Symbol;
var objectProto$1 = Object.prototype;
var hasOwnProperty = objectProto$1.hasOwnProperty;
var nativeObjectToString$1 = objectProto$1.toString;
var symToStringTag$1 = Symbol$2 ? Symbol$2.toStringTag : void 0;
function getRawTag$1(value) {
  var isOwn = hasOwnProperty.call(value, symToStringTag$1), tag = value[symToStringTag$1];
  try {
    value[symToStringTag$1] = void 0;
    var unmasked = true;
  } catch (e) {
  }
  var result = nativeObjectToString$1.call(value);
  if (unmasked) {
    if (isOwn) {
      value[symToStringTag$1] = tag;
    } else {
      delete value[symToStringTag$1];
    }
  }
  return result;
}
var _getRawTag = getRawTag$1;
var objectProto = Object.prototype;
var nativeObjectToString = objectProto.toString;
function objectToString$1(value) {
  return nativeObjectToString.call(value);
}
var _objectToString = objectToString$1;
var Symbol$1 = _Symbol, getRawTag = _getRawTag, objectToString = _objectToString;
var nullTag = "[object Null]", undefinedTag = "[object Undefined]";
var symToStringTag = Symbol$1 ? Symbol$1.toStringTag : void 0;
function baseGetTag$1(value) {
  if (value == null) {
    return value === void 0 ? undefinedTag : nullTag;
  }
  return symToStringTag && symToStringTag in Object(value) ? getRawTag(value) : objectToString(value);
}
var _baseGetTag = baseGetTag$1;
function isObjectLike$1(value) {
  return value != null && typeof value == "object";
}
var isObjectLike_1 = isObjectLike$1;
var baseGetTag = _baseGetTag, isObjectLike = isObjectLike_1;
var symbolTag = "[object Symbol]";
function isSymbol$1(value) {
  return typeof value == "symbol" || isObjectLike(value) && baseGetTag(value) == symbolTag;
}
var isSymbol_1 = isSymbol$1;
var baseTrim = _baseTrim, isObject$1 = isObject_1, isSymbol = isSymbol_1;
var NAN = 0 / 0;
var reIsBadHex = /^[-+]0x[0-9a-f]+$/i;
var reIsBinary = /^0b[01]+$/i;
var reIsOctal = /^0o[0-7]+$/i;
var freeParseInt = parseInt;
function toNumber$1(value) {
  if (typeof value == "number") {
    return value;
  }
  if (isSymbol(value)) {
    return NAN;
  }
  if (isObject$1(value)) {
    var other = typeof value.valueOf == "function" ? value.valueOf() : value;
    value = isObject$1(other) ? other + "" : other;
  }
  if (typeof value != "string") {
    return value === 0 ? value : +value;
  }
  value = baseTrim(value);
  var isBinary = reIsBinary.test(value);
  return isBinary || reIsOctal.test(value) ? freeParseInt(value.slice(2), isBinary ? 2 : 8) : reIsBadHex.test(value) ? NAN : +value;
}
var toNumber_1 = toNumber$1;
var isObject = isObject_1, now = now_1, toNumber = toNumber_1;
var FUNC_ERROR_TEXT = "Expected a function";
var nativeMax = Math.max, nativeMin = Math.min;
function debounce(func, wait, options) {
  var lastArgs, lastThis, maxWait, result, timerId, lastCallTime, lastInvokeTime = 0, leading = false, maxing = false, trailing = true;
  if (typeof func != "function") {
    throw new TypeError(FUNC_ERROR_TEXT);
  }
  wait = toNumber(wait) || 0;
  if (isObject(options)) {
    leading = !!options.leading;
    maxing = "maxWait" in options;
    maxWait = maxing ? nativeMax(toNumber(options.maxWait) || 0, wait) : maxWait;
    trailing = "trailing" in options ? !!options.trailing : trailing;
  }
  function invokeFunc(time) {
    var args = lastArgs, thisArg = lastThis;
    lastArgs = lastThis = void 0;
    lastInvokeTime = time;
    result = func.apply(thisArg, args);
    return result;
  }
  function leadingEdge(time) {
    lastInvokeTime = time;
    timerId = setTimeout(timerExpired, wait);
    return leading ? invokeFunc(time) : result;
  }
  function remainingWait(time) {
    var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime, timeWaiting = wait - timeSinceLastCall;
    return maxing ? nativeMin(timeWaiting, maxWait - timeSinceLastInvoke) : timeWaiting;
  }
  function shouldInvoke(time) {
    var timeSinceLastCall = time - lastCallTime, timeSinceLastInvoke = time - lastInvokeTime;
    return lastCallTime === void 0 || timeSinceLastCall >= wait || timeSinceLastCall < 0 || maxing && timeSinceLastInvoke >= maxWait;
  }
  function timerExpired() {
    var time = now();
    if (shouldInvoke(time)) {
      return trailingEdge(time);
    }
    timerId = setTimeout(timerExpired, remainingWait(time));
  }
  function trailingEdge(time) {
    timerId = void 0;
    if (trailing && lastArgs) {
      return invokeFunc(time);
    }
    lastArgs = lastThis = void 0;
    return result;
  }
  function cancel() {
    if (timerId !== void 0) {
      clearTimeout(timerId);
    }
    lastInvokeTime = 0;
    lastArgs = lastCallTime = lastThis = timerId = void 0;
  }
  function flush() {
    return timerId === void 0 ? result : trailingEdge(now());
  }
  function debounced() {
    var time = now(), isInvoking = shouldInvoke(time);
    lastArgs = arguments;
    lastThis = this;
    lastCallTime = time;
    if (isInvoking) {
      if (timerId === void 0) {
        return leadingEdge(lastCallTime);
      }
      if (maxing) {
        clearTimeout(timerId);
        timerId = setTimeout(timerExpired, wait);
        return invokeFunc(lastCallTime);
      }
    }
    if (timerId === void 0) {
      timerId = setTimeout(timerExpired, wait);
    }
    return result;
  }
  debounced.cancel = cancel;
  debounced.flush = flush;
  return debounced;
}
var debounce_1 = debounce;
const debounce$1 = /* @__PURE__ */ getDefaultExportFromCjs(debounce_1);
const REMOTE_NAME = "Alert";
const DebounceSelect = ({
  value,
  onChange,
  debounceTimeout = 500,
  selectAll,
  apiParams,
  labelInValue = false,
  mode,
  disabledIds,
  ...rest
}) => {
  const [fetching, setFetching] = supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.useState(false);
  const [options, setOptions] = supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.useState([]);
  const formatMessage = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const { type = 3 } = apiParams || {};
  const debounceFetcher = supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.useMemo(() => {
    const loadOptions = (value2) => {
      setOptions([]);
      setFetching(true);
      searchData(value2);
    };
    return debounce$1(loadOptions, debounceTimeout);
  }, [debounceTimeout]);
  const searchData = (key) => {
    const params = { pageNo: 1, pageSize: 100, type, ...apiParams };
    if (key) params.k = key;
    searchTreeData(params).then((res2) => {
      res2.forEach((e) => {
        e.disabled = disabledIds == null ? void 0 : disabledIds.includes(e.id);
      });
      setOptions(res2);
      setFetching(false);
    }).catch((err) => {
      setFetching(false);
      console.log(err);
    });
  };
  supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.useEffect(() => {
    searchData == null ? void 0 : searchData();
  }, []);
  const _onChange = (e) => {
    onChange == null ? void 0 : onChange(
      labelInValue ? mode ? (e == null ? void 0 : e.map((item) => ({ ...item, option: options.find((i) => i.id === item.value) }))) ?? [] : e ? { ...e, option: options.find((i) => i.id === (e == null ? void 0 : e.value)) } : void 0 : e
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Select,
    {
      allowClear: true,
      showSearch: true,
      filterOption: false,
      fieldNames: { label: "path", value: "id" },
      notFoundContent: fetching ? /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Spin, { size: "small" }) : formatMessage("uns.noData"),
      dropdownRender: (menu) => /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        menu,
        options.length > 0 && (selectAll && mode || options.length > 99) && /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Divider, { style: { margin: "4px 0", borderColor: "#c6c6c6" } }),
          selectAll && mode && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { textAlign: "center" }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Button,
            {
              color: "default",
              variant: "filled",
              onClick: () => {
                selectAll(options);
              },
              size: "small",
              style: { backgroundColor: "var(--supos-uns-button-color)" },
              children: formatMessage("uns.select100Items")
            }
          ) }),
          options.length > 99 && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { style: { textAlign: "center" }, children: formatMessage("uns.forMoreInformationPleaseSearch") })
        ] })
      ] }),
      ...rest,
      onSearch: debounceFetcher,
      options,
      value,
      onChange: _onChange,
      onFocus: () => searchData(),
      labelInValue,
      mode
    }
  );
};
const { loadRemote: loadRemote$1 } = index_cjs;
const { initPromise: initPromise$1 } = supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__;
const res$1 = initPromise$1.then((_) => loadRemote$1("@supos_host/components"));
const exportModule$1 = await initPromise$1.then((_) => res$1);
var supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__ = exportModule$1;
const { loadRemote } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_Alert__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadRemote("@supos_host/baseStore"));
const exportModule = await initPromise.then((_) => res);
var supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_baseStore__loadRemote__ = exportModule;
const NameSpace = ({ isEdit }) => {
  const form = supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.useFormInstance();
  const [options, setOptions] = supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.useState();
  const formatMessage = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const { qualityName = "quality", timestampName = "timeStamp" } = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_baseStore__loadRemote__.useBaseStore((state) => state.systemInfo);
  const onChange = (e) => {
    var _a, _b;
    const _options = (_b = (_a = e == null ? void 0 : e.option) == null ? void 0 : _a.fields) == null ? void 0 : _b.map((item) => {
      if ([qualityName, timestampName].includes(item.name)) {
        return { ...item, disabled: true };
      }
      return item;
    });
    setOptions(_options || []);
    form.setFieldValue(["refers", 0, "field"], void 0);
  };
  supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.useEffect(() => {
    if (isEdit) {
      getInstanceInfo({ id: form.getFieldValue(["refers", 0, "refer", "value"]) }).then((res2) => {
        var _a;
        const _options = (_a = res2 == null ? void 0 : res2.fields) == null ? void 0 : _a.map((item) => {
          if ([qualityName, timestampName].includes(item.name)) {
            return { ...item, disabled: true };
          }
          return item;
        });
        setOptions(_options || []);
        form.setFieldValue(["refers", 0, "refer", "label"], res2 == null ? void 0 : res2.path);
      });
    }
  }, [isEdit]);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item, { label: formatMessage("key"), required: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Space,
    {
      style: { width: "100%" },
      styles: {
        item: { width: "50%", overflow: "hidden" }
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item,
          {
            name: ["refers", 0, "refer"],
            style: { marginBottom: 0 },
            rules: [
              {
                required: true,
                message: commonFormatMessage("uns.pleaseInputNamespace")
              }
            ],
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              DebounceSelect,
              {
                style: { width: "100%" },
                placeholder: commonFormatMessage("uns.namespace"),
                onChange,
                popupMatchSelectWidth: 400,
                apiParams: { type: 4 },
                labelInValue: true
              }
            )
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item,
          {
            name: ["refers", 0, "field"],
            style: { marginBottom: 0 },
            rules: [
              {
                required: true,
                message: commonFormatMessage("uns.pleaseSelectKeyType")
              }
            ],
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComSelect,
              {
                fieldNames: { label: "name", value: "name" },
                placeholder: commonFormatMessage("uns.key"),
                options,
                style: { width: "100%" },
                allowClear: true
              }
            )
          }
        )
      ]
    }
  ) });
};
const Condition = () => {
  const formatMessage = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const options = [
    {
      label: formatMessage("greaterThan"),
      value: ">"
    },
    {
      label: formatMessage("greaterEqualThan"),
      value: ">="
    },
    {
      label: formatMessage("lessThan"),
      value: "<"
    },
    {
      label: formatMessage("lessEqualThan"),
      value: "<="
    },
    {
      label: formatMessage("equal"),
      value: "="
    },
    {
      label: formatMessage("noEqual"),
      value: "!="
    }
    // {
    //   label: formatMessage('alert.range'),
    //   value: 'range',
    // },
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item, { label: formatMessage("condition"), required: true, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Space,
    {
      style: { width: "100%" },
      styles: {
        item: { width: "50%", overflow: "hidden" }
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item,
          {
            name: ["protocol", "condition"],
            style: { marginBottom: 0 },
            rules: [{ required: true, message: commonFormatMessage("rule.required") }],
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComSelect, { allowClear: true, options, style: { width: "100%" }, placeholder: formatMessage("condition") })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item, { noStyle: true, shouldUpdate: (pre, cur) => {
          var _a, _b;
          return ((_a = pre == null ? void 0 : pre.protocol) == null ? void 0 : _a.condition) !== ((_b = cur == null ? void 0 : cur.protocol) == null ? void 0 : _b.condition);
        }, children: ({ getFieldValue }) => {
          const conditionType = getFieldValue(["protocol", "condition"]);
          return conditionType === "range" ? /* @__PURE__ */ jsxRuntimeExports.jsxs(
            supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Space,
            {
              style: { width: "100%" },
              styles: {
                item: { width: "50%" }
              },
              children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item, { name: "num1", style: { marginBottom: 0 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.InputNumber, { style: { width: "100%" }, placeholder: formatMessage("min") }) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item, { name: "num2", style: { marginBottom: 0 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.InputNumber, { style: { width: "100%" }, placeholder: formatMessage("max") }) })
              ]
            }
          ) : /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item,
            {
              name: ["protocol", "limitValue"],
              style: { marginBottom: 0 },
              rules: [{ required: true, message: commonFormatMessage("rule.required") }],
              children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.InputNumber, { style: { width: "100%" }, placeholder: formatMessage("regularValue") })
            }
          );
        } })
      ]
    }
  ) });
};
const DeadZone = () => {
  const formatMessage = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const options = [
    {
      label: formatMessage("value"),
      value: 1
    },
    {
      label: formatMessage("percent"),
      value: 2
    }
  ];
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item, { label: formatMessage("deadZone"), children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Space,
    {
      style: { width: "100%" },
      styles: {
        item: { width: "50%", overflow: "hidden" }
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item, { name: ["protocol", "deadBandType"], style: { marginBottom: 0 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComSelect, { options, style: { width: "100%" }, placeholder: formatMessage("deadZone") }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.Item, { name: ["protocol", "deadBand"], style: { marginBottom: 0 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.InputNumber, { style: { width: "100%" }, placeholder: formatMessage("regularValue") }) })
      ]
    }
  ) });
};
const Alert = ({ title }) => {
  var _a;
  const location = supos_mf_2_ce_mf_1_Alert__loadShare__react_mf_2_router_mf_2_dom__loadShare__.useLocation();
  const businessId = (_a = location == null ? void 0 : location.state) == null ? void 0 : _a.businessId;
  const [searchForm] = supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.useForm();
  const formatMessage = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const [isEdit, setIsEdit] = supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.useState(false);
  const [show, setShow] = supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.useState(false);
  const formItemOptions = [
    {
      label: commonFormatMessage("common.name"),
      name: "name",
      rules: [
        { required: true, message: commonFormatMessage("rule.required") },
        { pattern: supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.validInputPattern, message: commonFormatMessage("rule.illegality") }
      ],
      properties: {
        placeholder: commonFormatMessage("common.name")
      }
    },
    {
      label: commonFormatMessage("uns.description"),
      name: "description",
      type: "TextArea",
      properties: {
        placeholder: commonFormatMessage("uns.description")
      }
    },
    {
      label: formatMessage("acceptType"),
      name: "withFlags",
      type: "Select",
      rules: [{ required: true, message: commonFormatMessage("rule.required") }],
      properties: {
        options: [
          { label: formatMessage("person"), value: 16 }
          // { label: formatMessage('alert.workflow'), value: 32 },
        ],
        placeholder: formatMessage("acceptType"),
        onClear: () => {
          form.setFieldsValue({ accept: void 0 });
        }
      }
    },
    {
      label: formatMessage("accept"),
      name: "accept",
      type: "Select",
      rules: [{ required: true, message: commonFormatMessage("rule.required") }],
      properties: {
        isRequest: show,
        placeholder: formatMessage("person"),
        mode: "multiple",
        filterOption: (input, option) => ((option == null ? void 0 : option.label) ?? "").toLowerCase().includes(input.toLowerCase()),
        showSearch: true,
        onChange: (_, option) => {
          const selected = Array.isArray(option) ? option.map((o) => ({ value: o.value, label: o.label })) : { value: option.value, label: option.label };
          form.setFieldsValue({ accept: selected });
        },
        api: (key) => searchUserManageList({ preferredUsername: key, page: 1, pageSize: 999 })
      }
    },
    {
      type: "divider"
    },
    {
      render: () => /* @__PURE__ */ jsxRuntimeExports.jsx(NameSpace, { isEdit })
    },
    {
      render: Condition
    },
    {
      render: DeadZone
    },
    {
      label: formatMessage("overDuration"),
      name: ["protocol", "overTime"],
      type: "Number",
      properties: {
        min: 1,
        precision: 0,
        placeholder: formatMessage("regularValue")
      }
    },
    {
      label: "id",
      name: "id",
      hidden: true
    },
    {
      type: "divider"
    }
  ];
  const [form] = supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Form.useForm();
  const { loading, pagination, data, refreshRequest, reload, setSearchParams } = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.usePagination({
    fetchApi: getAlertList,
    initPageSize: 23,
    defaultParams: {
      type: 5
    }
  });
  supos_mf_2_ce_mf_1_Alert__loadShare__react__loadShare__.useEffect(() => {
    data == null ? void 0 : data.map((e) => {
      if (e.id === businessId) {
        onOpen({
          unsId: e.id
        });
      }
    });
  }, [businessId, data]);
  supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_tabs_mf_2_lifecycle_mf_2_context__loadRemote__.useActivate(() => {
    refreshRequest == null ? void 0 : refreshRequest();
  });
  const onAddHandle = () => {
    setIsEdit(false);
    form.resetFields();
    if (show) return;
    setShow(true);
  };
  const onClose = () => {
    setShow(false);
    setIsEdit(false);
    form.resetFields();
  };
  const onSave = async () => {
    var _a2, _b, _c;
    const values = await form.validateFields();
    console.log(values, "values");
    let addData;
    if (values.withFlags === 16) {
      addData = {
        ...values,
        userList: values.accept.map((e) => {
          return {
            id: e.value,
            preferredUsername: e.label
          };
        }),
        refers: (_a2 = values.refers) == null ? void 0 : _a2.map((e) => {
          var _a3;
          return { id: (_a3 = e == null ? void 0 : e.refer) == null ? void 0 : _a3.value, field: e.field };
        })
      };
      delete addData.accept;
    } else if (values.withFlags === 32) {
      addData = { ...values, extend: values.accept.value };
      delete addData.accept;
    }
    const api2 = isEdit ? editRule : addRule;
    await api2({
      ...addData,
      expression: `a1${(_b = values == null ? void 0 : values.protocol) == null ? void 0 : _b.condition}${(_c = values == null ? void 0 : values.protocol) == null ? void 0 : _c.limitValue}`
    }).then(() => {
      refreshRequest();
      onClose();
    }).finally(() => {
    });
  };
  const onDeleteHandle = (item) => {
    deleteRule({
      id: item.id,
      withFlow: false,
      withDashboard: false
    }).then(() => {
      reload();
    });
  };
  const { ModalDom, onOpen } = supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.useInformationModal({
    onCallBack: refreshRequest
  });
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComLayout, { loading, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs(
      supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
      {
        title,
        extra: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Flex, { gap: 8, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComSearch,
          {
            form: searchForm,
            formItemOptions: [
              {
                name: "k",
                properties: {
                  prefix: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Search, {}),
                  placeholder: formatMessage("search"),
                  style: { width: 300 },
                  allowClear: true
                }
              }
            ],
            formConfig: {
              onFinish: () => {
                setSearchParams(searchForm.getFieldsValue());
              }
            },
            onSearch: () => {
              setSearchParams(searchForm.getFieldsValue());
            }
          }
        ) }),
        hasBack: false,
        style: {
          overflow: "hidden",
          display: "flex",
          flexDirection: "column",
          height: "100%"
        },
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComCardList,
            {
              onAddHandle,
              onDeleteHandle,
              addAuth: supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["alert.add"],
              deleteAuth: supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["alert.delete"],
              list: data == null ? void 0 : data.map((item) => ({
                ...item,
                icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Alarm, { color: "#DA1E28", size: "22" })
              })),
              style: { gap: 20, flex: 1 },
              cardStyle: { width: 243, height: 200 },
              viewOptions: [
                {
                  label: formatMessage("alterCount"),
                  valueKey: "noReadCount",
                  render: (_, record) => {
                    return /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: record == null ? void 0 : record.alarmCount }) });
                  }
                },
                {
                  label: commonFormatMessage("uns.description"),
                  valueKey: "description"
                }
              ],
              operationOptions: [
                {
                  label: formatMessage("edit"),
                  onClick: (item) => {
                    setIsEdit(true);
                    setShow(true);
                    form.setFieldsValue({
                      id: item.id,
                      refers: [
                        {
                          refer: { value: item.refUns },
                          field: item.field
                        }
                      ],
                      name: item.name,
                      description: item.description,
                      protocol: item.alarmRuleDefine,
                      withFlags: item.withFlags,
                      accept: item.withFlags === 32 ? { value: item.processDefinition.id, label: item.processDefinition.id.processDefinitionName } : item.handlerList.map((item2) => {
                        return {
                          value: item2.userId,
                          label: item2.username
                        };
                      })
                    });
                  },
                  type: "block",
                  auth: supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["alert.edit"]
                },
                {
                  label: formatMessage("show"),
                  onClick: (item) => {
                    onOpen({
                      // 报警自己的topic id
                      unsId: item.id
                    });
                  },
                  type: "block",
                  auth: supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["alert.show"]
                }
              ]
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_Alert__loadShare__antd__loadShare__.Pagination,
            {
              size: "small",
              className: "custom-pagination",
              align: "center",
              style: { margin: "20px 0" },
              showSizeChanger: false,
              total: pagination == null ? void 0 : pagination.total,
              pageSize: (pagination == null ? void 0 : pagination.pageSize) || 20,
              current: pagination == null ? void 0 : pagination.page,
              onChange: pagination.onChange
            }
          ),
          ModalDom
        ]
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComDrawer, { title: " ", width: 680, open: show, onClose, children: show && /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_Alert__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.OperationForm,
      {
        formConfig: {
          labelCol: { span: 7 },
          wrapperCol: { span: 17 }
        },
        title: isEdit ? formatMessage("editAlert") : formatMessage("createAlert"),
        form,
        onCancel: onClose,
        onSave,
        formItemOptions
      }
    ) })
  ] });
};
const App = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: Alert
}, Symbol.toStringTag, { value: "Module" }));
export {
  Alert as A,
  App as a,
  jsxRuntimeExports as j,
  supos_mf_2_ce_mf_1_Alert__loadShare__react_mf_2_router_mf_2_dom__loadShare__ as s
};
