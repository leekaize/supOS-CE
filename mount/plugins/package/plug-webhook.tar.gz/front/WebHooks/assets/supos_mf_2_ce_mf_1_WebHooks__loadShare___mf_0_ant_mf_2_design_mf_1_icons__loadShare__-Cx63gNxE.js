import { s as supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__, i as index_cjs } from "./supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__-C0pvS97-.js";
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("@ant-design/icons", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^5.5.2"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__ = exportModule;
export {
  supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__ as s
};
