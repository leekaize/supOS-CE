import { s as supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__-KnfA8M-g.js";
import { s as supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__, i as index_cjs } from "./supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__-C0pvS97-.js";
import { s as supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__ } from "./supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__-Cx63gNxE.js";
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
const { loadShare: loadShare$1 } = index_cjs;
const { initPromise: initPromise$5 } = supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__;
const res$5 = initPromise$5.then((_) => loadShare$1("antd", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^5.25.2"
  } }
}));
const exportModule$5 = await res$5.then((factory) => factory());
var supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__ = exportModule$5;
const { loadShare } = index_cjs;
const { initPromise: initPromise$4 } = supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__;
const res$4 = initPromise$4.then((_) => loadShare("@carbon/icons-react", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^11.60.0"
  } }
}));
const exportModule$4 = await res$4.then((factory) => factory());
var supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__ = exportModule$4;
const { loadRemote: loadRemote$3 } = index_cjs;
const { initPromise: initPromise$3 } = supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__;
const res$3 = initPromise$3.then((_) => loadRemote$3("@supos_host/components"));
const exportModule$3 = await initPromise$3.then((_) => res$3);
var supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__ = exportModule$3;
const { loadRemote: loadRemote$2 } = index_cjs;
const { initPromise: initPromise$2 } = supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__;
const res$2 = initPromise$2.then((_) => loadRemote$2("@supos_host/hooks"));
const exportModule$2 = await initPromise$2.then((_) => res$2);
var supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__ = exportModule$2;
const { loadRemote: loadRemote$1 } = index_cjs;
const { initPromise: initPromise$1 } = supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__;
const res$1 = initPromise$1.then((_) => loadRemote$1("@supos_host/utils"));
const exportModule$1 = await initPromise$1.then((_) => res$1);
var supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__ = exportModule$1;
const baseUrl$1 = "/inter-api/supos/sys";
const api$1 = new supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl$1);
const queryCodeValues = async (params) => api$1.get("/codes", { params });
const baseUrl = "/inter-api/supos";
const api = new supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl);
const getWebHookList = async (params) => api.get("/webhooks", {
  params
});
const addWebHookList = async (data) => api.post("/webhooks", data);
const updateWebHookList = async (data) => api.put("/webhooks", data);
const deleteWebHookList = async (id) => api.delete(`/webhooks/${id}`);
const { loadRemote } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadRemote("@supos_host/button-permission"));
const exportModule = await initPromise.then((_) => res);
var supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__ = exportModule;
const webHookContainer = "_webHookContainer_o2jo3_1";
const styles = {
  webHookContainer,
  "webHook-description": "_webHook-description_o2jo3_9",
  "webHook-description-api": "_webHook-description-api_o2jo3_29",
  "webHook-codeViewWrap": "_webHook-codeViewWrap_o2jo3_38"
};
const REMOTE_NAME = "WebHooks";
const WebHookHttpFormList = () => {
  const form = supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.useFormInstance();
  const formatMessage = supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [type, setType] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState(form.getFieldValue("body") ? "body" : "params");
  const [method, setMethod] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState(form.getFieldValue("methodType"));
  const handleSelectChange = (value) => {
    setType(value);
  };
  const handleMethodChange = (value) => {
    setMethod(value);
    setType("params");
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { margin: "6px 0 30px", fontSize: 16, fontWeight: 600, fontStyle: "normal", lineHeight: "16px" }, children: formatMessage("webHook") }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { border: "1px dashed #c6c6c6", borderRadius: 6, padding: 20 }, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { margin: "0 0 20px", fontSize: 16, fontWeight: 600, fontStyle: "normal", lineHeight: "16px" }, children: formatMessage("HTTPRequest") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { name: "methodType", label: formatMessage("method"), rules: [{ required: true }], children: /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Select,
        {
          style: { width: "100%" },
          placeholder: formatMessage("method"),
          options: [
            { label: "POST", value: "POST" },
            { label: "GET", value: "GET" },
            { label: "PUT", value: "PUT" },
            { label: "DELETE", value: "DELETE" }
          ],
          onChange: handleMethodChange
        }
      ) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { label: formatMessage("url"), name: "url", rules: [{ required: true }], children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Input, { addonBefore: "http://" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item,
        {
          label: formatMessage("timeout"),
          name: "timeout",
          extra: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "p",
            {
              style: {
                fontWeight: 400,
                fontStyle: "normal",
                fontSize: 14,
                color: "var(--character-secondary-45, rgba(0, 0, 0, 0.45))"
              },
              children: formatMessage("timeoutTips")
            }
          ),
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.InputNumber, { min: 1e3, max: 1e4, style: { width: "100%" }, suffix: "ms" })
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Divider, { style: { borderColor: "#c6c6c6" }, dashed: true }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { margin: "0 0 20px", fontSize: 16, fontWeight: 600, fontStyle: "normal", lineHeight: "16px" }, children: formatMessage("HTTPHeaders") }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.List, { name: "headers", children: (headers, { add, remove }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        headers.map(({ key, name, ...restField }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Flex, { gap: "8px", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { ...restField, name: [name, "key1"], wrapperCol: { span: 24 }, style: { flex: 1 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Input, { placeholder: formatMessage("commonPlaceholder") }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { ...restField, name: [name, "key2"], wrapperCol: { span: 24 }, style: { flex: 1 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Input, { placeholder: formatMessage("commonPlaceholder") }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Button,
            {
              color: "default",
              variant: "filled",
              icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.SubtractAlt, {}),
              onClick: () => {
                remove(name);
              },
              style: {
                border: "1px solid #CBD5E1",
                color: "var(--supos-text-color)",
                backgroundColor: "var(--supos-uns-button-color)"
              }
            }
          )
        ] }, key)),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Button,
          {
            color: "default",
            variant: "filled",
            onClick: () => {
              add();
              form.setFieldValue("functions", void 0);
            },
            block: true,
            style: { color: "var(--supos-text-color)", backgroundColor: "var(--supos-uns-button-color)" },
            icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.AddAlt, { size: 20 })
          }
        )
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Divider, { style: { borderColor: "#c6c6c6" }, dashed: true }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Select,
        {
          style: { width: 220, margin: "0 0 20px" },
          options: [
            { value: "params", label: "HTTP Parameters" },
            { value: "body", label: "HTTP Body", disabled: method !== "POST" }
          ],
          defaultValue: type,
          value: type,
          onChange: handleSelectChange
        }
      ),
      type === "params" ? /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.List, { name: "params", children: (parameters, { add, remove }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
        parameters.map(({ key, name, ...restField }) => /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Flex, { gap: "8px", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { ...restField, name: [name, "key1"], wrapperCol: { span: 24 }, style: { flex: 1 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Input, { placeholder: formatMessage("commonPlaceholder") }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { ...restField, name: [name, "key2"], wrapperCol: { span: 24 }, style: { flex: 1 }, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Input, { placeholder: formatMessage("commonPlaceholder") }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Button,
            {
              color: "default",
              variant: "filled",
              icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.SubtractAlt, {}),
              onClick: () => {
                remove(name);
              },
              style: {
                border: "1px solid #CBD5E1",
                color: "var(--supos-text-color)",
                backgroundColor: "var(--supos-uns-button-color)"
              }
            }
          )
        ] }, key)),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Button,
          {
            color: "default",
            variant: "filled",
            onClick: () => {
              add();
              form.setFieldValue("functions", void 0);
            },
            block: true,
            style: { color: "var(--supos-text-color)", backgroundColor: "var(--supos-uns-button-color)" },
            icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.AddAlt, { size: 20 })
          }
        )
      ] }) }) : /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { style: { width: "100%" }, wrapperCol: { span: 24 }, labelCol: { span: 0 }, name: "body", children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Input.TextArea, { style: { height: 100 } }) })
    ] })
  ] });
};
const content = `{
  "createTime": "2021-08-10T18:20:41.182+08:00",
  "header": {},
  "messageId": "1575342578356288",
  "payload": []
}`;
const WebHook = ({ title }) => {
  const formatMessage = supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const [searchForm] = supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.useForm();
  const { modal } = supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.App.useApp();
  const [selectNameValue, setSelectNameValue] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState("name");
  const [services, setServices] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState([]);
  const [eventMetaList, setEventMetaList] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState([]);
  const [actionList, setActionList] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState([]);
  const [show, setShow] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState(false);
  const [id, setId] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState();
  const [isEdit, setIsEdit] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState(false);
  const [isCopy, setIsCopy] = supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useState(false);
  const [form] = supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.useForm();
  const sysParams = {
    pageNo: 1,
    pageSize: 9999,
    moduleCode: "sys_webhook"
  };
  supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.useEffect(() => {
    queryCodeValues({
      entityCode: "service",
      ...sysParams
    }).then((res2) => {
      if (res2.data.length) {
        setServices(res2.data.map((item) => ({ label: item.name, value: item.code })));
      }
    });
  }, []);
  const { data, pagination, setSearchParams, loading, refreshRequest } = supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.usePagination({
    initPageSize: 100,
    fetchApi: getWebHookList
  });
  const columns = [
    {
      title: formatMessage("name"),
      dataIndex: "name",
      key: "name",
      ellipsis: true,
      width: "10%"
    },
    {
      title: formatMessage("service"),
      dataIndex: "serviceName",
      ellipsis: true,
      width: "10%",
      key: "serviceName"
    },
    {
      title: formatMessage("rawData"),
      dataIndex: "eventMetaName",
      ellipsis: true,
      width: "10%",
      key: "eventMetaName"
    },
    {
      title: formatMessage("event"),
      dataIndex: "actionNames",
      ellipsis: true,
      width: "10%",
      key: "actionNames",
      render: (item) => {
        return Object.values(item).join(",");
      }
    },
    {
      title: formatMessage("webHook"),
      dataIndex: "url",
      ellipsis: true,
      width: "18%",
      key: "url"
    },
    {
      title: formatMessage("note"),
      ellipsis: true,
      dataIndex: "description",
      width: "13%",
      key: "description"
    },
    {
      title: formatMessage("createTime"),
      dataIndex: "createTime",
      ellipsis: true,
      width: "13%",
      key: "createTime",
      render: (item) => supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.formatTimestamp(item)
    },
    {
      title: formatMessage("title"),
      dataIndex: "title",
      width: "12%",
      minWidth: 200,
      ellipsis: true,
      key: "title",
      render(_, text) {
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Flex, { style: { fontSize: 12 }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
            {
              auth: supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["webHook.copy"],
              style: {
                height: 18,
                fontSize: 14,
                background: "none",
                color: "var(--supos-theme-color)"
              },
              color: "default",
              variant: "filled",
              onClick: () => {
                onCopyOpen == null ? void 0 : onCopyOpen(text);
              },
              children: commonFormatMessage("common.copy")
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
            {
              auth: supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["webHook.edit"],
              style: {
                height: 18,
                background: "none",
                color: "var(--supos-theme-color)",
                fontSize: 14
              },
              color: "default",
              variant: "filled",
              onClick: () => {
                setId(text.id);
                onEditOpen == null ? void 0 : onEditOpen(text);
              },
              children: commonFormatMessage("common.edit")
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
            {
              auth: supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["webHook.delete"],
              style: {
                height: 18,
                background: "none",
                color: "var(--supos-theme-color)",
                fontSize: 14
              },
              color: "default",
              variant: "filled",
              onClick: () => {
                modal.confirm({
                  title: commonFormatMessage("common.deleteConfirm"),
                  onOk: () => {
                    deleteWebHookList(text.id).then(() => {
                      supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.message.success(commonFormatMessage("common.optsuccess"));
                      refreshRequest();
                    });
                  },
                  okText: commonFormatMessage("common.confirm")
                });
              },
              children: commonFormatMessage("common.delete")
            }
          )
        ] });
      }
    }
  ];
  const formItemOptions = [
    {
      name: "common",
      type: "Select",
      properties: {
        options: [
          { label: formatMessage("name"), value: "name" },
          { label: formatMessage("webHook"), value: "webHook" },
          { label: formatMessage("note"), value: "note" }
        ]
      },
      render: () => {
        return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { name: "common", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "flex", gap: 8 }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Select,
            {
              defaultValue: "name",
              options: [
                { label: formatMessage("name"), value: "name" },
                { label: formatMessage("webHook"), value: "webHook" },
                { label: formatMessage("note"), value: "note" }
              ],
              style: { minWidth: 110 },
              onChange: (text) => {
                setSelectNameValue(text);
              },
              onClear: () => {
                setSelectNameValue("");
              }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Input,
            {
              placeholder: selectNameValue === "name" ? formatMessage("name") : selectNameValue === "webHook" ? formatMessage("webHook") : selectNameValue === "note" ? formatMessage("note") : "",
              style: { minWidth: 250 },
              onPressEnter: onSearch
            }
          )
        ] }) });
      }
    }
  ];
  const formItemOptionsWebHook = [
    {
      label: formatMessage("name"),
      name: "name",
      rules: [
        { required: true, message: commonFormatMessage("rule.required") },
        {
          max: 256,
          message: commonFormatMessage("rule.customCharacterLimit", { length: 256 })
        }
      ],
      properties: {
        placeholder: formatMessage("name")
      }
    },
    {
      label: formatMessage("service"),
      name: "service",
      render: () => {
        return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { name: "service", label: formatMessage("service"), rules: [{ required: true }], children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Select,
          {
            placeholder: formatMessage("service"),
            options: services,
            onChange: (_, option) => {
              form.setFieldsValue({ eventMeta: null, actions: null });
              setEventMetaList([]);
              setActionList([]);
              queryCodeValues({
                entityCode: `meta_${option.value}`,
                ...sysParams
              }).then((res2) => setEventMetaList(res2.data));
            }
          }
        ) });
      }
    },
    {
      label: formatMessage("rawData"),
      rules: [{ required: true, message: commonFormatMessage("rule.required") }],
      name: "eventMeta",
      dependencies: ["service"],
      render: () => {
        return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { name: "eventMeta", label: formatMessage("rawData"), rules: [{ required: true }], children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Select,
          {
            placeholder: formatMessage("rawData"),
            options: eventMetaList == null ? void 0 : eventMetaList.map((item) => {
              return {
                label: item.name,
                value: item.code
              };
            }),
            onChange: (_, option) => {
              form.setFieldsValue({ actions: null });
              setActionList([]);
              queryCodeValues({
                entityCode: `action_${option.value}`,
                ...sysParams
              }).then((res2) => setActionList(res2.data));
            }
          }
        ) });
      }
    },
    {
      label: formatMessage("event"),
      rules: [{ required: true, message: commonFormatMessage("rule.required") }],
      name: "actions",
      render: () => {
        return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Form.Item, { name: "actions", label: formatMessage("event"), rules: [{ required: true }], children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_WebHooks__loadShare__antd__loadShare__.Select,
          {
            placeholder: formatMessage("event"),
            options: actionList == null ? void 0 : actionList.map((item) => {
              return {
                label: item.name,
                value: item.code
              };
            }),
            mode: "multiple"
          }
        ) });
      }
    },
    {
      type: "divider"
    },
    {
      render: () => /* @__PURE__ */ jsxRuntimeExports.jsx(WebHookHttpFormList, {})
    },
    {
      type: "divider"
    },
    {
      label: formatMessage("note"),
      name: "description",
      type: "TextArea",
      properties: {
        placeholder: formatMessage("note")
      }
    },
    {
      type: "divider"
    }
  ];
  const onCopyOpen = (data2) => {
    queryCodeValues({
      entityCode: `meta_${data2.service}`,
      ...sysParams
    }).then((res2) => {
      setEventMetaList(res2.data);
      queryCodeValues({
        entityCode: `action_${data2.eventMeta}`,
        ...sysParams
      }).then((res22) => setActionList(res22.data));
    });
    form.setFieldsValue({
      name: `${data2.name}-${commonFormatMessage("common.copy")}`,
      service: data2.service,
      eventMeta: data2.eventMeta,
      actions: data2.actions,
      methodType: data2.methodType,
      url: data2.url.replace("http://", ""),
      timeout: data2.timeout,
      headers: Object.entries(data2.headers || {}).map(([key1, key2]) => ({
        key1,
        key2
      })),
      params: Object.entries(data2.params || {}).map(([key1, key2]) => ({
        key1,
        key2
      })),
      body: data2.body,
      description: data2.description
    });
    setIsEdit(false);
    setIsCopy(true);
    setShow(true);
  };
  const onEditOpen = (data2) => {
    queryCodeValues({
      entityCode: `meta_${data2.service}`,
      ...sysParams
    }).then((res2) => {
      setEventMetaList(res2.data);
      queryCodeValues({
        entityCode: `action_${data2.eventMeta}`,
        ...sysParams
      }).then((res22) => setActionList(res22.data));
    });
    form.setFieldsValue({
      name: data2.name,
      service: data2.service,
      eventMeta: data2.eventMeta,
      actions: data2.actions,
      methodType: data2.methodType,
      url: data2.url.replace("http://", ""),
      timeout: data2.timeout,
      headers: Object.entries((data2 == null ? void 0 : data2.headers) || {}).map(([key1, key2]) => ({
        key1,
        key2
      })),
      params: Object.entries((data2 == null ? void 0 : data2.params) || {}).map(([key1, key2]) => ({
        key1,
        key2
      })),
      body: data2.body,
      description: data2.description
    });
    setIsEdit(true);
    setIsCopy(false);
    setShow(true);
  };
  const onAddHandle = () => {
    setIsEdit(false);
    setIsCopy(false);
    form.resetFields();
    if (show) return;
    setShow(true);
  };
  const onSave = async () => {
    var _a, _b;
    const values = await form.validateFields();
    values.url = `http://${values.url}`;
    values.headers = (_a = values == null ? void 0 : values.headers) == null ? void 0 : _a.reduce((acc, item) => {
      acc[item.key1] = item.key2;
      return acc;
    }, {});
    values.params = (_b = values == null ? void 0 : values.params) == null ? void 0 : _b.reduce((acc, item) => {
      acc[item.key1] = item.key2;
      return acc;
    }, {});
    if (isEdit) {
      values.id = id;
    }
    const api2 = isEdit ? updateWebHookList : addWebHookList;
    await api2({ ...values }).then(() => {
      refreshRequest();
      onClose();
    });
  };
  const onClose = () => {
    setShow(false);
    setIsEdit(false);
    setIsCopy(false);
    form.resetFields();
    setEventMetaList([]);
    setActionList([]);
  };
  const onSearch = () => {
    const params = searchForm.getFieldsValue();
    setSearchParams(
      selectNameValue === "name" ? { name: params.common } : selectNameValue === "webHook" ? { url: params.common } : selectNameValue === "note" ? { description: params.common } : null
    );
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComLayout, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
      {
        className: styles["webHookContainer"],
        title: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Chat, { size: 19, style: { justifyContent: "center", verticalAlign: "middle" } }),
          " ",
          title
        ] }),
        hasBack: false,
        children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { margin: "30px 36px" }, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { marginBottom: "26px" }, children: formatMessage("callDescription") }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: styles["webHook-description"], children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: formatMessage("description") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: formatMessage("apiSpecifications") }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: styles["webHook-description-api"], children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.CodeSnippet, { className: styles["webHook-codeViewWrap"], type: "multi", minCollapsedNumberOfRows: 1, children: content }) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { style: { margin: "30px 0 26px" }, children: formatMessage("webHook") }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { style: { display: "flex", justifyContent: "space-between" }, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComSearch, { form: searchForm, formItemOptions, onSearch }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton, { auth: supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["webHook.add"], type: "primary", onClick: onAddHandle, children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__.PlusOutlined, {}),
              " ",
              formatMessage("newWebHook")
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ProTable,
            {
              loading,
              resizeable: true,
              style: { margin: "16px 0px" },
              columns,
              dataSource: data,
              pagination: {
                total: pagination == null ? void 0 : pagination.total,
                style: { display: "flex", justifyContent: "flex-end", padding: "10px 0" },
                pageSize: (pagination == null ? void 0 : pagination.pageSize) || 20,
                current: pagination == null ? void 0 : pagination.page,
                showQuickJumper: true,
                pageSizeOptions: pagination.pageSizes,
                showSizeChanger: true,
                onChange: pagination.onChange,
                onShowSizeChange: (current, size) => {
                  pagination.onChange({ page: current, pageSize: size });
                }
              }
            }
          )
        ] })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComDrawer, { title: " ", width: 680, open: show, onClose, maskClosable: false, children: show && /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_WebHooks__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.OperationForm,
      {
        formConfig: {
          labelCol: { span: 7 },
          wrapperCol: { span: 17 }
        },
        title: isEdit ? formatMessage("editWebHook") : isCopy ? formatMessage("copyWebHook") : formatMessage("newWebHook"),
        form,
        onCancel: onClose,
        onSave,
        formItemOptions: formItemOptionsWebHook
      }
    ) })
  ] });
};
const App = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: WebHook
}, Symbol.toStringTag, { value: "Module" }));
export {
  App as A,
  WebHook as W,
  jsxRuntimeExports as j
};
