const callDescription = "Usage Instructions";
const description = "1. The addition of webHook allows real-time data to be sent to another system when business data changes.";
const apiSpecifications = "Webhook callback interface specification:";
const name = "Name";
const service = "Service";
const rawData = "Metadata";
const event = "Event";
const webHook = "WebHook";
const note = "Remarks";
const createTime = "Creation time";
const title = "Name";
const newWebHook = "New webHook";
const copyWebHook = "Copy webHook";
const editWebHook = "Editing webHook";
const HTTPRequest = "HTTP Request";
const method = "Method";
const url = "URL";
const timeout = "Timeout";
const HTTPHeaders = "HTTP Headers";
const HTTPParameters = "HTTP Parameters";
const HTTPBody = "HTTP Body";
const commonPlaceholder = "Please enter";
const add = "Add";
const edit = "Edit";
const timeoutTips = "Between 1000 milliseconds and 10000 milliseconds";
const enUS = {
  callDescription,
  description,
  apiSpecifications,
  name,
  service,
  rawData,
  event,
  webHook,
  note,
  createTime,
  title,
  newWebHook,
  copyWebHook,
  editWebHook,
  HTTPRequest,
  method,
  url,
  timeout,
  HTTPHeaders,
  HTTPParameters,
  HTTPBody,
  commonPlaceholder,
  add,
  edit,
  timeoutTips
};
export {
  HTTPBody,
  HTTPHeaders,
  HTTPParameters,
  HTTPRequest,
  add,
  apiSpecifications,
  callDescription,
  commonPlaceholder,
  copyWebHook,
  createTime,
  enUS as default,
  description,
  edit,
  editWebHook,
  event,
  method,
  name,
  newWebHook,
  note,
  rawData,
  service,
  timeout,
  timeoutTips,
  title,
  url,
  webHook
};
