const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/App-Qj1DXmLs.js","assets/supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__-KnfA8M-g.js","assets/_commonjsHelpers-CUmg6egw.js","assets/supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__-C0pvS97-.js","assets/supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__-Cx63gNxE.js","assets/App-_1AP2JOj.css"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-D3MmRnmT.js";
const exposesMap = {
  "./index": async () => {
    const importModule = await __vitePreload(() => import("./App-Qj1DXmLs.js").then((n) => n.A), true ? __vite__mapDeps([0,1,2,3,4,5]) : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./enUS": async () => {
    const importModule = await __vitePreload(() => import("./en-US-DqlwojEh.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  },
  "./zhCN": async () => {
    const importModule = await __vitePreload(() => import("./zh-CN-CRilu-Gu.js"), true ? [] : void 0);
    const exportModule = {};
    Object.assign(exportModule, importModule);
    Object.defineProperty(exportModule, "__esModule", {
      value: true,
      enumerable: false
    });
    return exportModule;
  }
};
export {
  exposesMap as default
};
