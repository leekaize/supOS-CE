const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/index-CaxZt4Hj.js","assets/_commonjsHelpers-CUmg6egw.js","assets/index-D6UEb1uf.js","assets/supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__-KnfA8M-g.js","assets/supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__-C0pvS97-.js","assets/supos_mf_2_ce_mf_1_WebHooks__loadShare__react_mf_2_dom__loadShare__-Be_SRFPL.js","assets/index-CPX7noc5.js","assets/DownloadOutlined-BU1CGR1t.js","assets/supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__-Cx63gNxE.js","assets/index-NF_PaXIO.js","assets/index-BE_olEB-.js","assets/index-cZzrNOD2.js"])))=>i.map(i=>d[i]);
import { i as index_cjs, s as supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__ } from "./supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__-C0pvS97-.js";
import exposesMap from "./virtualExposes-CpbVlQYM.js";
import { _ as __vitePreload } from "./preload-helper-D3MmRnmT.js";
const importMap = {
  "react": async () => {
    let pkg = await __vitePreload(() => import("./index-CaxZt4Hj.js").then((n) => n.i), true ? __vite__mapDeps([0,1]) : void 0);
    return pkg;
  },
  "react-router-dom": async () => {
    let pkg = await __vitePreload(() => import("./index-D6UEb1uf.js"), true ? __vite__mapDeps([2,3,1,4,5]) : void 0);
    return pkg;
  },
  "antd": async () => {
    let pkg = await __vitePreload(() => import("./index-CPX7noc5.js"), true ? __vite__mapDeps([6,3,1,4,7,5,8]) : void 0);
    return pkg;
  },
  "@ant-design/icons": async () => {
    let pkg = await __vitePreload(() => import("./index-NF_PaXIO.js"), true ? __vite__mapDeps([9,3,1,4,7]) : void 0);
    return pkg;
  },
  "@carbon/icons-react": async () => {
    let pkg = await __vitePreload(() => import("./index-BE_olEB-.js"), true ? __vite__mapDeps([10,1,3,4]) : void 0);
    return pkg;
  },
  "react-dom": async () => {
    let pkg = await __vitePreload(() => import("./index-cZzrNOD2.js").then((n) => n.i), true ? __vite__mapDeps([11,1,3,4]) : void 0);
    return pkg;
  }
};
const usedShared = {
  "react": {
    name: "react",
    version: "18.3.1",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/WebHooks",
    async get() {
      usedShared["react"].loaded = true;
      const { "react": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^18.3.1"
    }
  },
  "react-router-dom": {
    name: "react-router-dom",
    version: "6.28.0",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/WebHooks",
    async get() {
      usedShared["react-router-dom"].loaded = true;
      const { "react-router-dom": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^6.27.0"
    }
  },
  "antd": {
    name: "antd",
    version: "5.25.2",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/WebHooks",
    async get() {
      usedShared["antd"].loaded = true;
      const { "antd": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^5.25.2"
    }
  },
  "@ant-design/icons": {
    name: "@ant-design/icons",
    version: "5.5.2",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/WebHooks",
    async get() {
      usedShared["@ant-design/icons"].loaded = true;
      const { "@ant-design/icons": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^5.5.2"
    }
  },
  "@carbon/icons-react": {
    name: "@carbon/icons-react",
    version: "11.60.0",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/WebHooks",
    async get() {
      usedShared["@carbon/icons-react"].loaded = true;
      const { "@carbon/icons-react": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^11.60.0"
    }
  },
  "react-dom": {
    name: "react-dom",
    version: "18.3.1",
    scope: ["default"],
    loaded: false,
    from: "supos-ce/WebHooks",
    async get() {
      usedShared["react-dom"].loaded = true;
      const { "react-dom": pkgDynamicImport } = importMap;
      const res = await pkgDynamicImport();
      const exportModule = { ...res };
      Object.defineProperty(exportModule, "__esModule", {
        value: true,
        enumerable: false
      });
      return function() {
        return exportModule;
      };
    },
    shareConfig: {
      singleton: true,
      requiredVersion: "^18.3.1"
    }
  }
};
const usedRemotes = [
  {
    entryGlobalName: "supos-ce/host",
    name: "@supos_host",
    type: "var",
    entry: "/mf-manifest.json",
    shareScope: "default"
  }
];
const initTokens = {};
const shareScopeName = "default";
const mfName = "supos-ce/WebHooks";
async function init(shared = {}, initScope = []) {
  const initRes = index_cjs.init({
    name: mfName,
    remotes: usedRemotes,
    shared: usedShared,
    plugins: [],
    shareStrategy: "version-first"
  });
  var initToken = initTokens[shareScopeName];
  if (!initToken)
    initToken = initTokens[shareScopeName] = { from: mfName };
  if (initScope.indexOf(initToken) >= 0) return;
  initScope.push(initToken);
  initRes.initShareScopeMap("default", shared);
  try {
    await Promise.all(await initRes.initializeSharing("default", {
      strategy: "version-first",
      from: "build",
      initScope
    }));
  } catch (e) {
    console.error(e);
  }
  supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__.initResolve(initRes);
  return initRes;
}
function getExposes(moduleName) {
  if (!(moduleName in exposesMap)) throw new Error(`Module ${moduleName} does not exist in container.`);
  return exposesMap[moduleName]().then((res) => () => res);
}
export {
  getExposes as get,
  init
};
