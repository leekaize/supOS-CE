const callDescription = "调用说明";
const description = "1.通过新增webHook允许在业务数据发生变化时，将实时数据发送到另一个系统。";
const apiSpecifications = "2.Webhook回调接口规范：";
const name = "名称";
const service = "服务";
const rawData = "元数据";
const event = "事件";
const webHook = "webHook";
const note = "备注";
const createTime = "创建时间";
const title = "操作";
const newWebHook = "创建 webHook";
const copyWebHook = "复制 webHook";
const editWebHook = "编辑 webHook";
const HTTPRequest = "HTTP 请求";
const method = "Method";
const url = "URL";
const timeout = "Timeout";
const HTTPHeaders = "HTTP Headers";
const HTTPParameters = "HTTP Parameters";
const HTTPBody = "HTTP Body";
const commonPlaceholder = "请输入";
const add = "新增";
const edit = "编辑";
const timeoutTips = "在1000毫秒至10000毫秒之间";
const zhCN = {
  callDescription,
  description,
  apiSpecifications,
  name,
  service,
  rawData,
  event,
  webHook,
  note,
  createTime,
  title,
  newWebHook,
  copyWebHook,
  editWebHook,
  HTTPRequest,
  method,
  url,
  timeout,
  HTTPHeaders,
  HTTPParameters,
  HTTPBody,
  commonPlaceholder,
  add,
  edit,
  timeoutTips
};
export {
  HTTPBody,
  HTTPHeaders,
  HTTPParameters,
  HTTPRequest,
  add,
  apiSpecifications,
  callDescription,
  commonPlaceholder,
  copyWebHook,
  createTime,
  zhCN as default,
  description,
  edit,
  editWebHook,
  event,
  method,
  name,
  newWebHook,
  note,
  rawData,
  service,
  timeout,
  timeoutTips,
  title,
  url,
  webHook
};
