import "./hostInit-Dn-3ZuSg.js";
import { i as index_cjs, s as supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__ } from "./supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__-C0pvS97-.js";
import { j as jsxRuntimeExports, W as WebHook } from "./App-Qj1DXmLs.js";
import { s as supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__-KnfA8M-g.js";
import { s as supos_mf_2_ce_mf_1_WebHooks__loadShare__react_mf_2_dom__loadShare__ } from "./supos_mf_2_ce_mf_1_WebHooks__loadShare__react_mf_2_dom__loadShare__-Be_SRFPL.js";
import "./preload-helper-D3MmRnmT.js";
import "./supos_mf_2_ce_mf_1_WebHooks__loadShare___mf_0_ant_mf_2_design_mf_1_icons__loadShare__-Cx63gNxE.js";
import "./_commonjsHelpers-CUmg6egw.js";
var createRoot;
var m = supos_mf_2_ce_mf_1_WebHooks__loadShare__react_mf_2_dom__loadShare__;
{
  createRoot = m.createRoot;
  m.hydrateRoot;
}
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_WebHooks__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("react-router-dom", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^6.27.0"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_WebHooks__loadShare__react_mf_2_router_mf_2_dom__loadShare__ = exportModule;
createRoot(document.getElementById("root")).render(
  /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__react__loadShare__.StrictMode, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_WebHooks__loadShare__react_mf_2_router_mf_2_dom__loadShare__.BrowserRouter, { children: /* @__PURE__ */ jsxRuntimeExports.jsx(WebHook, { title: "" }) }) })
);
