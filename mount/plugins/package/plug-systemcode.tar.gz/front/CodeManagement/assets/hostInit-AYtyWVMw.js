const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/remoteEntry-BdmVCHaS.js","assets/supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__-ebOofBfC.js","assets/virtualExposes-CJUmja5s.js","assets/preload-helper-ClaZnuLS.js"])))=>i.map(i=>d[i]);
import { _ as __vitePreload } from "./preload-helper-ClaZnuLS.js";
const remoteEntryPromise = __vitePreload(() => import("./remoteEntry-BdmVCHaS.js"), true ? __vite__mapDeps([0,1,2,3]) : void 0);
Promise.resolve(remoteEntryPromise).then((remoteEntry) => {
  return Promise.resolve(remoteEntry.__tla).then(remoteEntry.init).catch(remoteEntry.init);
});
