const codeManagement = "编码管理";
const editCode = "修改编码";
const newCode = "新增编码";
const code = "编码";
const name = "名称";
const note = "备注";
const editCodeValue = "修改编码值";
const newCodeValue = "新增编码值";
const codeValue = "编码值";
const search = "搜索";
const batchDelete = "批量删除";
const descriptionA = "描述A";
const descriptionB = "描述B";
const descriptionC = "描述C";
const custom = "自定义";
const all = "所有";
const builtIn = "内置";
const codeRule = "字母、数字、下划线组合，最大长度100！";
const maxLength = "最大长度{num}！";
const modulePlaceholderTip = "请输入名称进行搜索";
const codePlaceholderTip = "请输入编码或名称进行搜索";
const codeValuePlaceholderTip = "请输入编码或名称进行搜索";
const zhCN = {
  codeManagement,
  editCode,
  newCode,
  code,
  name,
  note,
  editCodeValue,
  newCodeValue,
  codeValue,
  search,
  batchDelete,
  descriptionA,
  descriptionB,
  descriptionC,
  custom,
  all,
  builtIn,
  codeRule,
  maxLength,
  modulePlaceholderTip,
  codePlaceholderTip,
  codeValuePlaceholderTip
};
export {
  all,
  batchDelete,
  builtIn,
  code,
  codeManagement,
  codePlaceholderTip,
  codeRule,
  codeValue,
  codeValuePlaceholderTip,
  custom,
  zhCN as default,
  descriptionA,
  descriptionB,
  descriptionC,
  editCode,
  editCodeValue,
  maxLength,
  modulePlaceholderTip,
  name,
  newCode,
  newCodeValue,
  note,
  search
};
