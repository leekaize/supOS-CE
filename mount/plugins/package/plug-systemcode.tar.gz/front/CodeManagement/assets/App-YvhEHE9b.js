import { s as supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__ } from "./supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__-CbMmPqiQ.js";
import { s as supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__, i as index_cjs } from "./supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__-ebOofBfC.js";
var jsxRuntime = { exports: {} };
var reactJsxRuntime_production_min = {};
/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */
var f = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__, k = Symbol.for("react.element"), l = Symbol.for("react.fragment"), m = Object.prototype.hasOwnProperty, n = f.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner, p = { key: true, ref: true, __self: true, __source: true };
function q(c, a, g) {
  var b, d = {}, e = null, h = null;
  void 0 !== g && (e = "" + g);
  void 0 !== a.key && (e = "" + a.key);
  void 0 !== a.ref && (h = a.ref);
  for (b in a) m.call(a, b) && !p.hasOwnProperty(b) && (d[b] = a[b]);
  if (c && c.defaultProps) for (b in a = c.defaultProps, a) void 0 === d[b] && (d[b] = a[b]);
  return { $$typeof: k, type: c, key: e, ref: h, props: d, _owner: n.current };
}
reactJsxRuntime_production_min.Fragment = l;
reactJsxRuntime_production_min.jsx = q;
reactJsxRuntime_production_min.jsxs = q;
{
  jsxRuntime.exports = reactJsxRuntime_production_min;
}
var jsxRuntimeExports = jsxRuntime.exports;
const { loadShare: loadShare$2 } = index_cjs;
const { initPromise: initPromise$6 } = supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__;
const res$6 = initPromise$6.then((_) => loadShare$2("@carbon/icons-react", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^11.60.0"
  } }
}));
const exportModule$6 = await res$6.then((factory) => factory());
var supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__ = exportModule$6;
const { loadRemote: loadRemote$3 } = index_cjs;
const { initPromise: initPromise$5 } = supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__;
const res$5 = initPromise$5.then((_) => loadRemote$3("@supos_host/components"));
const exportModule$5 = await initPromise$5.then((_) => res$5);
var supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__ = exportModule$5;
const { loadRemote: loadRemote$2 } = index_cjs;
const { initPromise: initPromise$4 } = supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__;
const res$4 = initPromise$4.then((_) => loadRemote$2("@supos_host/hooks"));
const exportModule$4 = await initPromise$4.then((_) => res$4);
var supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__ = exportModule$4;
const { loadShare: loadShare$1 } = index_cjs;
const { initPromise: initPromise$3 } = supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__;
const res$3 = initPromise$3.then((_) => loadShare$1("antd", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^5.25.2"
  } }
}));
const exportModule$3 = await res$3.then((factory) => factory());
var supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__ = exportModule$3;
const { loadRemote: loadRemote$1 } = index_cjs;
const { initPromise: initPromise$2 } = supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__;
const res$2 = initPromise$2.then((_) => loadRemote$1("@supos_host/utils"));
const exportModule$2 = await initPromise$2.then((_) => res$2);
var supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__ = exportModule$2;
const baseUrl = "/inter-api/supos/sys";
const api = new supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_utils__loadRemote__.ApiWrapper(baseUrl);
const queryModuleList = async (params) => api.get("/modules", { params });
const deleteModule = async (moduleCode) => api.delete(`/modules/${moduleCode}`);
const queryCodeList = async (params) => api.get("/entities", { params });
const addCode = async (params) => api.post("/entities", params);
const updateCode = async (params) => api.put("/entities", params);
const deleteCode = async (params) => api.delete("/entities", { data: params });
const queryCodeValues = async (params) => api.get("/codes", { params });
const addCodeValue = async (params) => api.post("/codes", params);
const updateCodeValue = async (params) => api.put("/codes", params);
const deleteCodeValue = async (params) => api.delete("/codes", { data: params });
const batchDeleteCodeValue = async (params) => api.delete("/codes/batch", { data: params });
const sortCodeValue = async (params) => api.put("/codes/sort", params);
const codeGroupBox = "_codeGroupBox_1ht80_1";
const titleBox$1 = "_titleBox_1ht80_21";
const title$1 = "_title_1ht80_10";
const addIcon = "_addIcon_1ht80_32";
const disabled = "_disabled_1ht80_35";
const tree$1 = "_tree_1ht80_39";
const optGroup = "_optGroup_1ht80_48";
const styles$3 = {
  codeGroupBox,
  titleBox: titleBox$1,
  title: title$1,
  addIcon,
  disabled,
  tree: tree$1,
  optGroup
};
const { loadRemote } = index_cjs;
const { initPromise: initPromise$1 } = supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__;
const res$1 = initPromise$1.then((_) => loadRemote("@supos_host/button-permission"));
const exportModule$1 = await initPromise$1.then((_) => res$1);
var supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__ = exportModule$1;
const REMOTE_NAME = "CodeManagement";
const CodeList = (props) => {
  const { moduleCode, onSelect } = props;
  const formatMessage = supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const [form] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Form.useForm();
  const paginationRef = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useRef({ current: 1, pageSize: 100 });
  const oldDataSourceRef = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useRef([]);
  const [dataSource, setDataSource] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState([]);
  const [isEdit, setIsEdit] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(false);
  const [openDrawer, setOpenDrawer] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(false);
  const [buttonLoading, setButtonLoading] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(false);
  const [selectedKeys, setSelectedKeys] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState([]);
  const [hasMore, setHasMore] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(true);
  const [searchKey, setSearchKey] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState("");
  const { modal } = supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.App.useApp();
  const formItemOptions = [
    {
      label: formatMessage("code"),
      name: "code",
      rules: [
        { required: true, message: commonFormatMessage("rule.required") },
        { pattern: /^[A-Za-z0-9_]{0,100}$/, message: formatMessage("codeRule") }
      ],
      properties: {
        placeholder: formatMessage("code"),
        disabled: isEdit
      }
    },
    {
      label: formatMessage("name"),
      name: "name",
      rules: [
        { required: true, message: commonFormatMessage("rule.required") },
        {
          max: 500,
          message: formatMessage("maxLength", { num: 500 })
        }
      ],
      properties: {
        placeholder: formatMessage("name")
      }
    },
    {
      label: formatMessage("note"),
      name: "description",
      rules: [
        {
          max: 255,
          message: formatMessage("maxLength", { num: 255 })
        }
      ],
      properties: {
        placeholder: formatMessage("note")
      }
    },
    {
      type: "divider"
    }
  ];
  supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useEffect(() => {
    setSelectedKeys([]);
    if (!moduleCode) {
      setDataSource([]);
      setHasMore(false);
      return;
    }
    oldDataSourceRef.current = [];
    getList();
  }, [moduleCode]);
  const getList = (params) => {
    var _a, _b;
    queryCodeList({
      moduleCode,
      pageNo: (_a = paginationRef.current) == null ? void 0 : _a.current,
      pageSize: (_b = paginationRef.current) == null ? void 0 : _b.pageSize,
      searchKey,
      ...{}
    }).then((res2) => {
      const { data, pageNo, pageSize, total } = res2;
      data.forEach((item2) => {
        item2.page = pageNo;
      });
      paginationRef.current = {
        current: pageNo,
        pageSize,
        total
      };
      setDataSource([...oldDataSourceRef.current, ...data]);
      oldDataSourceRef.current = [...oldDataSourceRef.current, ...data];
      if (!data.length || data.length < pageSize) {
        setHasMore(false);
      }
    }).catch(() => {
      setHasMore(false);
    });
  };
  const handleAdd = () => {
    if (!moduleCode) return;
    setOpenDrawer(true);
    setIsEdit(false);
  };
  const handleEdit = (e, item2) => {
    e.stopPropagation();
    form.setFieldsValue(item2);
    setIsEdit(true);
    setOpenDrawer(true);
  };
  const handleDelete = (e, record) => {
    e.stopPropagation();
    modal.confirm({
      title: commonFormatMessage("common.deleteConfirm"),
      onOk: () => {
        deleteCode({ ...record, moduleCode }).then(() => {
          var _a, _b;
          const newCurrent = record.page === 1 ? 1 : record.page - 1;
          const newDataSource = [...dataSource];
          newDataSource.splice((record.page - 1) * ((_a = paginationRef.current) == null ? void 0 : _a.pageSize), (_b = paginationRef.current) == null ? void 0 : _b.total);
          oldDataSourceRef.current = newDataSource;
          paginationRef.current.current = newCurrent;
          if (record.code === selectedKeys[0]) {
            onSelect([]);
            setSelectedKeys([]);
          }
          setHasMore(true);
          getList();
        });
      }
    });
  };
  const handleSave = async () => {
    const values = await form.validateFields();
    setButtonLoading(true);
    const api2 = isEdit ? updateCode : addCode;
    api2({ ...values, moduleCode }).then(() => {
      var _a, _b, _c, _d, _e, _f, _g;
      handleCloseDrawer();
      if (isEdit) {
        const newDataSource2 = dataSource.map((item2) => {
          if (item2.code === values.code) {
            return { ...item2, ...values };
          }
          return { ...item2 };
        });
        oldDataSourceRef.current = newDataSource2;
        setDataSource(newDataSource2);
        return;
      }
      if (((_a = paginationRef.current) == null ? void 0 : _a.current) * ((_b = paginationRef.current) == null ? void 0 : _b.pageSize) === ((_c = paginationRef.current) == null ? void 0 : _c.total)) {
        const newCurrent = ((_d = paginationRef.current) == null ? void 0 : _d.current) + 1;
        paginationRef.current.current = newCurrent;
        getList();
        return;
      }
      const newDataSource = [...dataSource];
      newDataSource.splice(
        (((_e = paginationRef.current) == null ? void 0 : _e.current) - 1) * ((_f = paginationRef.current) == null ? void 0 : _f.pageSize),
        (_g = paginationRef.current) == null ? void 0 : _g.total
      );
      oldDataSourceRef.current = newDataSource;
      getList();
    }).finally(() => {
      setButtonLoading(false);
    });
  };
  const handleCloseDrawer = () => {
    setOpenDrawer(false);
    form.resetFields();
  };
  const handleSelect = (item2) => {
    onSelect([item2]);
    setSelectedKeys([item2.code]);
  };
  const handleLoadMore = () => {
    var _a;
    paginationRef.current.current = ((_a = paginationRef.current) == null ? void 0 : _a.current) + 1;
    getList();
  };
  const handleChangeKeyword = (e) => {
    const { value } = e.target;
    setSearchKey(value);
  };
  const handleSearch = () => {
    paginationRef.current.current = 1;
    oldDataSourceRef.current = [];
    onSelect([]);
    setSelectedKeys([]);
    setHasMore(true);
    getList();
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
      {
        className: styles$3.codeGroupBox,
        title: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: styles$3.titleBox, children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Code, { style: { flexShrink: 0 } }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles$3.title, title: formatMessage("codeManagement"), children: formatMessage("codeManagement") })
        ] }),
        mustHasBack: false,
        extra: /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Space, { size: "small", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Space.Compact, { block: true, size: "small", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Input,
              {
                style: { width: 100 },
                disabled: !moduleCode,
                value: searchKey,
                onChange: handleChangeKeyword,
                onPressEnter: handleSearch,
                placeholder: formatMessage("codePlaceholderTip"),
                title: searchKey ? searchKey : formatMessage("codePlaceholderTip")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Button, { type: "primary", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Search, {}), disabled: !moduleCode, onClick: handleSearch, children: formatMessage("search") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthWrapper, { auth: supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["codeManagement.addCode"], children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Space.Compact, { block: true, size: "small", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { title: formatMessage("newCode"), children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.NewTab, { className: !moduleCode ? styles$3.disabled : styles$3.addIcon, onClick: handleAdd }) }) }) })
        ] }),
        children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.InfiniteScrollList,
          {
            className: styles$3.tree,
            dataSource,
            rowKey: "code",
            rowLabel: "name",
            extra: (item2) => {
              if (item2.sysDefault) return null;
              return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Space, { size: "small", className: styles$3.optGroup, children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthWrapper, { auth: supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["codeManagement.editCode"], children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Edit,
                  {
                    onClick: (e) => handleEdit(e, item2)
                  }
                ) }),
                /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthWrapper, { auth: supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["codeManagement.deleteCode"], children: /* @__PURE__ */ jsxRuntimeExports.jsx(
                  supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.TrashCan,
                  {
                    onClick: (e) => handleDelete(e, item2)
                  }
                ) })
              ] });
            },
            onSelect: handleSelect,
            selectedKeys,
            hasMore,
            onLoadMoreData: handleLoadMore
          }
        )
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComDrawer, { open: openDrawer, onClose: handleCloseDrawer, width: 680, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.OperationForm,
      {
        formConfig: {
          labelCol: { span: 7 },
          wrapperCol: { span: 17 }
        },
        title: isEdit ? formatMessage("editCode") : formatMessage("newCode"),
        form,
        onCancel: handleCloseDrawer,
        onSave: handleSave,
        formItemOptions,
        loading: buttonLoading
      }
    ) })
  ] });
};
const { loadShare } = index_cjs;
const { initPromise } = supos_mf_2_ce_mf_1_CodeManagement__mf_v__runtimeInit__mf_v__;
const res = initPromise.then((_) => loadShare("ahooks", {
  customShareInfo: { shareConfig: {
    singleton: true,
    strictVersion: false,
    requiredVersion: "^3.8.5"
  } }
}));
const exportModule = await res.then((factory) => factory());
var supos_mf_2_ce_mf_1_CodeManagement__loadShare__ahooks__loadShare__ = exportModule;
const moduleBox = "_moduleBox_lkbil_1";
const searchBox = "_searchBox_lkbil_8";
const filterIcon = "_filterIcon_lkbil_16";
const tree = "_tree_lkbil_27";
const item = "_item_lkbil_33";
const moduleTitle = "_moduleTitle_lkbil_38";
const moduleTag = "_moduleTag_lkbil_45";
const styles$2 = {
  moduleBox,
  searchBox,
  filterIcon,
  tree,
  item,
  moduleTitle,
  moduleTag
};
const ModuleList = (props) => {
  const { onSelect } = props;
  const formatMessage = supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const { modal } = supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.App.useApp();
  const paginationRef = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useRef({ current: 1, pageSize: 100 });
  const oldDataSourceRef = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useRef([]);
  const [type, setType] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState("null");
  const [searchKey, setSearchKey] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState("");
  const [loading, setLoading] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(false);
  const [dataSource, setDataSource] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState([]);
  const [hasMore, setHasMore] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(true);
  const [selectedKeys, setSelectedKeys] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState([]);
  const items = [
    {
      label: formatMessage("all"),
      key: "null"
    },
    {
      label: formatMessage("builtIn"),
      key: "SYSTEM"
    },
    {
      label: formatMessage("custom"),
      key: "BIZ"
    }
  ];
  const { run: debouncedSearch } = supos_mf_2_ce_mf_1_CodeManagement__loadShare__ahooks__loadShare__.useDebounceFn(
    (searchKey2) => {
      getList({ searchKey: searchKey2 });
    },
    { wait: 500 }
  );
  supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useEffect(() => {
    oldDataSourceRef.current = [];
    paginationRef.current = { current: 1, pageSize: 100 };
    getList();
  }, [type]);
  const getList = (params) => {
    var _a, _b;
    if (loading) {
      return;
    }
    setLoading(true);
    queryModuleList({
      type: type === "null" ? void 0 : type,
      searchKey,
      pageNo: (_a = paginationRef.current) == null ? void 0 : _a.current,
      pageSize: (_b = paginationRef.current) == null ? void 0 : _b.pageSize,
      ...params || {}
    }).then((res2) => {
      const { data, pageSize, pageNo, total } = res2;
      paginationRef.current = {
        current: pageNo,
        pageSize,
        total
      };
      data.forEach((item2) => {
        item2.page = pageNo;
      });
      setDataSource([...oldDataSourceRef.current, ...data]);
      oldDataSourceRef.current = [...oldDataSourceRef.current, ...data];
      setLoading(false);
      if (!data.length || data.length < pageSize) {
        setHasMore(false);
      }
    }).catch(() => {
      setLoading(false);
      setHasMore(false);
    });
  };
  const handleSelectType = (params) => {
    if (params.key === type) return;
    oldDataSourceRef.current = [];
    onSelect([]);
    setSelectedKeys([]);
    setSearchKey("");
    setType(params.key);
  };
  const handleSearch = (e) => {
    const { value } = e.target;
    oldDataSourceRef.current = [];
    setSelectedKeys([]);
    setSearchKey(value);
    debouncedSearch(value);
  };
  const handleSelect = (item2) => {
    onSelect([item2]);
    setSelectedKeys([item2.code]);
  };
  const handleLoadMore = () => {
    var _a;
    paginationRef.current.current = ((_a = paginationRef.current) == null ? void 0 : _a.current) + 1;
    getList();
  };
  const handleDelete = (e, record) => {
    e.stopPropagation();
    modal.confirm({
      zIndex: 99999,
      title: commonFormatMessage("common.deleteConfirm"),
      onOk: () => {
        deleteModule(record.code).then(() => {
          var _a, _b;
          supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.message.success(commonFormatMessage("common.deleteSuccessfully"));
          const newCurrent = record.page === 1 ? 1 : record.page - 1;
          const newDataSource = [...dataSource];
          newDataSource.splice((record.page - 1) * ((_a = paginationRef.current) == null ? void 0 : _a.pageSize), (_b = paginationRef.current) == null ? void 0 : _b.total);
          oldDataSourceRef.current = newDataSource;
          paginationRef.current.current = newCurrent;
          if (selectedKeys.includes(record.code)) {
            onSelect([]);
            setSelectedKeys([]);
          }
          getList();
        });
      }
    });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: styles$2.moduleBox, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: styles$2.searchBox, children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Dropdown, { menu: { items, selectedKeys: [type], onClick: handleSelectType }, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: styles$2.filterIcon, children: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Filter, { size: 16 }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ProSearch,
        {
          size: "sm",
          placeholder: formatMessage("modulePlaceholderTip"),
          value: searchKey,
          onChange: handleSearch,
          title: searchKey ? searchKey : formatMessage("modulePlaceholderTip")
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.InfiniteScrollList,
      {
        className: styles$2.tree,
        dataSource,
        selectedKeys,
        hasMore,
        renderItem: (item2) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: styles$2.item, children: [
          item2.type === "SYSTEM" ? /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Tag, { className: styles$2.moduleTag, color: "green", children: formatMessage("builtIn") }) : /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Tag, { className: styles$2.moduleTag, children: formatMessage("custom") }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: styles$2.moduleTitle, title: item2.name, children: item2.name })
        ] }),
        extra: (item2) => {
          if (item2.type === "SYSTEM") return null;
          return /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.TrashCan,
            {
              onClick: (e) => handleDelete(e, item2)
            }
          );
        },
        onSelect: handleSelect,
        onLoadMoreData: handleLoadMore
      }
    )
  ] });
};
const codeTableBox = "_codeTableBox_5knls_1";
const tableBox = "_tableBox_5knls_19";
const styles$1 = {
  codeTableBox,
  tableBox
};
const CodeValueList = (props) => {
  const { moduleCode, entityCode } = props;
  const formatMessage = supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const commonFormatMessage = supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate();
  const [form] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Form.useForm();
  const { modal } = supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.App.useApp();
  const {
    pagination,
    data: dataSource,
    loading,
    refreshRequest,
    setSearchParams,
    clearData,
    setPagination
  } = supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.usePagination({
    initPageSize: 20,
    fetchApi: queryCodeValues,
    firstNotGetData: true
  });
  const tableRef = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useRef(null);
  const [isEdit, setIsEdit] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(false);
  const [openDrawer, setOpenDrawer] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(false);
  const [selectedRowKeys, setSelectedRowKeys] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState([]);
  const [buttonLoading, setButtonLoading] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(false);
  const [searchKey, setSearchKey] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState("");
  const [scrollY, setScrollY] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState(0);
  const columns = [
    {
      title: formatMessage("code"),
      dataIndex: "code",
      width: "35%"
    },
    {
      title: formatMessage("name"),
      dataIndex: "name",
      width: "35%"
    },
    {
      title: commonFormatMessage("common.operation"),
      dataIndex: "operation",
      render: (_, record) => {
        return /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Space, { size: "small", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthWrapper, { auth: supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["codeManagement.editCodeValue"], children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              style: {
                color: "var(--supos-theme-color)"
              },
              type: "link",
              onClick: () => handleEdit(record),
              children: commonFormatMessage("common.edit")
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthWrapper, { auth: supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["codeManagement.delCodeValue"], children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            "a",
            {
              style: {
                color: "var(--supos-theme-color)"
              },
              type: "link",
              onClick: () => handleDelete(record),
              children: commonFormatMessage("common.delete")
            }
          ) })
        ] });
      }
    }
  ];
  const formItemOptions = [
    {
      name: "id",
      hidden: true
    },
    {
      label: formatMessage("code"),
      name: "code",
      rules: [
        { required: true, message: commonFormatMessage("rule.required") },
        { pattern: /^[A-Za-z0-9_]{0,100}$/, message: formatMessage("codeRule") }
      ],
      properties: {
        placeholder: formatMessage("code"),
        disabled: isEdit
      }
    },
    {
      label: formatMessage("name"),
      name: "name",
      rules: [
        { required: true, message: commonFormatMessage("rule.required") },
        {
          max: 500,
          message: formatMessage("maxLength", { num: 500 })
        }
      ],
      properties: {
        placeholder: formatMessage("name")
      }
    },
    {
      label: formatMessage("descriptionA"),
      name: "desA",
      rules: [
        {
          max: 255,
          message: formatMessage("maxLength", { num: 255 })
        }
      ],
      properties: {
        placeholder: formatMessage("descriptionA")
      }
    },
    {
      label: formatMessage("descriptionB"),
      name: "desB",
      rules: [
        {
          max: 255,
          message: formatMessage("maxLength", { num: 255 })
        }
      ],
      properties: {
        placeholder: formatMessage("descriptionB")
      }
    },
    {
      label: formatMessage("descriptionC"),
      name: "desC",
      rules: [
        {
          max: 255,
          message: formatMessage("maxLength", { num: 255 })
        }
      ],
      properties: {
        placeholder: formatMessage("descriptionC")
      }
    },
    {
      label: formatMessage("note"),
      name: "description",
      rules: [
        {
          max: 255,
          message: formatMessage("maxLength", { num: 255 })
        }
      ],
      properties: {
        placeholder: formatMessage("note")
      }
    },
    {
      type: "divider"
    }
  ];
  supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useEffect(() => {
    if (!tableRef.current) return;
    const { clientHeight: outerHeight } = tableRef.current;
    const { clientHeight: headHeight } = tableRef.current.querySelector(".ant-table-header");
    const iHeight = outerHeight - headHeight;
    setScrollY(iHeight);
  }, []);
  supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useEffect(() => {
    setSearchKey("");
    setSelectedRowKeys([]);
    if (!entityCode) {
      clearData();
      return;
    }
    setSearchParams({ searchKey: void 0, entityCode, moduleCode });
    setPagination(1, 20);
  }, [entityCode]);
  const handleChangeSelectedRows = (newSelectedRowKeys) => {
    setSelectedRowKeys(newSelectedRowKeys);
  };
  const handleDelete = (record) => {
    modal.confirm({
      title: commonFormatMessage("common.deleteConfirm"),
      onOk: () => {
        deleteCodeValue({ ...record, moduleCode, entityCode }).then(() => {
          supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.message.success(commonFormatMessage("common.deleteSuccessfully"));
          setPagination(
            pagination.page * pagination.pageSize === pagination.total ? Math.max(1, pagination.page - 1) : pagination.page
          );
        });
      }
    });
  };
  const handleBatchDelete = () => {
    const params = dataSource.filter((item2) => selectedRowKeys.includes(item2.code)).map((item2) => {
      return { moduleCode, entityCode, code: item2.code };
    });
    modal.confirm({
      title: commonFormatMessage("common.deleteConfirm"),
      onOk: () => {
        batchDeleteCodeValue({ codes: params }).then(() => {
          supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.message.success(commonFormatMessage("common.deleteSuccessfully"));
          setPagination(
            selectedRowKeys.length === dataSource.length ? Math.max(1, pagination.page - 1) : pagination.page
          );
        });
      }
    });
  };
  const handleDragEnd = (_, params) => {
    sortCodeValue(params).then(() => {
      refreshRequest();
    });
  };
  const handleAdd = () => {
    setOpenDrawer(true);
    setIsEdit(false);
  };
  const handleEdit = (item2) => {
    form.setFieldsValue(item2);
    setIsEdit(true);
    setOpenDrawer(true);
  };
  const handleCloseDrawer = () => {
    setOpenDrawer(false);
    form.resetFields();
  };
  const handleSave = async () => {
    const values = await form.validateFields();
    setButtonLoading(true);
    const api2 = values.id ? updateCodeValue : addCodeValue;
    api2({ ...values, moduleCode, entityCode }).then(() => {
      handleCloseDrawer();
      refreshRequest();
    }).finally(() => {
      setButtonLoading(false);
    });
  };
  const handleChangeKeyword = (e) => {
    const { value } = e.target;
    setSearchKey(value);
  };
  const handleSearch = () => {
    setSearchParams({ searchKey, entityCode, moduleCode });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
      {
        className: styles$1.codeTableBox,
        title: formatMessage("codeValue"),
        mustHasBack: false,
        extra: /* @__PURE__ */ jsxRuntimeExports.jsx(jsxRuntimeExports.Fragment, { children: /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Space, { size: "small", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Space.Compact, { block: true, size: "small", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(
              supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Input,
              {
                style: { width: 183 },
                disabled: !entityCode,
                value: searchKey,
                onChange: handleChangeKeyword,
                onPressEnter: handleSearch,
                placeholder: formatMessage("codeValuePlaceholderTip"),
                title: searchKey ? searchKey : formatMessage("codeValuePlaceholderTip")
              }
            ),
            /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton, { type: "primary", icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Search, {}), disabled: !entityCode, onClick: handleSearch, children: formatMessage("search") })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Space.Compact, { block: true, size: "small", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
            {
              auth: supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["codeManagement.addCodeValue"],
              size: "small",
              icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.NewTab, {}),
              disabled: !entityCode,
              onClick: handleAdd,
              children: formatMessage("newCode")
            }
          ) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare__antd__loadShare__.Space.Compact, { block: true, size: "small", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
            supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.AuthButton,
            {
              auth: supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_button_mf_2_permission__loadRemote__.ButtonPermission["codeManagement.delCodeValue"],
              size: "small",
              icon: /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.TrashCan, {}),
              disabled: !entityCode || !selectedRowKeys.length,
              onClick: handleBatchDelete,
              children: formatMessage("batchDelete")
            }
          ) })
        ] }) }),
        children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { ref: tableRef, className: styles$1.tableBox, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.DndTable,
          {
            tableConfig: {
              loading,
              fixedPosition: true,
              rowKey: "code",
              columns,
              dataSource,
              rowSelection: { selectedRowKeys, onChange: handleChangeSelectedRows },
              pagination: {
                ...pagination,
                current: pagination.page,
                showSizeChanger: true
              },
              scroll: { y: scrollY !== 0 ? scrollY - 56 : 0 }
            },
            onDragEnd: handleDragEnd
          }
        ) })
      }
    ),
    /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComDrawer, { open: openDrawer, onClose: handleCloseDrawer, width: 680, children: /* @__PURE__ */ jsxRuntimeExports.jsx(
      supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.OperationForm,
      {
        formConfig: {
          labelCol: { span: 7 },
          wrapperCol: { span: 17 }
        },
        title: isEdit ? formatMessage("editCodeValue") : formatMessage("newCodeValue"),
        form,
        onCancel: handleCloseDrawer,
        onSave: handleSave,
        formItemOptions,
        loading: buttonLoading
      }
    ) })
  ] });
};
const titleBox = "_titleBox_1r19x_1";
const title = "_title_1r19x_1";
const styles = {
  titleBox,
  title
};
const CodeManagement = () => {
  const formatMessage = supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_hooks__loadRemote__.useTranslate(REMOTE_NAME);
  const [selectedModuleCode, setSelectedModuleCode] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState();
  const [selectedCode, setSelectedCode] = supos_mf_2_ce_mf_1_CodeManagement__loadShare__react__loadShare__.useState();
  const handleSelectModule = (selectedItems) => {
    var _a;
    setSelectedModuleCode((_a = selectedItems[0]) == null ? void 0 : _a.code);
    setSelectedCode("");
  };
  const handleSelectCode = (selectedItems) => {
    var _a;
    setSelectedCode((_a = selectedItems[0]) == null ? void 0 : _a.code);
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComLayout, { loading: false, children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
    supos_mf_2_ce_mf_1_CodeManagement__loadRemote___mf_0_supos_host_mf_1_components__loadRemote__.ComContent,
    {
      title: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: styles.titleBox, children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(supos_mf_2_ce_mf_1_CodeManagement__loadShare___mf_0_carbon_mf_1_icons_mf_2_react__loadShare__.Code, {}),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: styles.title, children: formatMessage("codeManagement") })
      ] }),
      mustHasBack: false,
      style: {
        display: "flex"
      },
      children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(ModuleList, { onSelect: handleSelectModule }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CodeList, { moduleCode: selectedModuleCode, onSelect: handleSelectCode }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(CodeValueList, { entityCode: selectedCode, moduleCode: selectedModuleCode })
      ]
    }
  ) });
};
const App = /* @__PURE__ */ Object.freeze(/* @__PURE__ */ Object.defineProperty({
  __proto__: null,
  default: CodeManagement
}, Symbol.toStringTag, { value: "Module" }));
export {
  App as A,
  CodeManagement as C,
  jsxRuntimeExports as j
};
