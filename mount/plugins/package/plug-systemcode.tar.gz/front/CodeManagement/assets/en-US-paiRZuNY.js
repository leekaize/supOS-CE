const codeManagement = "Code management";
const editCode = "Modify code";
const newCode = "Add code";
const code = "Code";
const name = "Name";
const note = "Remarks";
const editCodeValue = "Modify code value";
const newCodeValue = "Add code value";
const codeValue = "Code value";
const search = "Search";
const batchDelete = "Batch delete";
const descriptionA = "Description A";
const descriptionB = "Description B";
const descriptionC = "Description C";
const custom = "Custom";
const all = "All";
const builtIn = "Built-in";
const codeRule = "Combination of letters, numbers, and underscores, with a maximum length of 100!";
const maxLength = "Maximum length {num}!";
const modulePlaceholderTip = "Please enter a name to search";
const codePlaceholderTip = "Please enter code or name to search";
const codeValuePlaceholderTip = "Please enter code or name to search";
const enUS = {
  codeManagement,
  editCode,
  newCode,
  code,
  name,
  note,
  editCodeValue,
  newCodeValue,
  codeValue,
  search,
  batchDelete,
  descriptionA,
  descriptionB,
  descriptionC,
  custom,
  all,
  builtIn,
  codeRule,
  maxLength,
  modulePlaceholderTip,
  codePlaceholderTip,
  codeValuePlaceholderTip
};
export {
  all,
  batchDelete,
  builtIn,
  code,
  codeManagement,
  codePlaceholderTip,
  codeRule,
  codeValue,
  codeValuePlaceholderTip,
  custom,
  enUS as default,
  descriptionA,
  descriptionB,
  descriptionC,
  editCode,
  editCodeValue,
  maxLength,
  modulePlaceholderTip,
  name,
  newCode,
  newCodeValue,
  note,
  search
};
